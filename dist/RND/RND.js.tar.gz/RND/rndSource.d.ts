/**
 * Random Data (RND)
 * Description
 * A block of random bytes and how it was made: a nonce, a seed, a key
 * derivation salt, a challenge, a sample for a randomness beacon, or a test
 * input. The same record asks for random data and delivers it: a request
 * states LENGTH (and, optionally, the quality it needs) with no BYTES; the
 * answer carries LENGTH bytes in BYTES with the source that produced them.
 *
 * RND says nothing about how the bytes will be used. Key material that has
 * been assigned a purpose and an algorithm belongs in $KMF.
 * What produced the bytes. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum rndSource {
    /**
     * Not stated.
     */
    Unspecified = 0,
    /**
     * The host operating system's cryptographically secure generator.
     */
    SystemCsprng = 1,
    /**
     * A hardware random number generator.
     */
    Hardware = 2,
    /**
     * A deterministic generator from a stated seed (reproducible; not for
     * secrets).
     */
    Deterministic = 3,
    /**
     * A public randomness beacon (verifiable, not secret).
     */
    Beacon = 4
}
//# sourceMappingURL=rndSource.d.ts.map