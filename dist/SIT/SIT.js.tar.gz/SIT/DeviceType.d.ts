export declare enum DeviceType {
    /**
     * Basic or undefined sensor type
     */
    UNKNOWN = 0,
    /**
     * General optical sensors
     */
    OPTICAL = 1,
    /**
     * Detects infrared radiation
     */
    INFRARED_SENSOR = 2,
    /**
     * Sensitive to ultraviolet light
     */
    ULTRAVIOLET_SENSOR = 3,
    /**
     * For X-ray detection
     */
    X_RAY_SENSOR = 4,
    /**
     * For gamma-ray detection
     */
    GAMMA_RAY_SENSOR = 5,
    /**
     * Basic radar systems
     */
    RADAR = 6,
    /**
     * Advanced radar with phased array technology
     */
    PHASED_ARRAY_RADAR = 7,
    /**
     * For high-resolution imaging
     */
    SYNTHETIC_APERTURE_RADAR = 8,
    /**
     * For astronomical observations using bistatic setup
     */
    BISTATIC_RADIO_TELESCOPE = 9,
    /**
     * For radio astronomy
     */
    RADIO_TELESCOPE = 10,
    /**
     * For atmospheric studies
     */
    ATMOSPHERIC_SENSOR = 11,
    /**
     * For observing space weather phenomena
     */
    SPACE_WEATHER_SENSOR = 12,
    /**
     * General environmental monitoring
     */
    ENVIRONMENTAL_SENSOR = 13,
    /**
     * For measuring seismic activities
     */
    SEISMIC_SENSOR = 14,
    /**
     * For gravity measurements
     */
    GRAVIMETRIC_SENSOR = 15,
    /**
     * For magnetic field detection
     */
    MAGNETIC_SENSOR = 16,
    /**
     * For electromagnetic field analysis
     */
    ELECTROMAGNETIC_SENSOR = 17,
    /**
     * For temperature and heat detection
     */
    THERMAL_SENSOR = 18,
    /**
     * For detecting chemicals and substances
     */
    CHEMICAL_SENSOR = 19,
    /**
     * For biological research and detection
     */
    BIOLOGICAL_SENSOR = 20,
    /**
     * For detecting ionizing radiation
     */
    RADIATION_SENSOR = 21,
    /**
     * For detecting subatomic particles
     */
    PARTICLE_DETECTOR = 22,
    /**
     * Light Detection and Ranging
     */
    LIDAR = 23,
    /**
     * Sound Navigation and Ranging
     */
    SONAR = 24,
    /**
     * General telescopes for astronomical observations
     */
    TELESCOPE = 25,
    /**
     * For spectral analysis
     */
    SPECTROSCOPIC_SENSOR = 26,
    /**
     * For measuring light intensity
     */
    PHOTOMETRIC_SENSOR = 27,
    /**
     * For analyzing polarization of light
     */
    POLARIMETRIC_SENSOR = 28,
    /**
     * For detailed imaging using interference
     */
    INTERFEROMETRIC_SENSOR = 29,
    /**
     * Capturing image data at multiple wavelengths
     */
    MULTISPECTRAL_SENSOR = 30,
    /**
     * Advanced imaging across many spectral bands
     */
    HYPERSPECTRAL_SENSOR = 31,
    /**
     * For Global Positioning System reception
     */
    GPS_RECEIVER = 32,
    /**
     * Standard radio communication device
     */
    RADIO_COMMUNICATIONS = 33,
    /**
     * Advanced laser communication system
     */
    LASER_COMMUNICATIONS = 34,
    /**
     * Satellite communication system
     */
    SATELLITE_COMMUNICATIONS = 35,
    /**
     * Device for laser-based experiments and measurements
     */
    LASER_INSTRUMENT = 36,
    /**
     * Radio frequency analysis and measurement device
     */
    RF_ANALYZER = 37,
    /**
     * Device for ionospheric research
     */
    IONOSPHERIC_SENSOR = 38,
    /**
     * Device for laser-based imaging
     */
    LASER_IMAGING = 39,
    /**
     * Advanced optical telescope
     */
    OPTICAL_TELESCOPE = 40,
    /**
     * Device for high-resolution optical observations
     */
    HIGH_RESOLUTION_OPTICAL = 41,
    RADIO = 42,
    /**
     * Microwave communication device
     */
    MICROWAVE_TRANSMITTER = 43,
    /**
     * Device for radio frequency monitoring
     */
    RF_MONITOR = 44,
    /**
     * High-frequency radio communication device
     */
    HF_RADIO_COMMUNICATIONS = 45
}
//# sourceMappingURL=DeviceType.d.ts.map