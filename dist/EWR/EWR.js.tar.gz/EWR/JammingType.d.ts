export declare enum JammingType {
    NOISE_BARRAGE = 0,
    NOISE_SPOT = 1,
    NOISE_SWEPT = 2,
    DECEPTION_RANGE_GATE = 3,
    DECEPTION_VELOCITY_GATE = 4,
    DECEPTION_ANGLE = 5,
    DECEPTION_FALSE_TARGET = 6,
    DRFM = 7,
    REPEATER = 8,
    CROSS_EYE = 9,
    CROSS_POLARIZATION = 10,
    CHAFF = 11,
    FLARE = 12,
    TOWED_DECOY = 13
}
//# sourceMappingURL=JammingType.d.ts.map