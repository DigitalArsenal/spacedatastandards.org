export declare enum seoObservatoryType {
    GROUND = 0,
    LEO = 1,
    GEO = 2,
    L1 = 3,
    L2 = 4,
    INTERPLANETARY = 5,
    SOLAR = 6
}
//# sourceMappingURL=seoObservatoryType.d.ts.map