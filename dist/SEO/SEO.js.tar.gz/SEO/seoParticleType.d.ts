export declare enum seoParticleType {
    PROTON = 0,
    ELECTRON = 1,
    ALPHA = 2,
    HEAVY_ION = 3,
    NEUTRON = 4,
    COSMIC_RAY = 5,
    MIXED = 6
}
//# sourceMappingURL=seoParticleType.d.ts.map