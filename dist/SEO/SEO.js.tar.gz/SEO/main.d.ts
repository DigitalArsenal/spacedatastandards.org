export { SEO, SEOT } from './SEO.js';
//# sourceMappingURL=main.d.ts.map