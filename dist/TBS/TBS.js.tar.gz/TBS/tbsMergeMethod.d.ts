/**
 * How independent provider reports for one site were reduced to the one
 * published position. Ordinals are wire values: append only; never reorder or
 * reuse.
 */
export declare enum tbsMergeMethod {
    /**
     * Exactly one provider reported the site; nothing was reconciled.
     */
    SINGLE_SOURCE = 0,
    /**
     * The report backed by the largest independent observation count won.
     */
    HIGHEST_SAMPLE_COUNT = 1,
    /**
     * The report with the most recent observation window won.
     */
    MOST_RECENT = 2,
    /**
     * A declared precedence ranking over publishing authorities selected the
     * winning report, regardless of sample count or recency.
     */
    AUTHORITY_PRECEDENCE = 3,
    /**
     * The published position is computed from the agreeing reports and belongs
     * to no single provider.
     */
    CENTROID = 4,
    /**
     * The publisher does not state how the reports were reduced. METHOD
     * defaults here so an unset field can never be read as SINGLE_SOURCE,
     * which holds ordinal 0.
     */
    UNSPECIFIED = 5
}
//# sourceMappingURL=tbsMergeMethod.d.ts.map