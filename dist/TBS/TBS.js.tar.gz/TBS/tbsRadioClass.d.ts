/**
 * Radio access technology class of a terrestrial base-station site.
 *
 * Members name generation-level access technologies only. A publisher encodes
 * the class ITS SOURCE STATES and never re-derives one from frequency,
 * identifier width, or operator. Ordinals are wire values: append only; never
 * reorder or reuse.
 */
export declare enum tbsRadioClass {
    /**
     * Second-generation circuit-switched cellular access.
     */
    GSM = 0,
    /**
     * Code-division multiple-access cellular access.
     */
    CDMA = 1,
    /**
     * Third-generation wideband code-division cellular access.
     */
    UMTS = 2,
    /**
     * Fourth-generation long-term-evolution cellular access.
     */
    LTE = 3,
    /**
     * Fifth-generation new-radio cellular access.
     */
    NR = 4,
    /**
     * An access technology the source names but this enum does not model. The
     * source's own term is retained in the provenance entry, never discarded.
     */
    OTHER = 5,
    /**
     * The source publishes no access technology. RADIO defaults here so an
     * unset field can never be read as GSM, which holds ordinal 0.
     */
    UNKNOWN = 6
}
//# sourceMappingURL=tbsRadioClass.d.ts.map