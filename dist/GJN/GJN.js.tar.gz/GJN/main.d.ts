export { GJN, GJNT } from './GJN.js';
export { GJNBoundingBox, GJNBoundingBoxT } from './GJNBoundingBox.js';
export { GJNFeature, GJNFeatureT } from './GJNFeature.js';
export { GJNGeometry, GJNGeometryT } from './GJNGeometry.js';
export { GJNGeometryType } from './GJNGeometryType.js';
export { GJNLinearRing, GJNLinearRingT } from './GJNLinearRing.js';
export { GJNPolygonRings, GJNPolygonRingsT } from './GJNPolygonRings.js';
export { GJNPosition, GJNPositionT } from './GJNPosition.js';
export { GJNProperty, GJNPropertyT } from './GJNProperty.js';
//# sourceMappingURL=main.d.ts.map