export declare enum GJNGeometryType {
    POINT = 0,
    MULTI_POINT = 1,
    LINE_STRING = 2,
    MULTI_LINE_STRING = 3,
    POLYGON = 4,
    MULTI_POLYGON = 5,
    GEOMETRY_COLLECTION = 6
}
//# sourceMappingURL=GJNGeometryType.d.ts.map