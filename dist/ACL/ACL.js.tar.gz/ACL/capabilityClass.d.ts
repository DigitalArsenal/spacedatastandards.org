/**
 * Capability class of a distributable software unit (module, application, or
 * composed flow).
 *
 * This enum IS the ratified category vocabulary. A storefront, library, module
 * manifest and search surface all classify against these members and nothing
 * else; a category that is not a member here does not exist. Members name
 * CAPABILITY CLASSES only — what the unit DOES. No member names a vendor,
 * site, organization, product, protocol brand or algorithm implementation;
 * that identity belongs in data fields such as PLG.PUBLISHER_NAME, never in
 * the taxonomy.
 *
 * Ordinals are wire values: APPEND ONLY. Never reorder, never remove, never
 * reuse an ordinal. A reorder silently re-labels every published listing.
 *
 * UNSPECIFIED deliberately holds ordinal 0 so that a zero-filled or
 * default-constructed classification can never decode as a real category. The
 * pre-existing `pluginCategory` enum in $PLG made the opposite choice — its
 * ordinal 0 is a real family — and had to append an `Unspecified` member at
 * the tail to recover. This enum does not repeat that.
 *
 * Each member's canonical display name is stated in its doc comment and is
 * part of the ratified contract: a consumer rendering a category label uses
 * that string verbatim, so every surface spells a category identically. The
 * canonical route slug is the member identifier lowercased with `_` replaced
 * by `-` (PROPAGATION -> "propagation", RF_AND_COMMUNICATIONS ->
 * "rf-and-communications").
 */
export declare enum capabilityClass {
    /**
     * No capability class stated. The publisher did not classify the unit.
     * A consumer MUST render an UNSPECIFIED unit as ungrouped and MUST NOT
     * infer a class from the unit's name, description or tags.
     * Display name: "Unspecified".
     */
    UNSPECIFIED = 0,
    /**
     * Advancing an object's state forward or backward in time under a force
     * model, and interpolating between computed states.
     * Display name: "Propagation".
     */
    PROPAGATION = 1,
    /**
     * Estimating an object's state or model parameters by fitting to
     * observations or ephemerides.
     * Display name: "Orbit Determination".
     */
    ORBIT_DETERMINATION = 2,
    /**
     * Planning, targeting and optimizing trajectory changes, including
     * station-keeping, transfers and collision-avoidance maneuvers.
     * Display name: "Maneuver Planning".
     */
    MANEUVER_PLANNING = 3,
    /**
     * Screening for close approaches between objects and quantifying collision
     * probability and miss distance.
     * Display name: "Conjunction Assessment".
     */
    CONJUNCTION_ASSESSMENT = 4,
    /**
     * Atmospheric reentry, decay prediction, fragmentation and debris-cloud
     * evolution.
     * Display name: "Reentry & Breakup".
     */
    REENTRY_AND_BREAKUP = 5,
    /**
     * Attitude determination and control, body orientation, and pointing or
     * slew planning.
     * Display name: "Attitude & Pointing".
     */
    ATTITUDE_AND_POINTING = 6,
    /**
     * Coordinate frame realization and transformation, time scale conversion,
     * and earth-orientation parameter handling.
     * Display name: "Reference Frames & Time".
     */
    REFERENCE_FRAMES_AND_TIME = 7,
    /**
     * Sensor modelling and tasking, field-of-regard and access computation, and
     * area or target coverage figures of merit.
     * Display name: "Sensors & Coverage".
     */
    SENSORS_AND_COVERAGE = 8,
    /**
     * Producing, correlating or associating observations of tracked objects,
     * and maintaining tracks from them.
     * Display name: "Tracking & Observation".
     */
    TRACKING_AND_OBSERVATION = 9,
    /**
     * Radio-frequency link modelling, emitter and band characterization, signal
     * capture handling, and communications planning.
     * Display name: "RF & Communications".
     */
    RF_AND_COMMUNICATIONS = 10,
    /**
     * Interference, jamming, spoofing and countermeasure modelling.
     * Display name: "Electronic Warfare".
     */
    ELECTRONIC_WARFARE = 11,
    /**
     * Atmospheric density, gravity field, magnetic field, radiation, solar and
     * geomagnetic activity, and ionospheric modelling.
     * Display name: "Space Environment".
     */
    SPACE_ENVIRONMENT = 12,
    /**
     * Acquiring bytes from upstream providers and parsing or exporting them
     * across canonical record formats.
     * Display name: "Data Sources & Ingest".
     */
    DATA_SOURCES_AND_INGEST = 13,
    /**
     * Validating records for integrity, physical plausibility, continuity and
     * schema conformance, and scoring data quality.
     * Display name: "Data Validation & Quality".
     */
    DATA_VALIDATION_AND_QUALITY = 14,
    /**
     * Object catalogue curation, cross-identifier resolution, bus and physical
     * property association, and entity identity.
     * Display name: "Catalog & Identity".
     */
    CATALOG_AND_IDENTITY = 15,
    /**
     * Rendering, scene composition, shading and interactive display of space
     * data.
     * Display name: "Visualization & Rendering".
     */
    VISUALIZATION_AND_RENDERING = 16,
    /**
     * Ground station operation and control of physical equipment, including
     * antenna rotators, radios and other hardware interfaces.
     * Display name: "Ground Segment & Hardware".
     */
    GROUND_SEGMENT_AND_HARDWARE = 17,
    /**
     * Mission and constellation design, trade studies, performance analysis and
     * report generation.
     * Display name: "Mission Design & Analysis".
     */
    MISSION_DESIGN_AND_ANALYSIS = 18,
    /**
     * Composition of other units into a graph. The unit of distribution is a
     * flow of modules, not a leaf algorithm.
     * Display name: "Flows & Composition".
     */
    FLOW_AND_COMPOSITION = 19,
    /**
     * Persisting, indexing and querying records; storage engines and query
     * surfaces.
     * Display name: "Data Storage & Query".
     */
    DATA_STORAGE_AND_QUERY = 20,
    /**
     * Key custody, signing and verification, authentication, authorization and
     * access control.
     * Display name: "Security & Identity".
     */
    SECURITY_AND_IDENTITY = 21,
    /**
     * Listing, purchase, subscription, entitlement and license enforcement for
     * distributed units.
     * Display name: "Commerce & Licensing".
     */
    COMMERCE_AND_LICENSING = 22,
    /**
     * Node runtime, artifact delivery, registry, publication and peer transport
     * plumbing.
     * Display name: "Node Infrastructure".
     */
    NODE_INFRASTRUCTURE = 23,
    /**
     * Foundational mathematics and general-purpose utility libraries consumed by
     * other units rather than run on their own.
     * Display name: "Foundation & Math".
     */
    FOUNDATION_AND_MATH = 24
}
//# sourceMappingURL=capabilityClass.d.ts.map