/**
 * Assignment (ASG)
 * Description
 * A linear assignment problem and its solution, and the association of
 * measurements with predicted objects that such a solution decides. The
 * problem is a cost matrix between rows (measurements, observations, tracks,
 * tasks) and columns (tracks, catalog objects, sensors, resources), given
 * dense or as sparse entries, with an optional cost for leaving a row
 * unassigned; the solution is the minimum-cost assignment of at most one
 * column per row and one row per column. This is the global-nearest-neighbour
 * step of measurement-to-track association, of observation-to-object
 * correlation and of any task allocation.
 *
 * The association part records how a set of observations ($RDO, $EOO, $RFO or
 * any other measurement record) was tested against predicted objects (for
 * example $OEM with covariance): each observation's measurements and sigmas,
 * its chi-square gate, every candidate object with its Mahalanobis distance
 * d2 = r' inv(S) r on the innovation covariance S = H P H' + R, the p-value,
 * the posterior association probability and the residuals, and the outcome
 * (associated or uncorrelated, ambiguous or not). The observation records
 * themselves keep their own standards; an ASG is the evidence beside them.
 *
 * One ASG carries one of: a problem, a solution, association options or an
 * association report. Units: km, km/s and degrees for measurements and
 * geometry; costs in the caller's unit.
 * Whether the problem minimizes or maximizes the total cost. Append new values
 * only; never reorder or reuse existing values.
 */
export declare enum asgObjective {
    /**
     * Minimize the sum of the assigned costs (the usual form).
     */
    Minimize = 0,
    /**
     * Maximize the sum of the assigned costs (a score or likelihood matrix).
     */
    Maximize = 1
}
//# sourceMappingURL=asgObjective.d.ts.map