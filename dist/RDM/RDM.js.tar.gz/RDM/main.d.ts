export { RDM, RDMT } from './RDM.js';
//# sourceMappingURL=main.d.ts.map