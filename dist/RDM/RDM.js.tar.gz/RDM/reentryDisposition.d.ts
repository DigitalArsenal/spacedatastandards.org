export declare enum reentryDisposition {
    CONTROLLED = 0,
    UNCONTROLLED = 1,
    SEMI_CONTROLLED = 2
}
//# sourceMappingURL=reentryDisposition.d.ts.map