export { BMC, BMCT } from './BMC.js';
//# sourceMappingURL=main.d.ts.map