export declare enum gnssConstellation {
    GPS = 0,
    GLONASS = 1,
    GALILEO = 2,
    BEIDOU = 3,
    QZSS = 4,
    IRNSS = 5,
    SBAS = 6,
    MIXED = 7
}
//# sourceMappingURL=gnssConstellation.d.ts.map