export declare enum gnssObsType {
    PSEUDORANGE = 0,
    CARRIER_PHASE = 1,
    DOPPLER = 2,
    SNR = 3,
    RAW_IF = 4
}
//# sourceMappingURL=gnssObsType.d.ts.map