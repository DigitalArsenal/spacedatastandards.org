export { OOL, OOLT } from './OOL.js';
//# sourceMappingURL=main.d.ts.map