/**
 * The quantity a series carries. Units are fixed per value. Append only.
 */
export declare enum swsQuantity {
    /**
     * QUANTITY_NAME and UNITS carry the source's own quantity.
     */
    Unspecified = 0,
    /**
     * Interplanetary magnetic field magnitude (Bt), nT.
     */
    ImfMagnitude = 1,
    /**
     * IMF component along REFERENCE_FRAME's X, Y, Z axis, nT.
     */
    ImfX = 2,
    ImfY = 3,
    ImfZ = 4,
    /**
     * IMF longitude (phi) in REFERENCE_FRAME, degrees, 0 to 360.
     */
    ImfLongitude = 5,
    /**
     * IMF latitude (theta) in REFERENCE_FRAME, degrees, -90 to 90.
     */
    ImfLatitude = 6,
    /**
     * Bulk proton speed, km/s.
     */
    ProtonSpeed = 7,
    /**
     * Proton bulk velocity along REFERENCE_FRAME's X, Y, Z axis, km/s.
     */
    ProtonVelocityX = 8,
    ProtonVelocityY = 9,
    ProtonVelocityZ = 10,
    /**
     * Proton number density, cm^-3.
     */
    ProtonDensity = 11,
    /**
     * Proton temperature, K.
     */
    ProtonTemperature = 12,
    /**
     * Alpha-particle speed (km/s), density (cm^-3), temperature (K).
     */
    AlphaSpeed = 13,
    AlphaDensity = 14,
    AlphaTemperature = 15,
    /**
     * Flow pressure, nPa.
     */
    FlowPressure = 16,
    /**
     * Solar wind electric field, mV/m.
     */
    ElectricField = 17,
    /**
     * Plasma beta, dimensionless.
     */
    PlasmaBeta = 18,
    /**
     * Alfven Mach number, dimensionless.
     */
    AlfvenMachNumber = 19,
    /**
     * Planetary Kp in decimal thirds (8.333 is 8+), 0 to 9.
     */
    Kp = 20,
    /**
     * Planetary ap for the sample's interval, ap units (2 nT).
     */
    Ap = 21,
    /**
     * Hpo index (Hp30 or Hp60 by CADENCE_S), open-ended, in decimal thirds.
     */
    Hpo = 22,
    /**
     * apo for the same interval, ap units.
     */
    Apo = 23,
    /**
     * Disturbance storm time index, nT.
     */
    Dst = 24,
    /**
     * SYM-H, SYM-D, ASY-H, ASY-D, nT.
     */
    SymH = 25,
    SymD = 26,
    AsyH = 27,
    AsyD = 28,
    /**
     * Auroral electrojet indices AE, AL, AU, AO, nT.
     */
    Ae = 29,
    Al = 30,
    Au = 31,
    Ao = 32,
    /**
     * Polar cap index, north and south, mV/m.
     */
    PcNorth = 33,
    PcSouth = 34,
    /**
     * Soft X-ray irradiance in PASSBAND_MIN_NM..PASSBAND_MAX_NM, W/m^2.
     */
    XrayFlux = 35,
    /**
     * The same before the source's electron correction, W/m^2.
     */
    XrayFluxUncorrected = 36,
    /**
     * Integral proton flux above ENERGY_MIN_MEV, pfu (cm^-2 s^-1 sr^-1).
     */
    ProtonIntegralFlux = 37,
    /**
     * Integral electron flux above ENERGY_MIN_MEV, pfu.
     */
    ElectronIntegralFlux = 38,
    /**
     * Differential proton flux in ENERGY_MIN_MEV..ENERGY_MAX_MEV,
     * cm^-2 s^-1 sr^-1 MeV^-1.
     */
    ProtonDifferentialFlux = 39,
    /**
     * 10.7 cm solar radio flux as observed (sfu) and adjusted to 1 AU (sfu).
     */
    F107Observed = 40,
    F107Adjusted = 41,
    /**
     * Hemispheric auroral power, GW.
     */
    HemisphericPower = 42
}
//# sourceMappingURL=swsQuantity.d.ts.map