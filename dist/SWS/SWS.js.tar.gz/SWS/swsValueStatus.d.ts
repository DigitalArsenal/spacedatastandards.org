/**
 * How final a value is. Append only.
 */
export declare enum swsValueStatus {
    Unspecified = 0,
    /**
     * Real-time, unedited (e.g. SWPC RTSW).
     */
    RealTime = 1,
    /**
     * Estimated from a partial network (e.g. SWPC estimated Kp).
     */
    Estimated = 2,
    /**
     * Quicklook (e.g. Kyoto real-time Dst).
     */
    Quicklook = 3,
    Nowcast = 4,
    Provisional = 5,
    Definitive = 6,
    /**
     * Issued forecast; FORECAST_ISSUED_AT is its issue time.
     */
    Predicted = 7,
    /**
     * Output of a model run named in MODEL_RUN_ID (e.g. WSA-ENLIL).
     */
    Modeled = 8
}
//# sourceMappingURL=swsValueStatus.d.ts.map