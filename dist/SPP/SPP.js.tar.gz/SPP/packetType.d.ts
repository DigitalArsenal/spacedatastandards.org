export declare enum packetType {
    TM = 0,
    TC = 1
}
//# sourceMappingURL=packetType.d.ts.map