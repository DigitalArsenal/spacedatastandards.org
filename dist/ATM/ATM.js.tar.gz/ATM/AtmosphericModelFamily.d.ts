/**
 * Canonical list of atmosphere model families per CCSDS SANA registry.
 * Use the `YEAR` field in the ATM message to specify the variant implementation.
 */
export declare enum AtmosphericModelFamily {
    /**
     * OID: 1.3.112.4.57.9.1
     * COSPAR International Reference Atmosphere
     * Known years: 1965, 1972, 1986, 1990
     */
    CIRA_XX = 0,
    /**
     * OID: 1.3.112.4.57.9.2
     * Drag Temperature Model
     * Known years: 1978, 1994, 2000, 2009, 2012, 2013, 2020
     */
    DTM_XX = 1,
    /**
     * OID: 1.3.112.4.57.9.3
     * Global Ionosphere-Thermosphere Model
     * GITM has no specific year versions defined
     */
    GITM = 2,
    /**
     * OID: 1.3.112.4.57.9.4
     * GOST atmospheric density model
     * Known version: 2004 (GOST R 25645.166-2004)
     */
    GOST = 3,
    /**
     * OID: 1.3.112.4.57.9.5
     * Global Reference Atmospheric Model
     * Known version: 2016
     */
    GRAM_XX = 4,
    /**
     * OID: 1.3.112.4.57.9.6
     * Harris-Priester empirical model
     * Known version: 1962
     */
    HP = 5,
    /**
     * OID: 1.3.112.4.57.9.7
     * Jacchia atmosphere model with HASDM correction overlay
     * Based on Jacchia 1970 with HASDM (DCA) overlay
     */
    JAC_HASDM = 6,
    /**
     * OID: 1.3.112.4.57.9.8
     * Jacchia-Gill bi-polynomial interpolation
     * Interpolates Jacchia 1971
     */
    JAC_GILL = 7,
    /**
     * OID: 1.3.112.4.57.9.9
     * Jacchia-Bowman empirical model
     * Known versions: 2006 (JB2006), 2008 (JB2008)
     */
    JB08 = 8,
    /**
     * OID: 1.3.112.4.57.9.10
     * Jacchia-Roberts analytic model
     * Known version: 1971
     */
    JR71 = 9,
    /**
     * OID: 1.3.112.4.57.9.11
     * Jacchia static diffusion models
     * Known years: 1970, 1971, 1977
     */
    JXX = 10,
    /**
     * OID: 1.3.112.4.57.9.12
     * Marshall Engineering Thermosphere
     * Known version: 2007
     */
    MET_XX = 11,
    /**
     * OID: 1.3.112.4.57.9.13
     * MSIS empirical model
     * Known version: 1986
     */
    MSIS_86 = 12,
    /**
     * OID: 1.3.112.4.57.9.14
     * MSISE empirical model with exosphere extension
     * Known version: 1990
     */
    MSISE_90 = 13,
    /**
     * OID: 1.3.112.4.57.9.15
     * NRLMSISE empirical model
     * Known version: 2000 (NRLMSISE-00E)
     */
    NRLMSIS00E = 14,
    /**
     * OID: 1.3.112.4.57.9.16
     * Thermosphere-Ionosphere Electrodynamic General Circulation Model
     * Based on TIME-GCM, no version specified
     */
    TIECGM = 15,
    /**
     * OID: 1.3.112.4.57.9.17
     * U.S. Standard Atmosphere
     * Known versions: 1962, 1976
     */
    USSA_XX = 16
}
//# sourceMappingURL=AtmosphericModelFamily.d.ts.map