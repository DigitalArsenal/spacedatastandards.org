export { ATM, ATMT } from './ATM.js';
export { AtmosphericModelFamily } from './AtmosphericModelFamily.js';
//# sourceMappingURL=main.d.ts.map