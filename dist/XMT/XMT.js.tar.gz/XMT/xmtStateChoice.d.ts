/**
 * Outcome of the orbital-state source choice for one object. Append new
 * values only; never reorder or reuse existing values.
 */
export declare enum xmtStateChoice {
    /**
     * Not decided.
     */
    Unspecified = 0,
    /**
     * A state candidate within the maximum age was selected.
     */
    Selected = 1,
    /**
     * No state sources configured.
     */
    Unconfigured = 2,
    /**
     * The configured sources' newest states are older than the maximum age.
     */
    Stale = 3,
    /**
     * The configured sources have only states after the as-of time.
     */
    Future = 4,
    /**
     * No configured source has a state for the object.
     */
    Missing = 5,
    /**
     * Exactly one source declares coverage of the object (or an override
     * chose one).
     */
    Covered = 6,
    /**
     * Several sources declare coverage and none was chosen.
     */
    Overlap = 7
}
//# sourceMappingURL=xmtStateChoice.d.ts.map