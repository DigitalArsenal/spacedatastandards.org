export declare enum pcfGravitySelection {
    INFER_FLAGS = 0,
    POINT_MASS = 1,
    J2_ONLY = 2,
    J2_TO_J4 = 3,
    SPHERICAL_HARMONICS = 4,
    EGM2008 = 5,
    /**
     * NGA EGM96 (Lemoine et al. 1998, NASA/TP-1998-206861), tide-free.
     */
    EGM96 = 6,
    /**
     * GRGM660PRIM (Lemoine et al. 2013, J. Geophys. Res. Planets 118), the
     * Moon's field, in the Moon's principal-axis frame.
     */
    GRGM660PRIM = 7,
    /**
     * MRO120F (Konopliv et al. 2020, Geophys. Res. Lett. 47,
     * doi:10.1029/2020GL090568), the Mars field, in the Mars-fixed frame of
     * its PDS label.
     */
    MRO120F = 8
}
//# sourceMappingURL=pcfGravitySelection.d.ts.map