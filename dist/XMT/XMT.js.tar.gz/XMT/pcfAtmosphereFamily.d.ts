export declare enum pcfAtmosphereFamily {
    UNSPECIFIED = 0,
    NRLMSISE00 = 1,
    EXPONENTIAL = 2,
    USSA1976 = 3,
    HARRIS_PRIESTER = 4,
    /**
     * Jacchia-Roberts (Roberts, Celestial Mechanics 4, 1971): the closed-form
     * evaluation of Jacchia's static diffusion model with the constants NASA
     * GTDS and GMAT use (inflection temperature, mean molecular mass and
     * 100 km composition of Jacchia 1971, SAO SR 332; ATM's JR71). The drivers:
     * F10.7 of the previous day, that day's 81-day centred average, and the
     * three-hour Kp 6.7 h earlier (PRW.SPACE_WEATHER, or WEATHER's values held
     * constant). A VCM's JACCHIA_70 is carried here.
     */
    JACCHIA_ROBERTS = 5,
    /**
     * Jacchia-Bowman 2008 (Bowman et al., AIAA 2008-6438): solar indices and
     * Dst-derived temperature change from the request's JB2008 indices.
     */
    JB2008 = 6,
    /**
     * Banded exponential atmosphere of Mars: the density falls as
     * exp(-(h - h0) / H) through altitude bands (Vallado, Fundamentals of
     * Astrodynamics and Applications, 4th ed., section 8.6), and it co-rotates
     * with Mars.
     */
    MARS_EXPONENTIAL = 7
}
//# sourceMappingURL=pcfAtmosphereFamily.d.ts.map