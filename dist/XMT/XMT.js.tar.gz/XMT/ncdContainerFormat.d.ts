/**
 * Native container format class.
 *
 * These are FORMAT designations, not products: each names a published or
 * widely implemented container layout, and a capability description states
 * what the layout can express. Reserve 0 so an unset byte never decodes as a
 * real format. Append new members only; never reorder or reuse a value.
 */
export declare enum ncdContainerFormat {
    UNSPECIFIED = 0,
    /**
     * Double-precision Array File container carrying Spacecraft and Planet
     * Kernel segments: a binary file of typed, independently addressed
     * ephemeris segments, each with an integer target and centre, an integer
     * reference frame, a numeric segment type, and a contiguous address range
     * inside the file.
     */
    SPK_DAF = 1,
    /**
     * SP3 version c: fixed-column text container of per-epoch satellite
     * positions and optional velocities with a clock column, a header block of
     * accuracy codes, and one uniform epoch interval.
     */
    SP3_C = 2,
    /**
     * SP3 version d: as SP3_C, with an unbounded satellite count and extended
     * header lines.
     */
    SP3_D = 3,
    /**
     * Code-500 fixed-record binary ephemeris: a header record of packed words
     * followed by fixed-length data records on a uniform step.
     */
    CODE_500 = 4,
    /**
     * Scenario-epoch ephemeris text container: time-ordered position and
     * velocity records whose epochs are offsets in seconds from a declared
     * scenario epoch, qualified by a named coordinate system, a distance unit,
     * a named interpolation method and an interpolation order.
     */
    SCENARIO_EPOCH_EPHEMERIS_TEXT = 5,
    /**
     * Scenario-epoch attitude text container: the attitude counterpart of
     * SCENARIO_EPOCH_EPHEMERIS_TEXT, carrying quaternion, Euler or angular
     * velocity records against the same scenario epoch.
     */
    SCENARIO_EPOCH_ATTITUDE_TEXT = 6,
    /**
     * CCSDS Orbit Ephemeris Message, keyword-value notation.
     */
    CCSDS_OEM_KVN = 7,
    /**
     * CCSDS Orbit Ephemeris Message, XML.
     */
    CCSDS_OEM_XML = 8,
    /**
     * CCSDS Attitude Ephemeris Message, keyword-value notation.
     */
    CCSDS_AEM_KVN = 9,
    /**
     * CCSDS Attitude Ephemeris Message, XML.
     */
    CCSDS_AEM_XML = 10,
    /**
     * CCSDS Tracking Data Message, keyword-value notation.
     */
    CCSDS_TDM_KVN = 11,
    /**
     * CCSDS Tracking Data Message, XML.
     */
    CCSDS_TDM_XML = 12,
    /**
     * CCSDS Orbit Mean-Elements Message, keyword-value notation.
     */
    CCSDS_OMM_KVN = 13,
    /**
     * CCSDS Orbit Mean-Elements Message, XML.
     */
    CCSDS_OMM_XML = 14,
    /**
     * CCSDS Orbit Parameter Message, keyword-value notation.
     */
    CCSDS_OPM_KVN = 15,
    /**
     * CCSDS Orbit Parameter Message, XML.
     */
    CCSDS_OPM_XML = 16,
    /**
     * CCSDS Orbit Comprehensive Message, keyword-value notation.
     */
    CCSDS_OCM_KVN = 17,
    /**
     * CCSDS Orbit Comprehensive Message, XML.
     */
    CCSDS_OCM_XML = 18,
    /**
     * CCSDS Conjunction Data Message, keyword-value notation.
     */
    CCSDS_CDM_KVN = 19,
    /**
     * CCSDS Conjunction Data Message, XML.
     */
    CCSDS_CDM_XML = 20,
    /**
     * CCSDS Attitude Parameter Message, keyword-value notation.
     */
    CCSDS_APM_KVN = 21,
    /**
     * CCSDS Attitude Parameter Message, XML.
     */
    CCSDS_APM_XML = 22,
    /**
     * CCSDS Attitude Comprehensive Message, keyword-value notation.
     */
    CCSDS_ACM_KVN = 23,
    /**
     * CCSDS Attitude Comprehensive Message, XML.
     */
    CCSDS_ACM_XML = 24,
    /**
     * CCSDS Reentry Data Message, keyword-value notation.
     */
    CCSDS_RDM_KVN = 25,
    /**
     * CCSDS Reentry Data Message, XML.
     */
    CCSDS_RDM_XML = 26,
    /**
     * ESA Earth Explorer orbit file in XML (Sentinel-1, -2 and -3 AUX_POEORB,
     * AUX_RESORB and AUX_PREORB).
     */
    SENTINEL_EOF_XML = 27,
    /**
     * NAIF C-kernel: a DAF holding pointing (attitude) segments.
     */
    NAIF_CK_DAF = 28,
    /**
     * NAIF spacecraft clock kernel, text.
     */
    NAIF_SCLK_KERNEL = 29,
    /**
     * RINEX observation file.
     */
    RINEX_OBS = 30,
    /**
     * RINEX navigation file.
     */
    RINEX_NAV = 31,
    /**
     * NAIF binary Planetary Constants Kernel: a DAF holding body orientation as
     * Chebyshev segments (data types 2, 3 and 20), with no size or shape data;
     * e.g. the Moon's principal-axis frame in moon_pa_de440_*.bpc (NAIF, PCK
     * Required Reading).
     */
    PCK_DAF = 32,
    /**
     * A container outside this roster. PROVIDER_DEFINED_FORMAT_NAME states
     * which; a producer never reuses a neighbouring member instead.
     */
    PROVIDER_DEFINED = 255
}
//# sourceMappingURL=ncdContainerFormat.d.ts.map