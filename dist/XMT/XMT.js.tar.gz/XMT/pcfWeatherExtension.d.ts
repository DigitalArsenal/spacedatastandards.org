export declare enum pcfWeatherExtension {
    /**
     * The provider's own rule (the numerical propagator refuses, the advanced
     * mean-element propagator chains forecasts).
     */
    UNSPECIFIED = 0,
    /**
     * Refuse an arc that reaches past the rows (space-weather-out-of-range).
     */
    REFUSE = 1,
    /**
     * Hold the last row's values.
     */
    HOLD_LAST = 2,
    /**
     * Observed rows, then the three-day forecast, then the 45-day forecast,
     * then the solar-cycle climatology; each hand-off is blended over one day
     * and every evaluation names its tier.
     */
    FORECAST_CHAIN = 3
}
//# sourceMappingURL=pcfWeatherExtension.d.ts.map