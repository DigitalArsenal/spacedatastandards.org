/**
 * Node Event (NEV)
 * Description
 * Things that happened on a node, as an event log an operator or another
 * service can follow: peers connecting and leaving, records published and
 * stored, grants issued, services starting and stopping, warnings and
 * failures. Each event says when it happened, what kind it is, which peer or
 * subject it concerns and a short detail; a set carries the events of one
 * read, newest first, with the total the node holds.
 *
 * NEV is an operational log, not an alerting or conjunction product: it
 * records what the node did and saw, so an operator can answer "what happened
 * on this node, and when?".
 * Kind of event. Append new values only; never reorder or reuse existing
 * values.
 */
export declare enum nevEventKind {
    /**
     * Not classified; DETAIL says what it was.
     */
    Other = 0,
    /**
     * A peer connected.
     */
    PeerConnected = 1,
    /**
     * A peer disconnected.
     */
    PeerDisconnected = 2,
    /**
     * The node published a notice of new data (a $PNM).
     */
    PublicationSent = 3,
    /**
     * The node received a notice of new data from a peer.
     */
    PublicationReceived = 4,
    /**
     * Records were stored.
     */
    RecordsStored = 5,
    /**
     * Records were deleted (retention, expiry or an operator).
     */
    RecordsDeleted = 6,
    /**
     * An access or capability grant was issued.
     */
    GrantIssued = 7,
    /**
     * An access or capability grant was revoked or expired.
     */
    GrantRevoked = 8,
    /**
     * A service or module started.
     */
    ServiceStarted = 9,
    /**
     * A service or module stopped.
     */
    ServiceStopped = 10,
    /**
     * A condition worth an operator's attention.
     */
    Warning = 11,
    /**
     * An operation failed.
     */
    Failure = 12
}
//# sourceMappingURL=nevEventKind.d.ts.map