/**
 * Dataset Availability (DAV)
 * Description
 * Whether a node can serve the latest published dataset of a lane (a
 * standard, provider and source), and if so which one: the batch, how big it
 * is, when it was published, the notice that announced it and whether that
 * notice verified, and whether the node's copy is current, held locally and
 * kept (pinned). A client asks before fetching, or reads it beside the
 * dataset, so it can tell a current dataset from a stale one and a verified
 * one from an unverified one.
 *
 * DAV describes a dataset; it does not carry it. The dataset's records travel
 * beside it in their own standard (or as a $REC collection when one answer
 * mixes standards).
 * Why a dataset is not available. Append new values only; never reorder or
 * reuse existing values.
 */
export declare enum davUnavailableReason {
    /**
     * The dataset is available.
     */
    None = 0,
    /**
     * No publication of the lane is known.
     */
    NotPublished = 1,
    /**
     * A publication is known but its content is not held.
     */
    NotHeld = 2,
    /**
     * The content is held but older than the latest known publication.
     */
    Stale = 3,
    /**
     * The notice did not verify.
     */
    Unverified = 4,
    /**
     * The caller may not read it.
     */
    NotEntitled = 5
}
//# sourceMappingURL=davUnavailableReason.d.ts.map