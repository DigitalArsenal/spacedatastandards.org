/**
 * Aggregation Result (AGR)
 * Description
 * A server-computed summary over one standard's records so charts, pivots,
 * timelines and catalogue tallies are one frame computed in one pass over
 * every record in the selection, never a client-side scan. A histogram bins a
 * numeric or time field; a category tally counts distinct values; a series
 * carries parallel X and Y vectors per named series (time or numeric X); a
 * scatter is a series without ordering; a pivot tallies a row key against a
 * column key. The frame states what was scanned and whether the scan was
 * bounded, exactly as a Query Page does.
 * Shape of the aggregate. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum agrKind {
    Histogram = 0,
    Category = 1,
    Series = 2,
    Scatter = 3,
    Pivot = 4
}
//# sourceMappingURL=agrKind.d.ts.map