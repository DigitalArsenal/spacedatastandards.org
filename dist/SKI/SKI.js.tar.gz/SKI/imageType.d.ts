export declare enum imageType {
    VISIBLE = 0,
    INFRARED = 1,
    MULTISPECTRAL = 2,
    HYPERSPECTRAL = 3,
    UV = 4,
    BROADBAND = 5
}
//# sourceMappingURL=imageType.d.ts.map