export { DataType } from './DataType.js';
export { EOP, EOPT } from './EOP.js';
export { EOPCOLLECTION, EOPCOLLECTIONT } from './EOPCOLLECTION.js';
//# sourceMappingURL=main.d.ts.map