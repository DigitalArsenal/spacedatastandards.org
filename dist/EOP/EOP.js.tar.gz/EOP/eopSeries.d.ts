/**
 * Published Earth-orientation series a row was taken from. Append new values
 * only; never reorder or reuse existing values.
 */
export declare enum eopSeries {
    UNSPECIFIED = 0,
    /**
     * IERS EOP 14 C04, the long-term combined solution (e.g.
     * eopc04_14_IAU2000.62-now.txt).
     */
    IERS_C04_14 = 1,
    /**
     * IERS EOP 20 C04, the ITRF2020-based combined solution.
     */
    IERS_C04_20 = 2,
    /**
     * IERS Bulletin A rapid service / prediction.
     */
    IERS_BULLETIN_A = 3,
    /**
     * IERS Bulletin B.
     */
    IERS_BULLETIN_B = 4,
    /**
     * USNO/IERS finals2000A combined rapid + prediction file.
     */
    FINALS2000A = 5,
    /**
     * A series not covered above; identify it in a producer-defined way.
     */
    OTHER = 6
}
//# sourceMappingURL=eopSeries.d.ts.map