export declare enum DataType {
    OBSERVED = 0,
    PREDICTED = 1
}
//# sourceMappingURL=DataType.d.ts.map