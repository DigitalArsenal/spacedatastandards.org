export declare enum StabilizationType {
    SPIN = 0,
    FIN = 1,
    DUAL = 2
}
//# sourceMappingURL=StabilizationType.d.ts.map