export declare enum PenetrationModel {
    DE_MARRE = 0,
    THOR = 1,
    ODERMATT = 2,
    ANDERSON = 3,
    BRL = 4
}
//# sourceMappingURL=PenetrationModel.d.ts.map