export declare enum ProjectileType {
    BALL = 0,
    HOLLOW_POINT = 1,
    BOAT_TAIL = 2,
    ARMOR_PIERCING = 3,
    ARMOR_PIERCING_INCENDIARY = 4,
    TRACER = 5,
    SABOT = 6,
    SUBCALIBER = 7,
    HEAT = 8,
    HESH = 9,
    HE = 10,
    APFSDS = 11,
    ARTILLERY_HE = 12,
    MORTAR = 13,
    GRENADE = 14,
    ROCKET = 15
}
//# sourceMappingURL=ProjectileType.d.ts.map