export declare enum BallisticModel {
    POINT_MASS_2D = 0,
    POINT_MASS_3D = 1,
    MODIFIED_POINT_MASS = 2,
    SIX_DOF = 3
}
//# sourceMappingURL=BallisticModel.d.ts.map