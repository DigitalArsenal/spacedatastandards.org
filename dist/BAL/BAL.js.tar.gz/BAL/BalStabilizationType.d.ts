export declare enum BalStabilizationType {
    SPIN = 0,
    FIN = 1,
    DUAL = 2
}
//# sourceMappingURL=BalStabilizationType.d.ts.map