export declare enum FusionMethod {
    SIMPLE_AVERAGE = 0,
    WEIGHTED_AVERAGE = 1,
    COVARIANCE_INTERSECTION = 2,
    BAR_SHALOM_CAMPO = 3,
    FEDERATED = 4,
    SEQUENTIAL = 5
}
//# sourceMappingURL=FusionMethod.d.ts.map