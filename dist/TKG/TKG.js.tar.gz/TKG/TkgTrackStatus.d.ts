export declare enum TkgTrackStatus {
    TENTATIVE = 0,
    CONFIRMED = 1,
    COASTING = 2,
    LOST = 3,
    DELETED = 4
}
//# sourceMappingURL=TkgTrackStatus.d.ts.map