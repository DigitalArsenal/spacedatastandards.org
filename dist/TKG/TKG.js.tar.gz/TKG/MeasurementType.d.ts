export declare enum MeasurementType {
    POSITION_3D = 0,
    POSITION_2D = 1,
    RANGE_BEARING = 2,
    RANGE_BEARING_ELEVATION = 3,
    RANGE_ONLY = 4,
    BEARING_ONLY = 5,
    RANGE_RATE = 6,
    ANGLES_ONLY = 7,
    TLE = 8,
    GPS = 9,
    RADAR = 10,
    ADSB = 11,
    SONAR = 12
}
//# sourceMappingURL=MeasurementType.d.ts.map