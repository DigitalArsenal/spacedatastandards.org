/**
 * Coarse envelope status for an invoke response. Per-method numeric
 * return codes travel in STATUS_CODE; STATUS categorizes the outcome
 * for host routing (retry, yield-and-resume, fail-closed) without the
 * host having to decode method-specific numbers.
 */
export declare enum pivStatus {
    /**
     * Invocation completed; STATUS_CODE carries the method-specific value.
     */
    OK = 0,
    /**
     * Method id not registered on the target plugin.
     */
    NOT_FOUND = 1,
    /**
     * Invocation succeeded but yielded before draining queued work.
     * Caller should inspect BACKLOG_REMAINING and re-invoke to continue.
     */
    YIELDED = 2,
    /**
     * Invocation failed; ERROR_CODE + ERROR_MESSAGE describe the failure.
     */
    FAILED = 3
}
//# sourceMappingURL=pivStatus.d.ts.map