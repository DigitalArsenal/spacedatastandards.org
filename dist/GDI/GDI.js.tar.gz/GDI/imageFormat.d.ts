export declare enum imageFormat {
    FITS = 0,
    JPEG = 1,
    PNG = 2,
    TIFF = 3,
    RAW = 4,
    NITF = 5,
    GEOTIFF = 6,
    OTHER = 7
}
//# sourceMappingURL=imageFormat.d.ts.map