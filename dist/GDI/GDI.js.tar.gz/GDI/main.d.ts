export { GDI, GDIT } from './GDI.js';
//# sourceMappingURL=main.d.ts.map