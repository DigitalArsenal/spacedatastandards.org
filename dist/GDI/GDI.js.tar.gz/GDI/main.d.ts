export { GDI, GDIT } from './GDI.js';
export { imageFormat } from './imageFormat.js';
//# sourceMappingURL=main.d.ts.map