/**
 * Broad feature class of a gazetteer place, as the consulted gazetteer
 * states it. A publisher encodes the class ITS SOURCE STATES and never
 * re-derives one from the place name, population, or geometry. The source's
 * own single-letter class token is retained verbatim in FEATURE_CLASS_CODE,
 * so a class this enum does not model is never lost. Ordinals are wire
 * values: append only; never reorder or reuse.
 */
export declare enum gnpFeatureClass {
    /**
     * Administrative boundary or political entity.
     */
    ADMINISTRATIVE = 0,
    /**
     * Hydrographic feature: stream, lake, sea, glacier, spring.
     */
    HYDROGRAPHIC = 1,
    /**
     * Area feature: park, reserve, oilfield, region.
     */
    AREA = 2,
    /**
     * Populated place: city, town, village, capital, section of a place.
     */
    POPULATED_PLACE = 3,
    /**
     * Road or railroad feature.
     */
    TRANSPORT = 4,
    /**
     * Spot feature: building, farm, facility, church, mine.
     */
    SPOT = 5,
    /**
     * Hypsographic feature: mountain, hill, rock, ridge, plain.
     */
    HYPSOGRAPHIC = 6,
    /**
     * Undersea feature: bank, ridge, trench, seamount.
     */
    UNDERSEA = 7,
    /**
     * Vegetation feature: forest, heath, grove.
     */
    VEGETATION = 8,
    /**
     * The gazetteer names a class this enum does not model, or publishes none.
     * FEATURE_CLASS defaults here so an unset field can never be read as
     * ADMINISTRATIVE, which holds ordinal 0. The source token, when there is
     * one, is still carried in FEATURE_CLASS_CODE.
     */
    UNSPECIFIED = 9
}
//# sourceMappingURL=gnpFeatureClass.d.ts.map