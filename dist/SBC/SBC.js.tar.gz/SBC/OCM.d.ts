import * as flatbuffers from 'flatbuffers';
import { CVR, CVRT } from './CVR.js';
import { Header, HeaderT } from './Header.js';
import { Maneuver, ManeuverT } from './Maneuver.js';
import { Metadata, MetadataT } from './Metadata.js';
import { OCMCovarianceBlock, OCMCovarianceBlockT } from './OCMCovarianceBlock.js';
import { OCMCovariancePropagation, OCMCovariancePropagationT } from './OCMCovariancePropagation.js';
import { OCMInspectionGeometry, OCMInspectionGeometryT } from './OCMInspectionGeometry.js';
import { OCMIntegrator, OCMIntegratorT } from './OCMIntegrator.js';
import { OCMMeanElements, OCMMeanElementsT } from './OCMMeanElements.js';
import { OCMRelativeGeometry, OCMRelativeGeometryT } from './OCMRelativeGeometry.js';
import { OCMSeedSet, OCMSeedSetT } from './OCMSeedSet.js';
import { OCMTrajectoryBlock, OCMTrajectoryBlockT } from './OCMTrajectoryBlock.js';
import { OrbitDetermination, OrbitDeterminationT } from './OrbitDetermination.js';
import { PPEOrbitalElementRecord, PPEOrbitalElementRecordT } from './PPEOrbitalElementRecord.js';
import { PPEPositionRecord, PPEPositionRecordT } from './PPEPositionRecord.js';
import { PVN, PVNT } from './PVN.js';
import { Perturbations, PerturbationsT } from './Perturbations.js';
import { PhysicalProperties, PhysicalPropertiesT } from './PhysicalProperties.js';
import { RFM, RFMT } from './RFM.js';
import { UserDefinedParameters, UserDefinedParametersT } from './UserDefinedParameters.js';
import { covarianceCalibration } from './covarianceCalibration.js';
import { covarianceOrdering } from './covarianceOrdering.js';
import { ocmTrajectoryBasis } from './ocmTrajectoryBasis.js';
import { prwDynamicParameter } from './prwDynamicParameter.js';
import { trajectoryType } from './trajectoryType.js';
/**
 * Orbit Comprehensive Message
 */
export declare class OCM implements flatbuffers.IUnpackableObject<OCMT> {
    bb: flatbuffers.ByteBuffer | null;
    bb_pos: number;
    __init(i: number, bb: flatbuffers.ByteBuffer): OCM;
    static getRootAsOCM(bb: flatbuffers.ByteBuffer, obj?: OCM): OCM;
    static getSizePrefixedRootAsOCM(bb: flatbuffers.ByteBuffer, obj?: OCM): OCM;
    static bufferHasIdentifier(bb: flatbuffers.ByteBuffer): boolean;
    /**
     * Header section of the OCM.
     */
    HEADER(obj?: Header): Header | null;
    /**
     * Metadata section of the OCM.
     */
    METADATA(obj?: Metadata): Metadata | null;
    /**
     * Trajectory state representation type.
     * Determines how orbit state data is parameterized in this message.
     * For CARTESIAN_PV/CARTESIAN_PVA, use STATE_DATA array.
     * For POLYNOMIAL_POS/POLYNOMIAL_OE, use the corresponding polynomial record arrays.
     */
    TRAJ_TYPE(): trajectoryType;
    /**
     * Legacy trajectory type string for backward compatibility and extended types
     * (e.g., "PROPAGATED", "ESTIMATED", "FILTERED").
     */
    TRAJ_TYPE_DESCRIPTION(): string | null;
    TRAJ_TYPE_DESCRIPTION(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Time interval between state vectors in seconds; required without STATE_EPOCHS.
     */
    STATE_STEP_SIZE(): number;
    /**
     * Number of components per state vector.
     * 6 = position + velocity (X, Y, Z, X_DOT, Y_DOT, Z_DOT)
     * 9 = position + velocity + acceleration (adds X_DDOT, Y_DDOT, Z_DDOT)
     * 6 or 7 for the element sets named by TRAJ_TYPE.
     */
    STATE_VECTOR_SIZE(): number;
    /**
     * State data as row-major array of doubles.
     * Layout: [X0, Y0, Z0, X_DOT0, Y_DOT0, Z_DOT0, X1, Y1, Z1, ...]
     * Time reconstruction uses STATE_EPOCHS when present, otherwise START_TIME + i * STATE_STEP_SIZE.
     * Length must be divisible by STATE_VECTOR_SIZE.
     * Units: km, km/s and km/s**2, in TRAJ_REF_FRAME about CENTER_NAME.
     * Empty when MEAN_ELEMENTS, RPO_GEOMETRY or RPO_INSPECTION is present.
     */
    STATE_DATA(index: number): number | null;
    stateDataLength(): number;
    stateDataArray(): Float64Array | null;
    /**
     * Covariance data as a flat array, one N x N matrix per epoch, N = COV_SIZE, aligned with the STATE_DATA epochs.
     * COV_ORDERING gives the values per epoch: N(N+1)/2 for LTM and UTM, N*N for FULL, LTMWCC and UTMWCC. Entry [i,j]
     * has the product of the units of state elements i and j (km**2, km**2/s, km**2/s**2 for a position-velocity
     * state), and of COV_UNITS for the parameter rows. Without COV_TYPE, COV_ORDERING and COV_SIZE: 21 elements per
     * epoch, the lower triangle of the 6x6 position and velocity covariance.
     */
    COVARIANCE_DATA(index: number): number | null;
    covarianceDataLength(): number;
    covarianceDataArray(): Float64Array | null;
    /**
     * Polynomial position records.
     * Used when TRAJ_TYPE is POLYNOMIAL_POS. Each record covers a time segment
     * with polynomial coefficients for X, Y, Z position (and optionally velocity).
     * See PPE schema for record structure and evaluation procedure.
     */
    POLYNOMIAL_POSITION_RECORDS(index: number, obj?: PPEPositionRecord): PPEPositionRecord | null;
    polynomialPositionRecordsLength(): number;
    /**
     * Polynomial orbital element records.
     * Used when TRAJ_TYPE is POLYNOMIAL_OE. Each record covers a time segment
     * with polynomial coefficients for classical orbital elements.
     * See PPE schema for record structure and evaluation procedure.
     */
    POLYNOMIAL_OE_RECORDS(index: number, obj?: PPEOrbitalElementRecord): PPEOrbitalElementRecord | null;
    polynomialOeRecordsLength(): number;
    /**
     * Physical properties of the space object.
     */
    PHYSICAL_PROPERTIES(obj?: PhysicalProperties): PhysicalProperties | null;
    /**
     * Maneuver data.
     */
    MANEUVER_DATA(index: number, obj?: Maneuver): Maneuver | null;
    maneuverDataLength(): number;
    /**
     * Perturbations parameters used.
     */
    PERTURBATIONS(obj?: Perturbations): Perturbations | null;
    /**
     * Orbit determination data.
     */
    ORBIT_DETERMINATION(obj?: OrbitDetermination): OrbitDetermination | null;
    /**
     * CCSDS 502.0-B-3 USER_DEFINED_x of a foreign message. SDN producers never write it and
     * SDN readers never read it.
     */
    USER_DEFINED_PARAMETERS(index: number, obj?: UserDefinedParameters): UserDefinedParameters | null;
    userDefinedParametersLength(): number;
    /**
     * Origin of TRAJ_REF_FRAME (EARTH, MOON, ...) (CCSDS 502.0-B-3 CENTER_NAME).
     */
    CENTER_NAME(): string | null;
    CENTER_NAME(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Reference frame of STATE_DATA and the polynomial records; for MEAN_ELEMENTS, the
     * frame of the elements (CCSDS 502.0-B-3 TRAJ_REF_FRAME).
     */
    TRAJ_REF_FRAME(obj?: RFM): RFM | null;
    /**
     * Epoch of TRAJ_REF_FRAME when it is not intrinsic to the frame
     * (CCSDS 502.0-B-3 TRAJ_FRAME_EPOCH).
     */
    TRAJ_FRAME_EPOCH(): string | null;
    TRAJ_FRAME_EPOCH(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Reference frame of COVARIANCE_DATA (CCSDS 502.0-B-3 COV_REF_FRAME). COV_REF_FRAME UVW is the frame of a
     * local-orbital covariance: U radial, V along-track, W cross-track, the velocity rows on the same axes.
     */
    COV_REF_FRAME(obj?: RFM): RFM | null;
    /**
     * Orbit revolution number at the first state (CCSDS 502.0-B-3 ORB_REVNUM).
     */
    ORB_REVNUM(): number;
    /**
     * For element sets: OSCULATING, or the mean-element theory used (BROUWER,
     * KOZAI, ...) (CCSDS 502.0-B-3 ORB_AVERAGING). Absent means OSCULATING.
     */
    ORB_AVERAGING(): string | null;
    ORB_AVERAGING(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Whether COVARIANCE_DATA's coverage was measured against independent
     * reference states: Calibrated only when every COV_REALISM entry is.
     */
    COV_CALIBRATION(): covarianceCalibration;
    /**
     * Identifier of that calibration evidence (a report or record).
     */
    COV_CALIBRATION_REFERENCE(): string | null;
    COV_CALIBRATION_REFERENCE(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Absolute epoch per STATE_DATA row in METADATA.TIME_SYSTEM (CCSDS 502.0-B-3
     * section 6.2.4). When nonempty, length equals STATE_DATA.length /
     * STATE_VECTOR_SIZE and these epochs override START_TIME + i * STATE_STEP_SIZE.
     * Absent or empty retains the uniform grid; COVARIANCE_DATA shares these epochs.
     */
    STATE_EPOCHS(index: number): string;
    STATE_EPOCHS(index: number, optionalEncoding: flatbuffers.Encoding): string | Uint8Array;
    stateEpochsLength(): number;
    /**
     * Element set of the state block of COVARIANCE_DATA (CCSDS 502.0-B-3 COV_TYPE): a SANA orbital element set
     * (CARTP, CARTPV, CARTPVA, ADBARV, KEPLERIAN, EQUINOCTIAL ...) or a covariance representation (SIG3EIGVEC3 and
     * TSIG3EIGVEC3 give 13 and 14 values per epoch whatever COV_SIZE says). Absent means CARTPV.
     */
    COV_TYPE(): string | null;
    COV_TYPE(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Order of the covariance values at each epoch (CCSDS 502.0-B-3 COV_ORDERING). COV_ORDERING LTM is the only ordering
     * the product writers (lib/js/PROD) accept.
     */
    COV_ORDERING(): covarianceOrdering;
    /**
     * Dimension N of the covariance matrix at each epoch: the rows of the state block (6 for CARTPV) plus the rows
     * COV_PARAMETERS names.
     */
    COV_SIZE(): number;
    /**
     * Names of the covariance rows after the state block, by their names in ORBIT_DETERMINATION.OD_DYNAMIC_PARAMETERS.
     * COV_PARAMETERS lists only the parameters the orbit determination solved for, in the fixed order DRAG_AREA_OVER_MASS,
     * DRAG_AREA_OVER_MASS_RATE, SRP_AREA_OVER_MASS, IN_TRACK_ACCELERATION, OUTGASSING_ACCELERATION (a VCM's B, BDOT, AGOM
     * and T are the first four): COV_SIZE - 6 entries, no row for a parameter the determination held.
     */
    COV_PARAMETERS(index: number): string;
    COV_PARAMETERS(index: number, optionalEncoding: flatbuffers.Encoding): string | Uint8Array;
    covParametersLength(): number;
    /**
     * Units of the standard deviation of each diagonal element (CCSDS 502.0-B-3 COV_UNITS): COV_UNITS has exactly
     * COV_SIZE entries, km and km/s for the state rows, then m**2/kg, m**2/kg/s, m**2/kg, m/s**2 and km/s**2 for the
     * parameter rows COV_PARAMETERS names; "n/a" for a dimensionless one.
     */
    COV_UNITS(index: number): string;
    COV_UNITS(index: number, optionalEncoding: flatbuffers.Encoding): string | Uint8Array;
    covUnitsLength(): number;
    /**
     * Every trajectory state time history of the message (CCSDS 502.0-B-3 TRAJ_START
     * blocks), in message order. TRAJ_TYPE, STATE_DATA and the fields that go with
     * them above state the first block's CARTPV or CARTPVA states.
     */
    TRAJECTORY_BLOCKS(index: number, obj?: OCMTrajectoryBlock): OCMTrajectoryBlock | null;
    trajectoryBlocksLength(): number;
    /**
     * Every covariance time history of the message (COV_START blocks), in message
     * order. COVARIANCE_DATA and the fields that go with it above state the first
     * block when it is one line.
     */
    COVARIANCE_BLOCKS(index: number, obj?: OCMCovarianceBlock): OCMCovarianceBlock | null;
    covarianceBlocksLength(): number;
    /**
     * Where the message's data comes from and the terms it travels under.
     */
    PROVENANCE(obj?: PVN): PVN | null;
    /**
     * Realism of COVARIANCE_DATA: one entry per epoch, in the order of the
     * STATE_DATA epochs, or one entry for every epoch.
     */
    COV_REALISM(index: number, obj?: CVR): CVR | null;
    covRealismLength(): number;
    /**
     * The mean element set this message carries, under the theory it names. STATE_DATA is
     * empty when this is present; no state travels beside a set.
     */
    MEAN_ELEMENTS(obj?: OCMMeanElements): OCMMeanElements | null;
    /**
     * What propagates COVARIANCE_DATA beyond its epoch (mean element sets).
     */
    COV_PROPAGATION(obj?: OCMCovariancePropagation): OCMCovariancePropagation | null;
    /**
     * The covariance rows after the state block, typed, in the order of COV_PARAMETERS:
     * every reader keys on these, never on the COV_PARAMETERS strings.
     */
    COV_PARAMETER_KINDS(index: number): prwDynamicParameter | null;
    covParameterKindsLength(): number;
    covParameterKindsArray(): Uint8Array | null;
    /**
     * Basis of the trajectory STATE_DATA states, the first block's TRAJ_BASIS
     * (CCSDS 502.0-B-3 TRAJ_BASIS).
     */
    TRAJ_BASIS(): ocmTrajectoryBasis;
    /**
     * The element sets the trajectory was computed from, one per object whose
     * elements it used.
     */
    SEED_SETS(index: number, obj?: OCMSeedSet): OCMSeedSet | null;
    seedSetsLength(): number;
    /**
     * Integrator settings of a solution made from a legacy VCM.
     */
    INTEGRATOR(obj?: OCMIntegrator): OCMIntegrator | null;
    /**
     * Relative-motion geometry; STATE_DATA is empty when this is present.
     */
    RPO_GEOMETRY(obj?: OCMRelativeGeometry): OCMRelativeGeometry | null;
    /**
     * Inspection geometry; STATE_DATA is empty when this is present.
     */
    RPO_INSPECTION(obj?: OCMInspectionGeometry): OCMInspectionGeometry | null;
    static startOCM(builder: flatbuffers.Builder): void;
    static addHeader(builder: flatbuffers.Builder, HEADEROffset: flatbuffers.Offset): void;
    static addMetadata(builder: flatbuffers.Builder, METADATAOffset: flatbuffers.Offset): void;
    static addTrajType(builder: flatbuffers.Builder, TRAJ_TYPE: trajectoryType): void;
    static addTrajTypeDescription(builder: flatbuffers.Builder, TRAJ_TYPE_DESCRIPTIONOffset: flatbuffers.Offset): void;
    static addStateStepSize(builder: flatbuffers.Builder, STATE_STEP_SIZE: number): void;
    static addStateVectorSize(builder: flatbuffers.Builder, STATE_VECTOR_SIZE: number): void;
    static addStateData(builder: flatbuffers.Builder, STATE_DATAOffset: flatbuffers.Offset): void;
    static createStateDataVector(builder: flatbuffers.Builder, data: number[] | Float64Array): flatbuffers.Offset;
    /**
     * @deprecated This Uint8Array overload will be removed in the future.
     */
    static createStateDataVector(builder: flatbuffers.Builder, data: number[] | Uint8Array): flatbuffers.Offset;
    static startStateDataVector(builder: flatbuffers.Builder, numElems: number): void;
    static addCovarianceData(builder: flatbuffers.Builder, COVARIANCE_DATAOffset: flatbuffers.Offset): void;
    static createCovarianceDataVector(builder: flatbuffers.Builder, data: number[] | Float64Array): flatbuffers.Offset;
    /**
     * @deprecated This Uint8Array overload will be removed in the future.
     */
    static createCovarianceDataVector(builder: flatbuffers.Builder, data: number[] | Uint8Array): flatbuffers.Offset;
    static startCovarianceDataVector(builder: flatbuffers.Builder, numElems: number): void;
    static addPolynomialPositionRecords(builder: flatbuffers.Builder, POLYNOMIAL_POSITION_RECORDSOffset: flatbuffers.Offset): void;
    static createPolynomialPositionRecordsVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startPolynomialPositionRecordsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addPolynomialOeRecords(builder: flatbuffers.Builder, POLYNOMIAL_OE_RECORDSOffset: flatbuffers.Offset): void;
    static createPolynomialOeRecordsVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startPolynomialOeRecordsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addPhysicalProperties(builder: flatbuffers.Builder, PHYSICAL_PROPERTIESOffset: flatbuffers.Offset): void;
    static addManeuverData(builder: flatbuffers.Builder, MANEUVER_DATAOffset: flatbuffers.Offset): void;
    static createManeuverDataVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startManeuverDataVector(builder: flatbuffers.Builder, numElems: number): void;
    static addPerturbations(builder: flatbuffers.Builder, PERTURBATIONSOffset: flatbuffers.Offset): void;
    static addOrbitDetermination(builder: flatbuffers.Builder, ORBIT_DETERMINATIONOffset: flatbuffers.Offset): void;
    static addUserDefinedParameters(builder: flatbuffers.Builder, USER_DEFINED_PARAMETERSOffset: flatbuffers.Offset): void;
    static createUserDefinedParametersVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startUserDefinedParametersVector(builder: flatbuffers.Builder, numElems: number): void;
    static addCenterName(builder: flatbuffers.Builder, CENTER_NAMEOffset: flatbuffers.Offset): void;
    static addTrajRefFrame(builder: flatbuffers.Builder, TRAJ_REF_FRAMEOffset: flatbuffers.Offset): void;
    static addTrajFrameEpoch(builder: flatbuffers.Builder, TRAJ_FRAME_EPOCHOffset: flatbuffers.Offset): void;
    static addCovRefFrame(builder: flatbuffers.Builder, COV_REF_FRAMEOffset: flatbuffers.Offset): void;
    static addOrbRevnum(builder: flatbuffers.Builder, ORB_REVNUM: number): void;
    static addOrbAveraging(builder: flatbuffers.Builder, ORB_AVERAGINGOffset: flatbuffers.Offset): void;
    static addCovCalibration(builder: flatbuffers.Builder, COV_CALIBRATION: covarianceCalibration): void;
    static addCovCalibrationReference(builder: flatbuffers.Builder, COV_CALIBRATION_REFERENCEOffset: flatbuffers.Offset): void;
    static addStateEpochs(builder: flatbuffers.Builder, STATE_EPOCHSOffset: flatbuffers.Offset): void;
    static createStateEpochsVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startStateEpochsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addCovType(builder: flatbuffers.Builder, COV_TYPEOffset: flatbuffers.Offset): void;
    static addCovOrdering(builder: flatbuffers.Builder, COV_ORDERING: covarianceOrdering): void;
    static addCovSize(builder: flatbuffers.Builder, COV_SIZE: number): void;
    static addCovParameters(builder: flatbuffers.Builder, COV_PARAMETERSOffset: flatbuffers.Offset): void;
    static createCovParametersVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startCovParametersVector(builder: flatbuffers.Builder, numElems: number): void;
    static addCovUnits(builder: flatbuffers.Builder, COV_UNITSOffset: flatbuffers.Offset): void;
    static createCovUnitsVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startCovUnitsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addTrajectoryBlocks(builder: flatbuffers.Builder, TRAJECTORY_BLOCKSOffset: flatbuffers.Offset): void;
    static createTrajectoryBlocksVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startTrajectoryBlocksVector(builder: flatbuffers.Builder, numElems: number): void;
    static addCovarianceBlocks(builder: flatbuffers.Builder, COVARIANCE_BLOCKSOffset: flatbuffers.Offset): void;
    static createCovarianceBlocksVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startCovarianceBlocksVector(builder: flatbuffers.Builder, numElems: number): void;
    static addProvenance(builder: flatbuffers.Builder, PROVENANCEOffset: flatbuffers.Offset): void;
    static addCovRealism(builder: flatbuffers.Builder, COV_REALISMOffset: flatbuffers.Offset): void;
    static createCovRealismVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startCovRealismVector(builder: flatbuffers.Builder, numElems: number): void;
    static addMeanElements(builder: flatbuffers.Builder, MEAN_ELEMENTSOffset: flatbuffers.Offset): void;
    static addCovPropagation(builder: flatbuffers.Builder, COV_PROPAGATIONOffset: flatbuffers.Offset): void;
    static addCovParameterKinds(builder: flatbuffers.Builder, COV_PARAMETER_KINDSOffset: flatbuffers.Offset): void;
    static createCovParameterKindsVector(builder: flatbuffers.Builder, data: prwDynamicParameter[]): flatbuffers.Offset;
    static startCovParameterKindsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addTrajBasis(builder: flatbuffers.Builder, TRAJ_BASIS: ocmTrajectoryBasis): void;
    static addSeedSets(builder: flatbuffers.Builder, SEED_SETSOffset: flatbuffers.Offset): void;
    static createSeedSetsVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startSeedSetsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addIntegrator(builder: flatbuffers.Builder, INTEGRATOROffset: flatbuffers.Offset): void;
    static addRpoGeometry(builder: flatbuffers.Builder, RPO_GEOMETRYOffset: flatbuffers.Offset): void;
    static addRpoInspection(builder: flatbuffers.Builder, RPO_INSPECTIONOffset: flatbuffers.Offset): void;
    static endOCM(builder: flatbuffers.Builder): flatbuffers.Offset;
    static finishOCMBuffer(builder: flatbuffers.Builder, offset: flatbuffers.Offset): void;
    static finishSizePrefixedOCMBuffer(builder: flatbuffers.Builder, offset: flatbuffers.Offset): void;
    unpack(): OCMT;
    unpackTo(_o: OCMT): void;
}
export declare class OCMT implements flatbuffers.IGeneratedObject {
    HEADER: HeaderT | null;
    METADATA: MetadataT | null;
    TRAJ_TYPE: trajectoryType;
    TRAJ_TYPE_DESCRIPTION: string | Uint8Array | null;
    STATE_STEP_SIZE: number;
    STATE_VECTOR_SIZE: number;
    STATE_DATA: (number)[];
    COVARIANCE_DATA: (number)[];
    POLYNOMIAL_POSITION_RECORDS: (PPEPositionRecordT)[];
    POLYNOMIAL_OE_RECORDS: (PPEOrbitalElementRecordT)[];
    PHYSICAL_PROPERTIES: PhysicalPropertiesT | null;
    MANEUVER_DATA: (ManeuverT)[];
    PERTURBATIONS: PerturbationsT | null;
    ORBIT_DETERMINATION: OrbitDeterminationT | null;
    USER_DEFINED_PARAMETERS: (UserDefinedParametersT)[];
    CENTER_NAME: string | Uint8Array | null;
    TRAJ_REF_FRAME: RFMT | null;
    TRAJ_FRAME_EPOCH: string | Uint8Array | null;
    COV_REF_FRAME: RFMT | null;
    ORB_REVNUM: number;
    ORB_AVERAGING: string | Uint8Array | null;
    COV_CALIBRATION: covarianceCalibration;
    COV_CALIBRATION_REFERENCE: string | Uint8Array | null;
    STATE_EPOCHS: (string)[];
    COV_TYPE: string | Uint8Array | null;
    COV_ORDERING: covarianceOrdering;
    COV_SIZE: number;
    COV_PARAMETERS: (string)[];
    COV_UNITS: (string)[];
    TRAJECTORY_BLOCKS: (OCMTrajectoryBlockT)[];
    COVARIANCE_BLOCKS: (OCMCovarianceBlockT)[];
    PROVENANCE: PVNT | null;
    COV_REALISM: (CVRT)[];
    MEAN_ELEMENTS: OCMMeanElementsT | null;
    COV_PROPAGATION: OCMCovariancePropagationT | null;
    COV_PARAMETER_KINDS: (prwDynamicParameter)[];
    TRAJ_BASIS: ocmTrajectoryBasis;
    SEED_SETS: (OCMSeedSetT)[];
    INTEGRATOR: OCMIntegratorT | null;
    RPO_GEOMETRY: OCMRelativeGeometryT | null;
    RPO_INSPECTION: OCMInspectionGeometryT | null;
    constructor(HEADER?: HeaderT | null, METADATA?: MetadataT | null, TRAJ_TYPE?: trajectoryType, TRAJ_TYPE_DESCRIPTION?: string | Uint8Array | null, STATE_STEP_SIZE?: number, STATE_VECTOR_SIZE?: number, STATE_DATA?: (number)[], COVARIANCE_DATA?: (number)[], POLYNOMIAL_POSITION_RECORDS?: (PPEPositionRecordT)[], POLYNOMIAL_OE_RECORDS?: (PPEOrbitalElementRecordT)[], PHYSICAL_PROPERTIES?: PhysicalPropertiesT | null, MANEUVER_DATA?: (ManeuverT)[], PERTURBATIONS?: PerturbationsT | null, ORBIT_DETERMINATION?: OrbitDeterminationT | null, USER_DEFINED_PARAMETERS?: (UserDefinedParametersT)[], CENTER_NAME?: string | Uint8Array | null, TRAJ_REF_FRAME?: RFMT | null, TRAJ_FRAME_EPOCH?: string | Uint8Array | null, COV_REF_FRAME?: RFMT | null, ORB_REVNUM?: number, ORB_AVERAGING?: string | Uint8Array | null, COV_CALIBRATION?: covarianceCalibration, COV_CALIBRATION_REFERENCE?: string | Uint8Array | null, STATE_EPOCHS?: (string)[], COV_TYPE?: string | Uint8Array | null, COV_ORDERING?: covarianceOrdering, COV_SIZE?: number, COV_PARAMETERS?: (string)[], COV_UNITS?: (string)[], TRAJECTORY_BLOCKS?: (OCMTrajectoryBlockT)[], COVARIANCE_BLOCKS?: (OCMCovarianceBlockT)[], PROVENANCE?: PVNT | null, COV_REALISM?: (CVRT)[], MEAN_ELEMENTS?: OCMMeanElementsT | null, COV_PROPAGATION?: OCMCovariancePropagationT | null, COV_PARAMETER_KINDS?: (prwDynamicParameter)[], TRAJ_BASIS?: ocmTrajectoryBasis, SEED_SETS?: (OCMSeedSetT)[], INTEGRATOR?: OCMIntegratorT | null, RPO_GEOMETRY?: OCMRelativeGeometryT | null, RPO_INSPECTION?: OCMInspectionGeometryT | null);
    pack(builder: flatbuffers.Builder): flatbuffers.Offset;
}
//# sourceMappingURL=OCM.d.ts.map