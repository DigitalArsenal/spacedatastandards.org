export { SDL, SDLT } from './SDL.js';
//# sourceMappingURL=main.d.ts.map