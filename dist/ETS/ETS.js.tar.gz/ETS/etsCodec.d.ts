/**
 * Codec that produced PAYLOAD. Member names are the codec's own 4-byte
 * bitstream magic: PAYLOAD[0..3] MUST equal the ASCII of the member name,
 * so the field and the bytes cannot disagree unnoticed. `TRK2` is a codec
 * name and has no relation to the `$TRK` standard. UNSPECIFIED holds ordinal
 * 0 so an unset CODEC can never read as a real codec. Ordinals are wire
 * values: append only, never reorder or reuse. A reader that meets an
 * ordinal it does not know MUST still index the record by its plain fields
 * and MUST NOT attempt to decode PAYLOAD.
 */
export declare enum etsCodec {
    /**
     * Unset. A record carrying this is not decodable.
     */
    UNSPECIFIED = 0,
    /**
     * Bounded-error predictive knot track: time-domain simplification, adaptive
     * position and time quanta, velocity-predicted residuals, local WGS 84
     * east-north-up frame anchored at the first observation.
     */
    TRK2 = 1
}
//# sourceMappingURL=etsCodec.d.ts.map