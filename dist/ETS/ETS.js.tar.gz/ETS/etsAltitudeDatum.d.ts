/**
 * Vertical datum of the altitude channel, and whether the channel exists.
 * This is the track's dimensionality: NONE is a 2-D (latitude, longitude)
 * track; every other stated member is 3-D. The unset member is invalid on a
 * written record. A consumer MUST NOT treat a barometric altitude as a
 * WGS 84 ellipsoidal height or build ECEF from it.
 */
export declare enum etsAltitudeDatum {
    /**
     * Unset. A writer MUST state one of the members below.
     */
    UNSPECIFIED = 0,
    /**
     * No altitude channel: a 2-D track. ALTITUDE_MIN_M, ALTITUDE_MAX_M and
     * TOLERANCE_V_M / ACHIEVED_MAX_ERROR_V_M are NaN.
     */
    NONE = 1,
    /**
     * Height above the WGS 84 ellipsoid, metres.
     */
    GEOMETRIC_WGS84 = 2,
    /**
     * Pressure altitude on the standard atmosphere at the standard sea-level
     * pressure setting (no local pressure correction), metres.
     */
    BAROMETRIC_STANDARD = 3,
    /**
     * Altitude is present but its source does not state the datum. The value
     * is carried and the datum is never guessed.
     */
    UNSTATED_3D = 4
}
//# sourceMappingURL=etsAltitudeDatum.d.ts.map