export declare enum referenceFrame {
    /**
     * Earth-Centered-Earth-Fixed (ECEF) frame: Rotates with Earth. Origin at Earth's center. X-axis towards prime meridian, Y-axis eastward, Z-axis towards North Pole. Ideal for terrestrial points.
     */
    ECEF = 0,
    /**
     * International Celestial Reference Frame (ICRF): An inertial frame fixed relative to distant stars. Based on quasars. Used for precision astronomy and unaffected by Earth's rotation.
     */
    ICRF = 1,
    /**
     * True Equator Mean Equinox (TEME): Used in SGP4 model for satellite tracking. Accounts for Earth's precession and nutation. Dynamic frame useful for orbit prediction.
     */
    TEME = 2,
    /**
     * East-North-Up (ENU): Local tangent plane system for surface points. "East" eastward, "North" northward, "Up" perpendicular to Earth's surface. Suited for stationary or slow-moving objects at low altitudes.
     */
    ENU = 3,
    /**
     * North-East-Down (NED): Common in aviation and navigation. "North" northward, "East" eastward, "Down" towards Earth's center. Aligns with gravity, intuitive for aircraft and vehicles.
     */
    NED = 4,
    /**
     * North-East-Up (NEU): Similar to NED but "Up" axis is opposite to gravity. Suited for applications preferring a conventional "Up" direction.
     */
    NEU = 5,
    /**
     * Radial-Intrack-Cross-track (RIC): Aligned with spacecraft's UVW system. "Radial" axis towards spacecraft, "In-track" perpendicular to radial and cross-track, "Cross-track" normal to orbit plane. Used for spacecraft orientation and tracking.
     */
    RIC = 6,
    /**
     * Earth Mean Equator and Equinox of J2000 (J2000): An Earth-Centered Inertial (ECI) frame defined by Earth's mean equator and equinox at the start of the year 2000. Fixed relative to distant stars, used for celestial mechanics and space navigation.
     */
    J2000 = 7,
    /**
     * Geocentric Celestial Reference Frame
     */
    GCRF = 8,
    /**
     * Greenwich Rotating Coordinates
     */
    GRC = 9,
    /**
     * International Terrestrial Reference Frame 2000
     */
    ITRF2000 = 10,
    /**
     * International Terrestrial Reference Frame 1993
     */
    ITRF93 = 11,
    /**
     * International Terrestrial Reference Frame 1997
     */
    ITRF97 = 12,
    /**
     * True of Date, Rotating
     */
    TDR = 13,
    /**
     * True of Date
     */
    TOD = 14,
    /**
     * Radial, Transverse, Normal
     */
    RTN = 15,
    /**
     * Transverse, Velocity, Normal
     */
    TVN = 16,
    /**
     * Vehicle-Body-Local-Horizontal (VVLH): An orbit reference frame with X-axis pointing from the center of the central body to the vehicle, Z-axis oppoOBSERVER to the orbital angular momentum vector, and Y-axis completing the right-handed system.
     */
    VVLH = 17,
    /**
     * Vehicle-Local-Vertical-Local-Horizontal (VLVH): An orbit reference frame similar to VVLH, often used in close proximity operations or surface-oriented missions.
     */
    VLVH = 18,
    /**
     * Local Tangent Plane (LTP): A local, surface-fixed reference frame often used for terrestrial applications, aligned with the local horizon.
     */
    LTP = 19,
    /**
     * Local Vertical-Local Horizontal (LVLH): An orbit reference frame with the Z-axis pointing towards the center of the central body (oppoOBSERVER to local vertical), the X-axis in the velocity direction (local horizontal), and the Y-axis completing the right-hand system.
     */
    LVLH = 20,
    /**
     * Polar-North-East (PNE): A variation of local coordinate systems typically used in polar regions, with axes aligned toward the geographic North Pole, Eastward, and perpendicular to the Earth's surface.
     */
    PNE = 21,
    /**
     * Body-Fixed Reference Frame (BRF): A reference frame fixed to the body of a spacecraft or celestial object, oriented according to the body's principal axes.
     */
    BRF = 22,
    /**
     * Another name for 'Radial, Transverse, Normal'
     */
    RSW = 23,
    /**
     * A local orbital coordinate frame
     */
    TNW = 24
}
//# sourceMappingURL=referenceFrame.d.ts.map