export { RFM, RFMT } from './RFM.js';
export { TDM, TDMT } from './TDM.js';
export { referenceFrame } from './referenceFrame.js';
//# sourceMappingURL=main.d.ts.map