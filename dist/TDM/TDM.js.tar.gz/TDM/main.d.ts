export { OBSERVERLocationReferenceFrame } from './OBSERVERLocationReferenceFrame.js';
export { TDM, TDMT } from './TDM.js';
export { TDMCOLLECTION, TDMCOLLECTIONT } from './TDMCOLLECTION.js';
//# sourceMappingURL=main.d.ts.map