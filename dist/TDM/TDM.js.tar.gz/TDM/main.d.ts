export { RFM, RFMT } from './RFM.js';
export { TDM, TDMT } from './TDM.js';
export { refFrame } from './refFrame.js';
//# sourceMappingURL=main.d.ts.map