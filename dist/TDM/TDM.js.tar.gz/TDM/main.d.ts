export { OBSERVERLocationReferenceFrame } from './OBSERVERLocationReferenceFrame.js';
export { TDM, TDMT } from './TDM.js';
//# sourceMappingURL=main.d.ts.map