export { TCF, TCFT } from './TCF.js';
//# sourceMappingURL=main.d.ts.map