/**
 * Publication Verification (PNV)
 * Description
 * What one node established about a publication notice ($PNM) it received:
 * who published it, which peer relayed it, whether its signature verified,
 * against which key and where that key came from, and whether the network
 * attribution of the publication could be confirmed. A $PNM is the
 * publisher's own signed statement; a PNV is a receiver's verdict on it, so
 * the two never share a record. A set carries the verdicts of one read, for
 * example the latest notice per standard, or the history of notices from one
 * peer.
 * How the receiving node attributes the publication. Append new values only;
 * never reorder or reuse existing values.
 */
export declare enum pnvAttribution {
    /**
     * Not determined.
     */
    Unknown = 0,
    /**
     * Published by the peer the notice arrived from.
     */
    Direct = 1,
    /**
     * Relayed: the publisher is a different peer from the one it arrived from.
     */
    Relayed = 2,
    /**
     * Published by the receiving node itself.
     */
    OwnNode = 3,
    /**
     * The publisher could not be established.
     */
    Unattributed = 4
}
//# sourceMappingURL=pnvAttribution.d.ts.map