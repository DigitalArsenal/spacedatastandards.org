/**
 * Coarse spectral region a band belongs to, by effective wavelength.
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum phbSpectralRegime {
    UNSPECIFIED = 0,
    /**
     * Photon energy above 100 keV (wavelength below 0.0124 nm).
     */
    GAMMA_RAY = 1,
    /**
     * 10 keV to 100 keV (0.0124 nm to 0.124 nm).
     */
    HARD_X_RAY = 2,
    /**
     * 0.1 keV to 10 keV (0.124 nm to 12.4 nm).
     */
    SOFT_X_RAY = 3,
    /**
     * 12.4 nm to 91.2 nm.
     */
    EXTREME_ULTRAVIOLET = 4,
    /**
     * 91.2 nm to 200 nm.
     */
    FAR_ULTRAVIOLET = 5,
    /**
     * 200 nm to 380 nm.
     */
    NEAR_ULTRAVIOLET = 6,
    /**
     * 380 nm to 750 nm.
     */
    VISIBLE = 7,
    /**
     * 0.75 um to 5 um.
     */
    NEAR_INFRARED = 8,
    /**
     * 5 um to 40 um.
     */
    MID_INFRARED = 9,
    /**
     * 40 um to 350 um.
     */
    FAR_INFRARED = 10,
    /**
     * 350 um to 1 mm.
     */
    SUBMILLIMETRE = 11,
    /**
     * 1 mm to 10 cm (3 GHz to 300 GHz).
     */
    MICROWAVE = 12,
    /**
     * Longer than 10 cm (below 3 GHz).
     */
    RADIO = 13
}
//# sourceMappingURL=phbSpectralRegime.d.ts.map