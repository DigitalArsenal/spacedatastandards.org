/**
 * Calibration system a magnitude is stated in.
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum phbMagnitudeSystem {
    UNSPECIFIED = 0,
    /**
     * Zero magnitude is the flux of the standard A0 V reference star.
     */
    VEGA = 1,
    /**
     * Zero magnitude is a flux density of 3631 Jy per unit frequency.
     */
    AB = 2,
    /**
     * Zero magnitude is a flux density of 3.631e-9 erg s-1 cm-2 A-1 per unit
     * wavelength.
     */
    ST = 3,
    /**
     * Instrument-specific system; ZERO_POINT_JY states the calibration.
     */
    INSTRUMENTAL = 4,
    /**
     * The value is not a magnitude (a flux, a count rate, a temperature).
     */
    NOT_A_MAGNITUDE = 5
}
//# sourceMappingURL=phbMagnitudeSystem.d.ts.map