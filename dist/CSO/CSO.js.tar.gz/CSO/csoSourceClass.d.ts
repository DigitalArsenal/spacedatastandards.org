/**
 * Physical class of a non-stellar source.
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum csoSourceClass {
    UNSPECIFIED = 0,
    /**
     * Not identified with a counterpart of known class.
     */
    UNIDENTIFIED = 1,
    /**
     * Accreting compact object with a stellar companion.
     */
    X_RAY_BINARY = 2,
    /**
     * Accreting white dwarf.
     */
    CATACLYSMIC_VARIABLE = 3,
    /**
     * Rotation-powered or accretion-powered neutron star.
     */
    PULSAR = 4,
    /**
     * Neutron star powered by magnetic-field decay.
     */
    MAGNETAR = 5,
    /**
     * Expanding remnant of a stellar explosion.
     */
    SUPERNOVA_REMNANT = 6,
    /**
     * Nebula powered by a pulsar wind.
     */
    PULSAR_WIND_NEBULA = 7,
    /**
     * Accreting supermassive black hole, not otherwise classed.
     */
    ACTIVE_GALACTIC_NUCLEUS = 8,
    /**
     * Active nucleus with its jet close to the line of sight.
     */
    BLAZAR = 9,
    /**
     * Luminous, distant active nucleus.
     */
    QUASAR = 10,
    /**
     * Galaxy whose emission is not dominated by its nucleus.
     */
    GALAXY = 11,
    /**
     * Bound cluster of galaxies.
     */
    GALAXY_CLUSTER = 12,
    /**
     * Globular star cluster.
     */
    GLOBULAR_CLUSTER = 13,
    /**
     * Open star cluster.
     */
    OPEN_CLUSTER = 14,
    /**
     * Ionised hydrogen region or star-forming region.
     */
    EMISSION_NEBULA = 15,
    /**
     * Planetary nebula.
     */
    PLANETARY_NEBULA = 16,
    /**
     * Molecular cloud or dark nebula.
     */
    MOLECULAR_CLOUD = 17,
    /**
     * Gamma-ray burst.
     */
    GAMMA_RAY_BURST = 18,
    /**
     * Supernova.
     */
    SUPERNOVA = 19,
    /**
     * Classical or recurrent nova.
     */
    NOVA = 20,
    /**
     * Kilonova from a compact-binary merger.
     */
    KILONOVA = 21,
    /**
     * Star disrupted by a massive black hole.
     */
    TIDAL_DISRUPTION_EVENT = 22,
    /**
     * Millisecond radio burst.
     */
    FAST_RADIO_BURST = 23,
    /**
     * Astrophysical neutrino candidate.
     */
    NEUTRINO_EVENT = 24,
    /**
     * Gravitational-wave candidate.
     */
    GRAVITATIONAL_WAVE_EVENT = 25,
    /**
     * X-ray or gamma-ray flare of a known source.
     */
    HIGH_ENERGY_FLARE = 26,
    /**
     * Optical transient not yet classified.
     */
    OPTICAL_TRANSIENT = 27,
    /**
     * Class stated in CLASS_NAME.
     */
    OTHER = 28
}
//# sourceMappingURL=csoSourceClass.d.ts.map