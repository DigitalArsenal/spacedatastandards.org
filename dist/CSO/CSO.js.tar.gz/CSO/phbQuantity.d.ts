/**
 * Physical quantity a measurement VALUE states.
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum phbQuantity {
    UNSPECIFIED = 0,
    /**
     * Magnitude in the band's SYSTEM.
     */
    MAGNITUDE = 1,
    /**
     * Spectral flux density per unit frequency, janskys (1e-26 W m-2 Hz-1).
     */
    FLUX_DENSITY_JY = 2,
    /**
     * Band-integrated energy flux, W m-2.
     */
    ENERGY_FLUX_W_PER_M2 = 3,
    /**
     * Band-integrated photon flux, photons m-2 s-1.
     */
    PHOTON_FLUX_PER_M2_S = 4,
    /**
     * Detected count rate of the stated instrument, counts s-1.
     */
    COUNT_RATE_PER_S = 5,
    /**
     * Brightness temperature, kelvin.
     */
    BRIGHTNESS_TEMPERATURE_K = 6
}
//# sourceMappingURL=phbQuantity.d.ts.map