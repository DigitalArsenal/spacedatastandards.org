export declare enum ooiStatus {
    ACTIVE = 0,
    PENDING = 1,
    CLOSED = 2,
    MONITORING = 3,
    URGENT = 4,
    ARCHIVED = 5
}
//# sourceMappingURL=ooiStatus.d.ts.map