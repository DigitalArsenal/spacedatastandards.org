export { OOI, OOIT } from './OOI.js';
//# sourceMappingURL=main.d.ts.map