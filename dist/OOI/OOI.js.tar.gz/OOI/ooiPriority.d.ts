export declare enum ooiPriority {
    CRITICAL = 0,
    HIGH = 1,
    MEDIUM = 2,
    LOW = 3,
    ROUTINE = 4
}
//# sourceMappingURL=ooiPriority.d.ts.map