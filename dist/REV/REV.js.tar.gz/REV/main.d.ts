export { REV, REVT } from './REV.js';
//# sourceMappingURL=main.d.ts.map