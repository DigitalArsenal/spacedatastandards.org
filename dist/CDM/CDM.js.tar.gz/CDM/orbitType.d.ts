export declare enum orbitType {
    /**
     * 0
     */
    ORBIT = 0,
    /**
     * 1
     */
    LANDING = 1,
    /**
     * 2
     */
    IMPACT = 2,
    /**
     * 3
     */
    DOCKED = 3,
    /**
     * 4
     */
    ROUNDTRIP = 4
}
//# sourceMappingURL=orbitType.d.ts.map