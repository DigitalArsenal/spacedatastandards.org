export declare enum maneuverableType {
    YES = 0,
    NO = 1,
    NA = 2
}
//# sourceMappingURL=maneuverableType.d.ts.map