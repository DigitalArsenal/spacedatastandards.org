export declare enum objectCenteredReferenceFrame {
    /**
     * Radial, Transverse, Normal
     */
    RTN = 0,
    /**
     * Transverse, Velocity, Normal
     */
    TVN = 1
}
//# sourceMappingURL=objectCenteredReferenceFrame.d.ts.map