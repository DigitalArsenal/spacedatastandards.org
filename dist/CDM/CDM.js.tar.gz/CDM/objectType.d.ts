export declare enum objectType {
    PAYLOAD = 0,
    ROCKET_BODY = 1,
    DEBRIS = 2,
    UNKNOWN = 3,
    OTHER = 4
}
//# sourceMappingURL=objectType.d.ts.map