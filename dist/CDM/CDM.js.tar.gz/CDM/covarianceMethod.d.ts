export declare enum covarianceMethod {
    CALCULATED = 0,
    DEFAULT = 1
}
//# sourceMappingURL=covarianceMethod.d.ts.map