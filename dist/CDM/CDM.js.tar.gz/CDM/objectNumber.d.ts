export declare enum objectNumber {
    OBJECT1 = 0,
    OBJECT2 = 1
}
//# sourceMappingURL=objectNumber.d.ts.map