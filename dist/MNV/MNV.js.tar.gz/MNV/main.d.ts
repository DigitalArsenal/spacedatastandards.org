export { MNV, MNVT } from './MNV.js';
//# sourceMappingURL=main.d.ts.map