export declare enum maneuverStatus {
    DETECTED = 0,
    CONFIRMED = 1,
    PREDICTED = 2,
    PLANNED = 3,
    EXECUTED = 4,
    CANCELLED = 5,
    UNKNOWN = 6
}
//# sourceMappingURL=maneuverStatus.d.ts.map