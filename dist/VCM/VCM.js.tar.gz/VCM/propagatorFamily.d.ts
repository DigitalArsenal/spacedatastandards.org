/**
 * Enum to represent propagator types
 */
export declare enum propagatorFamily {
    NONE = 0,
    SEMI_ANALYTICAL = 1,
    VINTI = 2,
    SGP4 = 3,
    COWELL = 4,
    RK4 = 5,
    NYX = 6,
    GMAT = 7,
    SPICE = 8,
    SGP = 9,
    SDP4 = 10,
    SGP8 = 11,
    SDP8 = 12
}
//# sourceMappingURL=propagatorFamily.d.ts.map