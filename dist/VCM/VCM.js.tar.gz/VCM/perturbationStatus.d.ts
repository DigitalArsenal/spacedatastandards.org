/**
 * Enum to represent the status of various perturbations (ON/OFF)
 */
export declare enum perturbationStatus {
    OFF = 0,
    ON = 1
}
//# sourceMappingURL=perturbationStatus.d.ts.map