export declare enum timingStandard {
    /**
     * Greenwich Mean Sidereal Time
     */
    GMST = 0,
    /**
     * Global Positioning System
     */
    GPS = 1,
    /**
     * Mission Elapsed Time
     */
    MET = 2,
    /**
     * Mission Relative Time
     */
    MRT = 3,
    /**
     * Spacecraft Clock (receiver) (requires rules for interpretation in ICD)
     */
    SCLK = 4,
    /**
     * International Atomic Time
     */
    TAI = 5,
    /**
     * Barycentric Coordinate Time
     */
    TCB = 6,
    /**
     * Barycentric Dynamical Time
     */
    TDB = 7,
    /**
     * Geocentric Coordinate Time
     */
    TCG = 8,
    /**
     * Terrestrial Time
     */
    TT = 9,
    /**
     * Universal Time
     */
    UT1 = 10,
    /**
     * Coordinated Universal Time
     */
    UTC = 11
}
//# sourceMappingURL=timingStandard.d.ts.map