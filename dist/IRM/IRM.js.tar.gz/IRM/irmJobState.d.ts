/**
 * Lifecycle of the job the mark describes.
 */
export declare enum irmJobState {
    UNSPECIFIED = 0,
    /**
     * Chunks remain; NEXT_OFFSET is where the next read starts.
     */
    IN_PROGRESS = 1,
    /**
     * The source was read to its end and every chunk was committed. NEXT_OFFSET
     * equals the total length when the length is known.
     */
    COMPLETE = 2,
    /**
     * The publisher stopped on an error it did not recover from; FAULT states
     * what happened. The mark stays valid as a resume point.
     */
    FAILED = 3,
    /**
     * The publisher abandoned the job deliberately; it is not a resume point and
     * a consumer restarts from offset 0.
     */
    ABANDONED = 4,
    /**
     * The source changed identity underneath the job (VALIDATOR mismatch), so the
     * position no longer refers to the same bytes. A conforming consumer restarts
     * from offset 0 rather than resuming.
     */
    INVALIDATED = 5
}
//# sourceMappingURL=irmJobState.d.ts.map