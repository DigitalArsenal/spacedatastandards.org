/**
 * How the reader addresses the source's byte ranges.
 */
export declare enum irmRangeMode {
    UNSPECIFIED = 0,
    /**
     * Half-open ranges expressed as a start offset and a byte count.
     */
    OFFSET_LENGTH = 1,
    /**
     * Inclusive first/last byte positions, the convention of ranged transfer
     * protocols: a chunk of `RANGE_FIRST_BYTE`..`RANGE_LAST_BYTE` inclusive.
     */
    INCLUSIVE_BYTE_RANGE = 2,
    /**
     * The source is delivered as discrete numbered parts and byte offsets are not
     * addressable; CHUNK_INDEX is the only position.
     */
    PART_INDEX = 3
}
//# sourceMappingURL=irmRangeMode.d.ts.map