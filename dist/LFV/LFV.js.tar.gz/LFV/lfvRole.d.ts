/**
 * Labelled Feature Vectors (LFV)
 * Description
 * Numeric features computed from objects or their data, each row labelled
 * with what it is, and the report of a test of whether the labelled classes
 * can be told apart. A row says which object (or element set, or history)
 * it was computed from, which group it belongs to (TARGET), its role (a real
 * object or a decoy), which generator made it when it is synthetic, and an
 * optional class; its values follow the set's FEATURE_NAMES in order. The
 * report gives the test's statistic and significance, the decision threshold
 * and the counts on each side of it (the confusion counts), the probability
 * that a real row ranks first among its group, and per-feature separation.
 *
 * Uses: screening whether decoy orbits hide a real one, testing whether a
 * detector separates manoeuvring from quiet objects, any experiment that
 * trains or scores a classifier on features of space objects. Features live
 * here rather than in an $OMM's user-defined parameters so element sets stay
 * clean: a row references its source by identifier and may nest the $OMM
 * element sets it was computed from when a reader needs them alongside.
 * Role of a row in a distinguishing experiment. Append new values only;
 * never reorder or reuse existing values.
 */
export declare enum lfvRole {
    /**
     * Not labelled (a row to be scored).
     */
    Unlabelled = 0,
    /**
     * Computed from a real object's data.
     */
    Real = 1,
    /**
     * Computed from synthetic data made to resemble a real object.
     */
    Decoy = 2
}
//# sourceMappingURL=lfvRole.d.ts.map