export declare enum maintenanceType {
    SCHEDULED = 0,
    UNSCHEDULED = 1,
    CORRECTIVE = 2,
    PREVENTIVE = 3,
    CALIBRATION = 4,
    UPGRADE = 5,
    INSPECTION = 6
}
//# sourceMappingURL=maintenanceType.d.ts.map