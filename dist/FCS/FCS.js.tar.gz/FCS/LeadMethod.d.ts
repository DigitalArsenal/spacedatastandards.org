export declare enum LeadMethod {
    NONE = 0,
    PREDICTIVE = 1,
    COLLISION = 2,
    CONSTANT_BEARING = 3,
    PURSUIT = 4
}
//# sourceMappingURL=LeadMethod.d.ts.map