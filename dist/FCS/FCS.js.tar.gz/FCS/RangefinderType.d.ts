export declare enum RangefinderType {
    STADIAMETRIC = 0,
    STEREOSCOPIC = 1,
    COINCIDENCE = 2,
    LASER = 3,
    RADAR = 4
}
//# sourceMappingURL=RangefinderType.d.ts.map