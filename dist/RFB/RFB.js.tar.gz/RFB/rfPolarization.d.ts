export declare enum rfPolarization {
    LHCP = 0,
    RHCP = 1,
    LINEAR_H = 2,
    LINEAR_V = 3,
    DUAL = 4,
    CROSS = 5,
    UNKNOWN = 6
}
//# sourceMappingURL=rfPolarization.d.ts.map