export { RFB, RFBT } from './RFB.js';
export { rfBandDesignation } from './rfBandDesignation.js';
export { rfPolarization } from './rfPolarization.js';
//# sourceMappingURL=main.d.ts.map