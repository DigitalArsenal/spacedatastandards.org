export declare enum rfBandDesignation {
    UHF = 0,
    L = 1,
    S = 2,
    C = 3,
    X = 4,
    KU = 5,
    K = 6,
    KA = 7,
    V = 8,
    W = 9,
    Q = 10,
    EHF = 11,
    OTHER = 12
}
//# sourceMappingURL=rfBandDesignation.d.ts.map