export declare enum soiCollectionMode {
    SIDEREAL = 0,
    RATE_TRACK = 1,
    STARE = 2,
    SEARCH = 3,
    SURVEY = 4,
    TASKED = 5
}
//# sourceMappingURL=soiCollectionMode.d.ts.map