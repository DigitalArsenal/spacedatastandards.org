export { SOI, SOIT } from './SOI.js';
//# sourceMappingURL=main.d.ts.map