export declare enum soiObsType {
    OPTICAL = 0,
    RADAR = 1,
    COMBINED = 2
}
//# sourceMappingURL=soiObsType.d.ts.map