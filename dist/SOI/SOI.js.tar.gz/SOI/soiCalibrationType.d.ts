export declare enum soiCalibrationType {
    PHOTOMETRIC = 0,
    ASTROMETRIC = 1,
    RADIOMETRIC = 2,
    POLARIMETRIC = 3,
    TEMPORAL = 4,
    NONE = 5
}
//# sourceMappingURL=soiCalibrationType.d.ts.map