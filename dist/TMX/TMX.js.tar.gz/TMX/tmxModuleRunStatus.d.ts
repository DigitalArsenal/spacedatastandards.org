/**
 * Execution status of a single phenomenology module within a matrix run. Append new values only.
 */
export declare enum tmxModuleRunStatus {
    /**
     * Not stated.
     */
    UNSPECIFIED = 0,
    /**
     * Module completed all targets cleanly.
     */
    OK = 1,
    /**
     * Module completed a subset of targets or inputs.
     */
    PARTIAL = 2,
    /**
     * Module unavailable or missing required inputs.
     */
    UNAVAILABLE = 3,
    /**
     * Module or lane restricted by access tier / policy.
     */
    NOT_PUBLIC = 4
}
//# sourceMappingURL=tmxModuleRunStatus.d.ts.map