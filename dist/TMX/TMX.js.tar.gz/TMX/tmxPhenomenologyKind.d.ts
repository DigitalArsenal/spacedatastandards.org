/**
 * Threat phenomenology axis evaluated in the matrix. Append new values only.
 */
export declare enum tmxPhenomenologyKind {
    /**
     * Not stated.
     */
    UNSPECIFIED = 0,
    /**
     * Orbital kinetic conjunctions.
     */
    ORBITAL_KINETIC = 1,
    /**
     * Co-orbital / rendezvous & proximity operations.
     */
    CO_ORBITAL_RPO = 2,
    /**
     * Direct-ascent anti-satellite reach.
     */
    DIRECT_ASCENT_ASAT = 3,
    /**
     * RF jamming, electronic warfare, and GNSS denial.
     */
    RF_EW_GNSS = 4,
    /**
     * Optical / laser directed energy.
     */
    OPTICAL_DIRECTED_ENERGY = 5,
    /**
     * Space weather, drag storm, solar flare/SEP, and planetary radiation.
     */
    SPACE_ENV_RADIATION = 6,
    /**
     * Ground custody tracking and cyber/gateway exposure.
     */
    GROUND_CUSTODY_CYBER = 7
}
//# sourceMappingURL=tmxPhenomenologyKind.d.ts.map