/**
 * How the surface redistributes energy it does not absorb or transmit.
 */
export declare enum rfsScatteringClass {
    UNSPECIFIED = 0,
    /**
     * Mirror-like; energy leaves at the reflection angle.
     */
    SPECULAR = 1,
    /**
     * Energy is spread across angles.
     */
    DIFFUSE = 2,
    /**
     * A specular lobe over a diffuse background.
     */
    MIXED = 3,
    /**
     * Diffuse with a cosine angular distribution.
     */
    LAMBERTIAN = 4,
    /**
     * Direction-dependent scattering that a single coefficient cannot describe.
     */
    ANISOTROPIC = 5
}
//# sourceMappingURL=rfsScatteringClass.d.ts.map