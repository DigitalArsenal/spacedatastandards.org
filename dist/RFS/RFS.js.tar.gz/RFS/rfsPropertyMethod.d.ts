/**
 * How a property value came to exist. `CLASS_DEFAULT` exists so a value taken
 * from a published class table can be REFUSED where a measurement of THIS
 * surface is required.
 */
export declare enum rfsPropertyMethod {
    UNSPECIFIED = 0,
    /**
     * Measured on this surface or a coupon of its material.
     */
    MEASURED = 1,
    /**
     * Computed from a physical model of the material's composition.
     */
    MODELED = 2,
    /**
     * Taken from a published table for the material class, not this surface.
     */
    CLASS_DEFAULT = 3,
    /**
     * Borrowed from a similar structure or bus family; visibly an
     * approximation.
     */
    INFERRED_FROM_FAMILY = 4
}
//# sourceMappingURL=rfsPropertyMethod.d.ts.map