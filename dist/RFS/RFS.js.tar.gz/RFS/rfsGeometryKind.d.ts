/**
 * What the material is attached to, which selects the standard it joins.
 */
export declare enum rfsGeometryKind {
    UNSPECIFIED = 0,
    /**
     * A mesh or material slot inside a reviewed 3D asset; joins `$VAM`.
     */
    ASSET_MESH = 1,
    /**
     * A named surface of a catalogued object; joins `$OPP.OPPSurface`.
     */
    OBJECT_SURFACE = 2,
    /**
     * An articulated panel; joins `$PNL`.
     */
    PANEL = 3,
    /**
     * A whole catalogued object; joins `$CAT`.
     */
    CATALOG_OBJECT = 4,
    /**
     * A structure at a terrestrial site; joins `$TBS`.
     */
    SITE_STRUCTURE = 5,
    /**
     * A face of a building or other fixed structure.
     */
    BUILDING_FACE = 6,
    /**
     * The ground or sea surface itself.
     */
    TERRAIN_SURFACE = 7,
    /**
     * A primitive solved analytically rather than as a mesh.
     */
    ANALYTIC_SHAPE = 8
}
//# sourceMappingURL=rfsGeometryKind.d.ts.map