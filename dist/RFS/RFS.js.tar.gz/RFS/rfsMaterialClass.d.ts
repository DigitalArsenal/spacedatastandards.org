/**
 * Material class, in the generic building-and-natural-material vocabulary of
 * the reference physics. Capability classes only: a class is what the surface
 * IS, never who made it. A branded product name belongs in NAME or in
 * RFSProvenance.SOURCE as data, never in this enum.
 *
 * ORDINALS ARE WIRE VALUES. New classes are APPENDED ONLY.
 */
export declare enum rfsMaterialClass {
    UNSPECIFIED = 0,
    CONCRETE = 1,
    BRICK = 2,
    PLASTERBOARD = 3,
    WOOD = 4,
    GLASS = 5,
    /**
     * Glass treated to reflect infrared, which also attenuates RF strongly.
     */
    COATED_GLASS = 6,
    CEILING_BOARD = 7,
    CHIPBOARD = 8,
    FLOORBOARD = 9,
    METAL = 10,
    STONE = 11,
    ASPHALT = 12,
    ROOFING_TILE = 13,
    VERY_DRY_GROUND = 14,
    MEDIUM_DRY_GROUND = 15,
    WET_GROUND = 16,
    SOIL = 17,
    SAND = 18,
    VEGETATION = 19,
    FRESH_WATER = 20,
    SEA_WATER = 21,
    ICE = 22,
    SNOW = 23,
    /**
     * Fibre-reinforced polymer structure.
     */
    COMPOSITE = 24,
    /**
     * Carbon-fibre structure, electrically conductive along the fibres.
     */
    CARBON_FIBER_COMPOSITE = 25,
    /**
     * Multi-layer insulation blanket.
     */
    MULTI_LAYER_INSULATION = 26,
    SOLAR_CELL = 27,
    /**
     * Conductive or lossy surface coating.
     */
    COATING = 28,
    /**
     * Surface engineered to absorb incident RF energy.
     */
    ABSORBER = 29,
    /**
     * Frequency-selective or periodic structure whose response is not a bulk
     * material property.
     */
    ENGINEERED_SURFACE = 30,
    /**
     * The source states a material this enum cannot express. The verbatim name
     * MUST be preserved in NAME.
     */
    OTHER = 31
}
//# sourceMappingURL=rfsMaterialClass.d.ts.map