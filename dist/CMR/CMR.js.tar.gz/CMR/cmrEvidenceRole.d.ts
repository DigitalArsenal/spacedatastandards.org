/**
 * What one source assertion establishes for a constellation membership.
 * Ordinals are wire values: append only; never reorder or reuse.
 */
export declare enum cmrEvidenceRole {
    /**
     * The source does not distinguish the assertion's role.
     */
    UNSPECIFIED = 0,
    /**
     * The object belongs to the named constellation or curated group.
     */
    MEMBERSHIP = 1,
    /**
     * The source identifies the constellation's operator or owner.
     */
    OPERATOR = 2,
    /**
     * The source establishes the NORAD catalogue identity or object join.
     */
    OBJECT_IDENTITY = 3,
    /**
     * The source establishes the object's satellite-bus join.
     */
    BUS_IDENTITY = 4
}
//# sourceMappingURL=cmrEvidenceRole.d.ts.map