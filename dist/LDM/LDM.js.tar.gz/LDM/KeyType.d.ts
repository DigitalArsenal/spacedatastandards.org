export declare enum KeyType {
    signing = 0,
    encryption = 1
}
//# sourceMappingURL=KeyType.d.ts.map