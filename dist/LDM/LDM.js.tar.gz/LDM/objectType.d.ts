export declare enum objectType {
    /**
     * 0
     */
    PAYLOAD = 0,
    /**
     * 1
     */
    ROCKET_BODY = 1,
    /**
     * 2
     */
    DEBRIS = 2,
    /**
     * 3
     */
    UNKNOWN = 3
}
//# sourceMappingURL=objectType.d.ts.map