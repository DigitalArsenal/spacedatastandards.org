export declare enum massType {
    DRY = 0,
    WET = 1
}
//# sourceMappingURL=massType.d.ts.map