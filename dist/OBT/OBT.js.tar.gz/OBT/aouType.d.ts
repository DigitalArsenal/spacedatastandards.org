export declare enum aouType {
    CIRCULAR = 0,
    ELLIPTICAL = 1,
    RECTANGULAR = 2,
    NONE = 3
}
//# sourceMappingURL=aouType.d.ts.map