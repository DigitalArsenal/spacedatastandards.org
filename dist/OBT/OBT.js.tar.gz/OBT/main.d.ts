export { OBT, OBTT } from './OBT.js';
//# sourceMappingURL=main.d.ts.map