export { OBT, OBTT } from './OBT.js';
export { aouType } from './aouType.js';
export { orbitObjectType } from './orbitObjectType.js';
//# sourceMappingURL=main.d.ts.map