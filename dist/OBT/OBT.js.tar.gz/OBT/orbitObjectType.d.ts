export declare enum orbitObjectType {
    PAYLOAD = 0,
    ROCKET_BODY = 1,
    DEBRIS = 2,
    TBA = 3,
    UNKNOWN = 4
}
//# sourceMappingURL=orbitObjectType.d.ts.map