/**
 * Where a capture's bytes physically live right now.
 */
export declare enum iqcCustody {
    /**
     * Bytes stay upstream. This record is a pointer and nothing more. This is
     * the DEFAULT and the correct value for every multi-gigabyte archive.
     */
    UPSTREAM_ONLY = 0,
    /**
     * This SDN deliberately pinned the bytes; CID is populated and resolvable.
     */
    PINNED = 1,
    /**
     * The bytes were pinned and have since been unpinned. CID is retained for
     * audit; it may no longer resolve.
     */
    UNPINNED = 2
}
//# sourceMappingURL=iqcCustody.d.ts.map