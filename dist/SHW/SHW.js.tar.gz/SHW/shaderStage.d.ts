/**
 * Shader Wire — wire contract for GLSL / WebGL shader plugins that compile
 * and expose parameterized fragments that a host injects into its own
 * pipeline. Carries compile request + response, a uniform description
 * table, and the injection-point enum a host consumes to know where to
 * splice a shader fragment into its stage graph.
 * Shader stage into which a compiled fragment should be injected.
 */
export declare enum shaderStage {
    VERTEX = 0,
    FRAGMENT = 1,
    COMPUTE = 2,
    GEOMETRY = 3,
    TESS_CONTROL = 4,
    TESS_EVALUATION = 5
}
//# sourceMappingURL=shaderStage.d.ts.map