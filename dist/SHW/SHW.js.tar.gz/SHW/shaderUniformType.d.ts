/**
 * Scalar / vector type of a uniform value.
 */
export declare enum shaderUniformType {
    FLOAT = 0,
    VEC2 = 1,
    VEC3 = 2,
    VEC4 = 3,
    INT = 4,
    IVEC2 = 5,
    IVEC3 = 6,
    IVEC4 = 7,
    UINT = 8,
    UVEC2 = 9,
    UVEC3 = 10,
    UVEC4 = 11,
    BOOL = 12,
    BVEC2 = 13,
    BVEC3 = 14,
    BVEC4 = 15,
    MAT2 = 16,
    MAT3 = 17,
    MAT4 = 18,
    SAMPLER_2D = 19,
    SAMPLER_CUBE = 20,
    SAMPLER_2D_ARRAY = 21
}
//# sourceMappingURL=shaderUniformType.d.ts.map