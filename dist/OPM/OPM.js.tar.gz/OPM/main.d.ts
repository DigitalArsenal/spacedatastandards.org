export { OPM, OPMT } from './OPM.js';
//# sourceMappingURL=main.d.ts.map