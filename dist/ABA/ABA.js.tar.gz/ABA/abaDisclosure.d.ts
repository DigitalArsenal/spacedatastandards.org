/**
 * Address Book Attestation (ABA)
 * One signed statement by an SDN node that an exact EPM contact profile is
 * an entry in its address book. A vCard must first be projected to an EPM.
 * An EPM alone is not an address-book entry: the valid ABA must be retained
 * and retrievable alongside the profile it attests.
 *
 * Project the latest valid record by (NODE_PEER_ID, ENTRY_ID), using
 * UPDATED_AT. Updates preserve CREATED_AT and strictly increase UPDATED_AT.
 * Conflicting records at the same timestamp are not a resolved entry.
 * DELETED records are signed tombstones and revoke the entry. Retain them
 * so an older attestation cannot resurrect a revoked entry.
 *
 * PUBLIC_KEY is the literal libp2p identity verification key. Its libp2p
 * Peer ID must equal NODE_PEER_ID; derivation material is never carried.
 * SIGNATURE covers the canonical record with SIGNATURE cleared, following
 * the CLM signing convention. The precise canonical form is in docs/ABA.md.
 * PROFILE_SHA256 is the 32-byte SHA-256 digest of PROFILE_BYTES, without
 * decoding, normalizing or reserializing those bytes before hashing.
 * Disclosure policy for one entry. Append values only; never reuse ordinals.
 */
export declare enum abaDisclosure {
    /**
     * Private to the node; never publicly served or synchronized.
     */
    PRIVATE = 0,
    /**
     * May be publicly served or synchronized with its signed attestation.
     */
    PUBLIC = 1
}
//# sourceMappingURL=abaDisclosure.d.ts.map