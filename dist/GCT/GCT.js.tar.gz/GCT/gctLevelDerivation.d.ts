/**
 * How a level was produced from the field. ORDINALS ARE WIRE VALUES; new
 * derivations are APPENDED ONLY.
 */
export declare enum gctLevelDerivation {
    /**
     * Not stated.
     */
    UNSPECIFIED = 0,
    /**
     * Sampled directly from the source field or authored at this cell.
     */
    AUTHORED = 1,
    /**
     * Mass-conserving merge of the finer level on a regular grid of cell
     * MERGE_CELL_M, silhouette preserved.
     */
    GRID_MERGE = 2,
    /**
     * Mass-conserving k-means merge of the finer level into
     * GAUSSIAN_COUNT clusters.
     */
    CLUSTER_MERGE = 3,
    /**
     * Fitted to a voxel or observational field by optimisation.
     */
    FITTED = 4
}
//# sourceMappingURL=gctLevelDerivation.d.ts.map