/**
 * Application Package Manifest
 *
 * An app is a launchable collection of WASM modules, the SDS data types it
 * produces and consumes, the upstream sources it depends on, and its user
 * interface, grouped under one stable identity. Apps run isomorphically in
 * the desktop runtime and the browser; the manifest is the single record a
 * launcher needs to list, verify, and start the app.
 *
 * The UI is carried inline: a fully self-contained HTML page (CSS and JS
 * inlined, no external requests) inside a string field, with an explicit
 * content-encoding parameter so the page may be stored as literal UTF-8
 * text, base64, or a compressed base64 form. A page may instead be served
 * by a member module; exactly one of the two mechanisms must be populated
 * per page.
 *
 * The page's data contract is described declaratively by DATAFLOW: every
 * unit of data that enters or leaves the running page, the SDS standard it
 * carries, the transport that moves it, and — when applicable — the loaded
 * module method port that produces or consumes it. Standards-only rule:
 * every page payload is an SDS record (a canonical size-prefixed
 * FlatBuffer) or a content identifier pointing at one; the app manifest
 * carries no bespoke page-only data shapes. Locators are content-addressed
 * and IPFS-first: a flow's LOCATOR is a CID resolved through the serving
 * node's IPFS gateway wherever the payload can be published as an immutable
 * object, falling back to a live gossip topic or a same-origin gateway
 * route only for streaming or request-scoped delivery.
 *
 * Member modules run isomorphically. A module ref may declare, via
 * RUNTIME_TARGET, that it loads IN THE PAGE through the same module-sdk ABI
 * the SDN nodes use: the page resolves the module bytes by CONTENT_HASH
 * over IPFS and instantiates them in the shared isomorphic JS harness
 * (manifest + plugin_invoke_stream), exactly as a server-side node would.
 * There is no bespoke browser loader; the browser and the node are two
 * hosts of one harness ABI.
 * Content encoding applied to APPUIPage.CONTENT. Append new values only;
 * never reorder or reuse existing values. Decoders must reject an encoding
 * value they do not recognize rather than guessing.
 */
export declare enum appContentEncoding {
    /**
     * CONTENT is the literal page text, UTF-8.
     */
    UTF8 = 0,
    /**
     * CONTENT is RFC 4648 standard base64 (with padding) of the page bytes.
     */
    BASE64 = 1,
    /**
     * CONTENT is base64 of the gzip-compressed page bytes.
     */
    BASE64_GZIP = 2,
    /**
     * CONTENT is base64 of the Brotli-compressed page bytes.
     */
    BASE64_BROTLI = 3
}
//# sourceMappingURL=appContentEncoding.d.ts.map