/**
 * Application Package Manifest
 *
 * An app is a launchable collection of WASM modules, the SDS data types it
 * produces and consumes, the upstream sources it depends on, and its user
 * interface, grouped under one stable identity. Apps run isomorphically in
 * the desktop runtime and the browser; the manifest is the single record a
 * launcher needs to list, verify, and start the app.
 *
 * The UI is carried inline: a fully self-contained HTML page (CSS and JS
 * inlined, no external requests) inside a string field, with an explicit
 * content-encoding parameter so the page may be stored as literal UTF-8
 * text, base64, or a compressed base64 form. A page may instead be served
 * by a member module; exactly one of the two mechanisms must be populated
 * per page.
 * Content encoding applied to APPUIPage.CONTENT. Append new values only;
 * never reorder or reuse existing values. Decoders must reject an encoding
 * value they do not recognize rather than guessing.
 */
export declare enum appContentEncoding {
    /**
     * CONTENT is the literal page text, UTF-8.
     */
    UTF8 = 0,
    /**
     * CONTENT is RFC 4648 standard base64 (with padding) of the page bytes.
     */
    BASE64 = 1,
    /**
     * CONTENT is base64 of the gzip-compressed page bytes.
     */
    BASE64_GZIP = 2,
    /**
     * CONTENT is base64 of the Brotli-compressed page bytes.
     */
    BASE64_BROTLI = 3
}
//# sourceMappingURL=appContentEncoding.d.ts.map