/**
 * Propagation model requested for the per-cell loss term, in the generic
 * published-model vocabulary. Capability classes only: a model class is what
 * the mathematics IS, never whose implementation runs it.
 *
 * ORDINALS ARE WIRE VALUES and deliberately match the widely-deployed
 * numbering of this vocabulary, including the gap before CUSTOM. New models
 * are APPENDED ONLY (between 11 and 98, then past 99 — an ordinal is never
 * reused, and 99 stays CUSTOM).
 */
export declare enum trsPropagationModel {
    /**
     * Free-space path loss. Holds ordinal 0 and is the default.
     */
    FREE_SPACE = 0,
    /**
     * Two-ray ground-reflection model.
     */
    TWO_RAY_GROUND = 1,
    /**
     * Okumura-Hata, urban.
     */
    HATA_URBAN = 2,
    /**
     * Okumura-Hata, suburban.
     */
    HATA_SUBURBAN = 3,
    /**
     * Okumura-Hata, rural/open.
     */
    HATA_RURAL = 4,
    /**
     * COST 231 extension of Hata.
     */
    COST231 = 5,
    /**
     * ITU-R P.1812-class terrain-aware path loss.
     */
    ITU_TERRAIN = 6,
    /**
     * Single knife-edge diffraction (ITU-R P.526).
     */
    KNIFE_EDGE = 7,
    /**
     * Multiple knife-edge diffraction (ITU-R P.526).
     */
    MULTI_KNIFE_EDGE = 8,
    /**
     * Bullington equivalent-edge diffraction (ITU-R P.526).
     */
    BULLINGTON = 9,
    /**
     * Longley-Rice / ITM irregular-terrain model.
     */
    LONGLEY_RICE = 10,
    /**
     * A model this enum cannot express; the solver names it out of band.
     */
    CUSTOM = 99
}
//# sourceMappingURL=trsPropagationModel.d.ts.map