/**
 * Node Pin Policy ($PIN)
 *
 * What an SDN node keeps pinned in its IPFS blockstore. A pin keeps bytes out
 * of IPFS garbage collection and lets other peers fetch them from the node by
 * CID. Pinning is separate from storage: the node's own store keeps and serves
 * its records and files by CID whether or not they are pinned.
 *
 * The node's own $EPM and its account $EPMs are always pinned. Every other
 * class is off until an operator turns it on. A rule names a class and,
 * optionally, one feed within it; a feed rule overrides its class rule.
 *
 * The node answers with its whole policy and what each rule holds. A client
 * changes rules by sending a $PIN whose RULES carry only the rules to change
 * (CLASS, FEED, ENABLED). The node applies them, pins or unpins the content
 * they cover, and answers with its whole policy.
 * What a pin holds. Append new values only; never reorder or reuse values.
 */
export declare enum pinClass {
    /**
     * The node's own $EPM. Always pinned.
     */
    NODE_EPM = 0,
    /**
     * The $EPMs of the node's accounts. Always pinned.
     */
    ACCOUNT_EPM = 1,
    /**
     * Dataset publications of a lane: manifests, shards, indexes, $PNM and
     * CAR archives. FEED is "<standard>/<provider>/<source>".
     */
    PUBLICATION = 2,
    /**
     * Records published as open shares (share links).
     */
    SHARE = 3,
    /**
     * Files a flow or module pins through its IPFS capability, such as star
     * catalogs, error models and ephemerides. FEED is the flow or module id.
     */
    FLOW_ASSET = 4,
    /**
     * Content announced to the node in pubsub tips. FEED is the topic.
     */
    TIP = 5,
    /**
     * Storefront listings and their artifacts.
     */
    STOREFRONT = 6,
    /**
     * 3D asset models.
     */
    ASSET_MODEL = 7,
    /**
     * Homepage site assets.
     */
    SITE_ASSET = 8,
    /**
     * Profile photos of the node and its accounts.
     */
    PROFILE_PHOTO = 9
}
//# sourceMappingURL=pinClass.d.ts.map