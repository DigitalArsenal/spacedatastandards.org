export { OOS, OOST } from './OOS.js';
//# sourceMappingURL=main.d.ts.map