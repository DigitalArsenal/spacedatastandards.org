/**
 * FlatSQL node operation selected by an FSO control frame. These operations
 * execute inside the independently instantiated FlatSQL WASM node; a host
 * routes the bytes but never implements an operation.
 */
export declare enum flatSqlNodeOperation {
    NONE = 0,
    APPEND_RECORDS = 1,
    QUERY_RECORDS = 2,
    CONFIGURE_INDEX = 3,
    UPSERT_VIEW = 4,
    COMPACT = 5,
    CONFIGURE_RETENTION = 6,
    SNAPSHOT = 7,
    RELOAD = 8
}
//# sourceMappingURL=flatSqlNodeOperation.d.ts.map