/**
 * Operations of a bounded expression. The expression is data, evaluated by the
 * provider; no code runs. Append new values only.
 */
export declare enum pcfExpressionOperation {
    UNSPECIFIED = 0,
    /**
     * Push VALUE.
     */
    CONSTANT = 1,
    /**
     * Push the value of PARAMETER at the integrated state, in the units of the $PCE
     * catalog.
     */
    PARAMETER = 2,
    /**
     * Pop two, push their sum, difference (second minus first popped), product or
     * quotient.
     */
    ADD = 3,
    SUBTRACT = 4,
    MULTIPLY = 5,
    DIVIDE = 6,
    /**
     * Pop one, push the result.
     */
    NEGATE = 7,
    ABSOLUTE = 8,
    SQUARE_ROOT = 9,
    SINE = 10,
    COSINE = 11,
    /**
     * Pop two, push the lesser or the greater.
     */
    MINIMUM = 12,
    MAXIMUM = 13
}
//# sourceMappingURL=pcfExpressionOperation.d.ts.map