export declare enum IntegratorType {
    RK4 = 0,
    RK45 = 1,
    RK78 = 2,
    DOPRI5 = 3,
    DOPRI853 = 4,
    ABM = 5,
    BS = 6,
    ANALYTICAL = 255
}
//# sourceMappingURL=IntegratorType.d.ts.map