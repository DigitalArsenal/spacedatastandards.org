/**
 * The event function of a located event. Each is a continuous function g of the
 * integrated state, evaluated by the integrator; an event is a zero crossing of g.
 * The crossing is bracketed on each accepted step, refined to TOLERANCE_SECONDS on
 * the integrator's continuous extension, and confirmed by re-stepping the
 * integrator itself, so the epoch does not depend on the step size. Append new
 * values only.
 */
export declare enum pcfEventKind {
    UNSPECIFIED = 0,
    /**
     * g = r . v, the radial rate. INCREASING crossings are periapsis, DECREASING apoapsis.
     */
    APSIS = 1,
    /**
     * g = n . r for the plane through the central body's center with normal PLANE_NORMAL
     * (absent: the pole of the request's axes, which makes the crossings the nodes).
     * INCREASING crossings are ascending, DECREASING descending.
     */
    PLANE_CROSSING = 2,
    /**
     * g = the true anomaly minus ANGLE_RAD, wrapped to (-pi, pi]. INCREASING.
     */
    TRUE_ANOMALY = 3,
    /**
     * g = the argument of latitude minus ANGLE_RAD, wrapped to (-pi, pi]. INCREASING.
     */
    ARGUMENT_OF_LATITUDE = 4,
    /**
     * g = r^2 d(z)/dt - z (r . v) with z the component along the pole of the request's
     * axes: the zero of the rate of the geocentric latitude. DECREASING crossings are
     * maxima, INCREASING minima.
     */
    LATITUDE_EXTREMUM = 5,
    /**
     * g = the angular separation of the Sun and the central body's centers minus the
     * difference of their apparent radii, positive in light (the umbra of the conical
     * model). DECREASING is entry, INCREASING exit.
     */
    UMBRA = 6,
    /**
     * g = the same separation minus the sum of the apparent radii (the penumbra
     * boundary).
     */
    PENUMBRA = 7,
    /**
     * g = (r - r2) . (v - v2), r2 and v2 the position and velocity of the trajectory on
     * the input port named by SECOND_TRAJECTORY_PORT. INCREASING crossings are minima of
     * the range. The $OEM must cover the propagated arc; the provider interpolates it by
     * Hermite polynomials.
     */
    CLOSEST_APPROACH = 8,
    /**
     * g = the value of EXPRESSION.
     */
    EXPRESSION = 9
}
//# sourceMappingURL=pcfEventKind.d.ts.map