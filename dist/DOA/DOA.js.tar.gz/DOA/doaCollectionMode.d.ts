export declare enum doaCollectionMode {
    TDOA = 0,
    FDOA = 1,
    TDOA_FDOA = 2,
    AOA = 3,
    COMBINED = 4,
    UNKNOWN = 5
}
//# sourceMappingURL=doaCollectionMode.d.ts.map