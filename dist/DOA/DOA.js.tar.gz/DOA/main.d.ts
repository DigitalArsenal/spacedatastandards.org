export { DOA, DOAT } from './DOA.js';
//# sourceMappingURL=main.d.ts.map