export declare enum radarObsType {
    DETECTION = 0,
    TRACK = 1,
    METRIC = 2,
    SIGNATURE = 3,
    SEARCH_FENCE = 4,
    UNKNOWN = 5
}
//# sourceMappingURL=radarObsType.d.ts.map