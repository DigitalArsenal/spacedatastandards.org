/**
 * Direction of a link relative to its endpoints.
 *
 * This enum deliberately mirrors `$LKS.linkCategory` member-for-member with
 * an added `UNSPECIFIED` at ordinal 0. `linkCategory` places `UPLINK` at
 * ordinal 0, so an unset field there silently decodes as a real direction;
 * a durable analytical record may not carry that hazard.
 */
export declare enum rflLinkKind {
    UNSPECIFIED = 0,
    UPLINK = 1,
    DOWNLINK = 2,
    CROSSLINK = 3,
    INTER_SATELLITE = 4,
    GROUND_TO_GROUND = 5,
    RELAY = 6,
    /**
     * Service link to an end-user terminal.
     */
    USER_BEAM = 7,
    /**
     * Gateway link carrying aggregated traffic to the network core.
     */
    FEEDER = 8
}
//# sourceMappingURL=rflLinkKind.d.ts.map