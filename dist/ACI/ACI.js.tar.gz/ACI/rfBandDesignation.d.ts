/**
 * Band designation carried by an emitter record.
 *
 * Two naming systems coexist here on purpose. `UHF`, `SHF`, `EHF` and the
 * members below `OTHER` are ITU-R V.431 decade bands; `L` through `Q` are the
 * IEEE 521 letter bands. They OVERLAP by construction (an 8.4 GHz downlink is
 * both `X` and `SHF`). A publisher encodes the designation ITS SOURCE STATES —
 * never a re-derivation from CENTER_FREQ, and never both.
 *
 * ORDINALS ARE WIRE VALUES. New members are APPENDED ONLY. Members added after
 * `OTHER` are therefore out of frequency order in the declaration; that is
 * deliberate and permanent. Reordering this enum silently re-labels every
 * $RFB record ever published.
 */
export declare enum rfBandDesignation {
    UHF = 0,
    L = 1,
    S = 2,
    C = 3,
    X = 4,
    KU = 5,
    K = 6,
    KA = 7,
    V = 8,
    W = 9,
    Q = 10,
    EHF = 11,
    /**
     * The source states a designation this enum cannot express. The verbatim
     * designation MUST be preserved in NAME.
     */
    OTHER = 12,
    /**
     * ITU-R V.431 very high frequency, 30–300 MHz. Appended 1.177.0.
     */
    VHF = 13,
    /**
     * ITU-R V.431 high frequency, 3–30 MHz. Appended 1.177.0.
     */
    HF = 14,
    /**
     * ITU-R V.431 medium frequency, 300 kHz–3 MHz. Appended 1.177.0.
     */
    MF = 15,
    /**
     * ITU-R V.431 low frequency, 30–300 kHz. Appended 1.177.0.
     */
    LF = 16,
    /**
     * ITU-R V.431 very low frequency, 3–30 kHz. Appended 1.177.0.
     */
    VLF = 17,
    /**
     * ITU-R V.431 super high frequency, 3–30 GHz. Appended 1.177.0 to close the
     * decade ladder between the pre-existing UHF and EHF members.
     */
    SHF = 18
}
//# sourceMappingURL=rfBandDesignation.d.ts.map