/**
 * What kind of interval an entry describes.
 *
 * `UNSPECIFIED` holds ordinal 0 so an unset field can never decode as a claim
 * of geometric access.
 */
export declare enum aciIntervalKind {
    UNSPECIFIED = 0,
    /**
     * Geometry alone permitted the link (mask, range, occultation, beam).
     */
    GEOMETRIC_ACCESS = 1,
    /**
     * The link budget met the stated threshold for the whole interval.
     */
    THRESHOLD_SATISFIED = 2,
    /**
     * The link had geometric access but did not meet the threshold.
     */
    OUTAGE = 3,
    /**
     * Service moved from one link or server to another.
     */
    HANDOVER = 4,
    /**
     * A contact booked on a schedule, whether or not it was executed.
     */
    SCHEDULED_CONTACT = 5,
    /**
     * An interval during which transmission was prohibited.
     */
    KEEP_OUT = 6,
    /**
     * An interval during which interference exceeded a stated criterion.
     */
    INTERFERENCE_EVENT = 7
}
//# sourceMappingURL=aciIntervalKind.d.ts.map