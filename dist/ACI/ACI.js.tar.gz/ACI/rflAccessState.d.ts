/**
 * Whether the link existed at a sample epoch, and how far the evaluation got.
 *
 * `NOT_EVALUATED` holds ordinal 0 so an unset field can never decode as a
 * claim that the link was up or down.
 */
export declare enum rflAccessState {
    /**
     * The sample epoch was not evaluated for this link.
     */
    NOT_EVALUATED = 0,
    /**
     * Geometry denies the link (below the elevation mask, occulted, out of
     * range, outside the beam).
     */
    NO_ACCESS = 1,
    /**
     * Geometry permits the link; the budget was not evaluated at this sample.
     */
    GEOMETRIC_ACCESS = 2,
    /**
     * Geometry permits the link, the budget was evaluated, and the stated
     * threshold is NOT met.
     */
    BELOW_THRESHOLD = 3,
    /**
     * Geometry permits the link and the budget meets the stated threshold.
     */
    THRESHOLD_SATISFIED = 4,
    /**
     * The link had access and lost it to the stated LIMITING_CONSTRAINT (rain
     * fade, sun outage, blockage) rather than to geometry.
     */
    OUTAGE = 5,
    /**
     * The emitter was deliberately not radiating (scheduled off, regulatory
     * keep-out, power-safe mode). Distinct from NO_ACCESS: the geometry may be
     * perfectly good.
     */
    SUPPRESSED = 6
}
//# sourceMappingURL=rflAccessState.d.ts.map