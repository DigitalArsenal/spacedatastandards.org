/**
 * Plugin type category
 */
export declare enum pluginCategory {
    /**
     * Sensor simulation and analysis
     */
    Sensor = 0,
    /**
     * Orbital propagation algorithms
     */
    Propagator = 1,
    /**
     * Custom rendering/visualization
     */
    Renderer = 2,
    /**
     * Data analysis and processing
     */
    Analysis = 3,
    /**
     * External data source integration
     */
    DataSource = 4,
    /**
     * Electronic warfare simulation
     */
    EW = 5,
    /**
     * Communications modeling
     */
    Comms = 6,
    /**
     * Physics simulation
     */
    Physics = 7,
    /**
     * GLSL shader plugins for custom visualization
     */
    Shader = 8
}
//# sourceMappingURL=pluginCategory.d.ts.map