/**
 * Plugin type category
 */
export declare enum pluginCategory {
    /**
     * Sensor simulation and analysis
     */
    Sensor = 0,
    /**
     * Orbital propagation algorithms
     */
    Propagator = 1,
    /**
     * Custom rendering/visualization
     */
    Renderer = 2,
    /**
     * Data analysis and processing
     */
    Analysis = 3,
    /**
     * External data source integration
     */
    DataSource = 4,
    /**
     * Electronic warfare simulation
     */
    EW = 5,
    /**
     * Communications modeling
     */
    Comms = 6,
    /**
     * Physics simulation
     */
    Physics = 7,
    /**
     * GLSL shader plugins for custom visualization
     */
    Shader = 8,
    /**
     * Parses raw upstream bytes into canonical SDS records
     */
    Parser = 9,
    /**
     * Validates records (integrity, physical bounds, continuity)
     */
    Validator = 10,
    /**
     * Interpolates ephemeris / state-vector records
     */
    Interpolator = 11,
    /**
     * Exports records to external formats (CSV, etc.)
     */
    Exporter = 12,
    /**
     * Foundational math / utility library module
     */
    Foundation = 13,
    /**
     * Node infrastructure (runtime, delivery, registry)
     */
    Infrastructure = 14,
    /**
     * Module-delivery licensing / key authority
     */
    Licensing = 15,
    /**
     * Storefront listing / discovery
     */
    Storefront = 16,
    /**
     * Publication: PNM signing + pub/sub announcement
     */
    Publisher = 17,
    /**
     * Astrodynamics simulation and dynamics-modelling module family. The member
     * identifier is a legacy vocabulary key retained for wire and manifest
     * compatibility; renaming it is an owner-gated breaking change.
     */
    Basilisk = 18,
    /**
     * Maneuver planning, targeting and trajectory optimization
     */
    Maneuver = 19,
    /**
     * A composed flow published as a single loadable module. The unit is a
     * graph of other modules, not a leaf algorithm.
     */
    Flow = 20,
    /**
     * No family stated. Sits at the end of the enum rather than at 0 because
     * this enum is append-only and `Sensor` already holds 0; it exists so a
     * record can distinguish "the provider did not say" from "Sensor". A
     * consumer MUST render an `Unspecified` module as ungrouped, never as a
     * member of any family.
     */
    Unspecified = 21
}
//# sourceMappingURL=pluginCategory.d.ts.map