/**
 * Object Identity Link (OIL)
 * Description
 * Candidate links between the identifiers two catalogs give the same space
 * object: a provider's own number and a NORAD catalog number, an
 * international designator, or another provider's number (for example a JSC
 * Vimpel number and a NORAD number). A link is a declaration with its
 * evidence, never an assertion: it says which source declared the pairing,
 * in which edition and on which line, how often, with what first-detection
 * dates, and whether the pairing is one-to-one or part of a group where one
 * identifier is declared against several on the other side (an alias or a
 * conflict). A consumer binds identities only after testing the link, for
 * example by comparing trajectories ($XMT), and records the outcome in the
 * link's STATUS.
 *
 * An OIL set is one crosswalk: the links one source edition declares, its
 * conflicts and its counters. Catalog composition ($CAT) and cross-matching
 * ($XMT) read it; $CAT records stay untouched.
 * Where a link stands. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum oilLinkStatus {
    /**
     * Not stated.
     */
    Unspecified = 0,
    /**
     * Declared by a source and not yet tested.
     */
    Candidate = 1,
    /**
     * Proposed for testing (for example paired with trajectories to compare).
     */
    Proposed = 2,
    /**
     * Repeats an earlier declaration of the same pair (DUPLICATE_OF names it).
     */
    Duplicate = 3,
    /**
     * One side is declared against more than one identifier on the other.
     */
    Conflicting = 4,
    /**
     * The declaration could not be read as a valid pairing (an impossible
     * date, a malformed identifier); kept with its text as evidence.
     */
    Invalid = 5,
    /**
     * Tested and bound: the identities are joined.
     */
    Bound = 6,
    /**
     * Tested and refused.
     */
    Rejected = 7
}
//# sourceMappingURL=oilLinkStatus.d.ts.map