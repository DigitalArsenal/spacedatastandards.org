/**
 * Shape of a group of identifiers declared against each other that is not
 * one-to-one. Append new values only; never reorder or reuse existing values.
 */
export declare enum oilConflictShape {
    /**
     * Not stated.
     */
    Unspecified = 0,
    /**
     * One left identifier is declared against several right identifiers.
     */
    OneLeftManyRight = 1,
    /**
     * One right identifier is declared against several left identifiers.
     */
    ManyLeftOneRight = 2,
    /**
     * Several on each side are declared against each other.
     */
    ManyLeftManyRight = 3
}
//# sourceMappingURL=oilConflictShape.d.ts.map