/**
 * The kind of operating surface. Ordinals are wire values: append only.
 */
export declare enum tfnSurfaceKind {
    /**
     * The source publishes no kind, or one this enum does not model; the
     * source's own token, when there is one, rides in SURFACE_TYPE_CODE.
     */
    UNSPECIFIED = 0,
    /**
     * A runway, including water runways at seaplane bases.
     */
    RUNWAY = 1,
    /**
     * A helipad or other vertical-operations pad.
     */
    HELIPAD = 2,
    /**
     * A berth a vessel moors alongside.
     */
    BERTH = 3,
    /**
     * An anchorage area.
     */
    ANCHORAGE = 4,
    /**
     * A quay or wharf frontage.
     */
    QUAY = 5,
    /**
     * A pier or jetty.
     */
    PIER = 6,
    /**
     * A launch or landing pad at a spaceport.
     */
    LAUNCH_PAD = 7
}
//# sourceMappingURL=tfnSurfaceKind.d.ts.map