/**
 * Which broadcast message a navigation record came from. Append new values
 * only; never reorder or reuse a value.
 */
export declare enum gnssNavMessageType {
    UNSPECIFIED = 0,
    /**
     * Legacy navigation message (GPS, QZSS, NavIC).
     */
    LNAV = 1,
    /**
     * Civil navigation message (GPS and QZSS L2C and L5).
     */
    CNAV = 2,
    /**
     * BeiDou B-CNAV1.
     */
    CNV1 = 3,
    /**
     * BeiDou B-CNAV2.
     */
    CNV2 = 4,
    /**
     * BeiDou B-CNAV3.
     */
    CNV3 = 5,
    /**
     * Galileo F/NAV (E5a).
     */
    FNAV = 6,
    /**
     * Galileo I/NAV (E1 and E5b).
     */
    INAV = 7,
    /**
     * BeiDou D1 (MEO and IGSO).
     */
    D1 = 8,
    /**
     * BeiDou D2 (GEO).
     */
    D2 = 9,
    /**
     * GLONASS FDMA navigation message.
     */
    FDMA = 10,
    /**
     * SBAS geostationary navigation message.
     */
    SBAS = 11
}
//# sourceMappingURL=gnssNavMessageType.d.ts.map