export { CMS, CMST } from './CMS.js';
export { commsChannel, commsChannelT } from './commsChannel.js';
export { commsTransponder, commsTransponderT } from './commsTransponder.js';
export { encryptionType } from './encryptionType.js';
export { modulationType } from './modulationType.js';
//# sourceMappingURL=main.d.ts.map