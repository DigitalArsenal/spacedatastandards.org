export declare enum ionoSource {
    IONOSONDE = 0,
    GPS_TEC = 1,
    BEACON = 2,
    ISR = 3,
    ALTIMETER = 4,
    RADIO_OCCULTATION = 5,
    MODEL = 6
}
//# sourceMappingURL=ionoSource.d.ts.map