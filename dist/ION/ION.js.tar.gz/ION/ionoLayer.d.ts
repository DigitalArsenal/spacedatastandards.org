export declare enum ionoLayer {
    D = 0,
    E = 1,
    ES = 2,
    F = 3,
    F1 = 4,
    F2 = 5,
    TOPSIDE = 6
}
//# sourceMappingURL=ionoLayer.d.ts.map