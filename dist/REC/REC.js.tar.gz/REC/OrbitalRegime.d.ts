export declare enum OrbitalRegime {
    LEO = 0,
    MEO = 1,
    GEO = 2,
    HEO = 3,
    SSO = 4,
    MOLNIYA = 5,
    TUNDRA = 6,
    POLAR = 7,
    EQUATORIAL = 8,
    HYPERBOLIC = 9,
    PARABOLIC = 10
}
//# sourceMappingURL=OrbitalRegime.d.ts.map