export declare enum CrewRole {
    COMMANDER = 0,
    GUNNER = 1,
    DRIVER = 2,
    LOADER = 3,
    RADIO_OP = 4,
    PILOT = 5,
    COPILOT = 6,
    ENGINEER = 7,
    HELMSMAN = 8
}
//# sourceMappingURL=CrewRole.d.ts.map