export declare enum ProjectilePhase {
    LOADED = 0,
    IN_FLIGHT = 1,
    DETONATED = 2,
    DUD = 3,
    IMPACT = 4
}
//# sourceMappingURL=ProjectilePhase.d.ts.map