export declare enum ScoreType {
    OUTLIER = 0
}
//# sourceMappingURL=ScoreType.d.ts.map