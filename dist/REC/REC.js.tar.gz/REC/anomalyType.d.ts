export declare enum anomalyType {
    TRUE_ANOMALY = 0,
    MEAN_ANOMALY = 1
}
//# sourceMappingURL=anomalyType.d.ts.map