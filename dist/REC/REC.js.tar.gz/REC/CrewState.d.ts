export declare enum CrewState {
    ALIVE = 0,
    WOUNDED = 1,
    UNCONSCIOUS = 2,
    DEAD = 3,
    BAILED = 4
}
//# sourceMappingURL=CrewState.d.ts.map