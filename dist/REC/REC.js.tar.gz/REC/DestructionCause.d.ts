export declare enum DestructionCause {
    NONE = 0,
    AMMO_DETONATION = 1,
    FUEL_FIRE = 2,
    CREW_LOST = 3,
    STRUCTURAL_FAILURE = 4,
    FLOODING = 5
}
//# sourceMappingURL=DestructionCause.d.ts.map