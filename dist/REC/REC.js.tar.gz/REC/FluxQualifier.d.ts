export declare enum FluxQualifier {
    OBSERVED = 0,
    BURST_ADJUSTED = 1,
    INTERPOLATED_EXTRAPOLATED = 2,
    NO_OBSERVATION = 3,
    CELESTRAK_INTERPOLATED = 4
}
//# sourceMappingURL=FluxQualifier.d.ts.map