export declare enum CZMVerticalOrigin {
    BASELINE = 0,
    BOTTOM = 1,
    CENTER = 2,
    TOP = 3
}
//# sourceMappingURL=CZMVerticalOrigin.d.ts.map