export declare enum ESMFunction {
    SEARCH = 0,
    CLASSIFICATION = 1,
    IDENTIFICATION = 2,
    DIRECTION_FINDING = 3,
    LOCATION = 4,
    RECORDING = 5,
    SITUATIONAL_AWARENESS = 6
}
//# sourceMappingURL=ESMFunction.d.ts.map