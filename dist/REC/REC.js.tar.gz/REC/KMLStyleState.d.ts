export declare enum KMLStyleState {
    NORMAL = 0,
    HIGHLIGHT = 1
}
//# sourceMappingURL=KMLStyleState.d.ts.map