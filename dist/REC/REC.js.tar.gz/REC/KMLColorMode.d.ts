export declare enum KMLColorMode {
    NORMAL = 0,
    RANDOM = 1
}
//# sourceMappingURL=KMLColorMode.d.ts.map