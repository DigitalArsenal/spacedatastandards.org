export declare enum CmsModulationType {
    BPSK = 0,
    QPSK = 1,
    OQPSK = 2,
    PSK8 = 3,
    QAM16 = 4,
    QAM64 = 5,
    FSK = 6,
    MSK = 7,
    GMSK = 8,
    AM = 9,
    FM = 10,
    PM = 11,
    SPREAD_SPECTRUM = 12,
    DVB_S2 = 13,
    DVB_S2X = 14
}
//# sourceMappingURL=CmsModulationType.d.ts.map