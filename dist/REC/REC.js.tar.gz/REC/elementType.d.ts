export declare enum elementType {
    OSCULATING = 0,
    MEAN = 1
}
//# sourceMappingURL=elementType.d.ts.map