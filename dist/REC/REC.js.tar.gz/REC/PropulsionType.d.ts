export declare enum PropulsionType {
    STEAM = 0,
    GAS_TURBINE = 1,
    DIESEL = 2,
    DIESEL_ELECTRIC = 3,
    NUCLEAR = 4,
    CODAG = 5,
    COGAG = 6,
    CODLAG = 7,
    AIP = 8
}
//# sourceMappingURL=PropulsionType.d.ts.map