export declare enum CentralBody {
    EARTH = 0,
    MOON = 1,
    SUN = 2,
    MARS = 3,
    JUPITER = 4,
    SATURN = 5,
    VENUS = 6,
    MERCURY = 7,
    CUSTOM_BODY = 8
}
//# sourceMappingURL=CentralBody.d.ts.map