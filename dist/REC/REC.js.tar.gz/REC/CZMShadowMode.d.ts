export declare enum CZMShadowMode {
    DISABLED = 0,
    ENABLED = 1,
    CAST_ONLY = 2,
    RECEIVE_ONLY = 3
}
//# sourceMappingURL=CZMShadowMode.d.ts.map