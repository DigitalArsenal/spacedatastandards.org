export declare enum CZMClockStep {
    TICK_DEPENDENT = 0,
    SYSTEM_CLOCK_MULTIPLIER = 1,
    SYSTEM_CLOCK = 2
}
//# sourceMappingURL=CZMClockStep.d.ts.map