export declare enum FuzeType {
    CONTACT = 0,
    DELAY = 1,
    TIMED = 2,
    PROXIMITY = 3,
    AIRBURST = 4,
    MAGNETIC = 5,
    PRESSURE = 6,
    SEISMIC = 7
}
//# sourceMappingURL=FuzeType.d.ts.map