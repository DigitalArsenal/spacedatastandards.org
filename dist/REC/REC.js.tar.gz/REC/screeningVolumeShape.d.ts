export declare enum screeningVolumeShape {
    ELLIPSOID = 0,
    BOX = 1
}
//# sourceMappingURL=screeningVolumeShape.d.ts.map