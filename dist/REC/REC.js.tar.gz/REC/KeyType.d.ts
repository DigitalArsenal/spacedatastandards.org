export declare enum KeyType {
    Signing = 0,
    Encryption = 1
}
//# sourceMappingURL=KeyType.d.ts.map