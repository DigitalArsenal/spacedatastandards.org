export declare enum DriveType {
    TRACKED = 0,
    WHEELED_4X4 = 1,
    WHEELED_6X6 = 2,
    WHEELED_8X8 = 3,
    HALF_TRACK = 4
}
//# sourceMappingURL=DriveType.d.ts.map