export declare enum CountermeasureStatus {
    READY = 0,
    DEPLOYING = 1,
    ACTIVE = 2,
    EXPENDED = 3,
    RELOADING = 4,
    FAILED = 5
}
//# sourceMappingURL=CountermeasureStatus.d.ts.map