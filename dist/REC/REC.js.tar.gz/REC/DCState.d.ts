export declare enum DCState {
    NORMAL = 0,
    MINOR_DAMAGE = 1,
    MODERATE_DAMAGE = 2,
    SEVERE_DAMAGE = 3,
    CRITICAL = 4,
    SINKING = 5,
    ABANDONED = 6
}
//# sourceMappingURL=DCState.d.ts.map