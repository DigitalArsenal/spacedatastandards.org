export declare enum KMLViewRefreshMode {
    NEVER = 0,
    ON_STOP = 1,
    ON_REQUEST = 2,
    ON_REGION = 3
}
//# sourceMappingURL=KMLViewRefreshMode.d.ts.map