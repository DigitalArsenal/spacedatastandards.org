export declare enum CZMStripeOrientation {
    HORIZONTAL = 0,
    VERTICAL = 1
}
//# sourceMappingURL=CZMStripeOrientation.d.ts.map