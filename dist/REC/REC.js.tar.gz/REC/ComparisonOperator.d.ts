/**
 * Comparison operators for match criteria and conditions
 */
export declare enum ComparisonOperator {
    /**
     * Equal to
     */
    EQ = 0,
    /**
     * Not equal to
     */
    NE = 1,
    /**
     * Greater than
     */
    GT = 2,
    /**
     * Less than
     */
    LT = 3,
    /**
     * Greater than or equal to
     */
    GE = 4,
    /**
     * Less than or equal to
     */
    LE = 5,
    /**
     * String starts with
     */
    STARTS_WITH = 6,
    /**
     * String ends with
     */
    ENDS_WITH = 7,
    /**
     * String contains
     */
    CONTAINS = 8,
    /**
     * String does not start with
     */
    NOT_STARTS_WITH = 9,
    /**
     * String does not end with
     */
    NOT_ENDS_WITH = 10,
    /**
     * String does not contain
     */
    NOT_CONTAINS = 11
}
//# sourceMappingURL=ComparisonOperator.d.ts.map