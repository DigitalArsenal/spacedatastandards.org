/**
 * What was found. Append new values only.
 */
export declare enum evlEventType {
    UNSPECIFIED = 0,
    /**
     * Total occultation of the illuminating body.
     */
    UMBRA = 1,
    /**
     * Partial occultation of the illuminating body.
     */
    PENUMBRA = 2,
    /**
     * The occulting body is fully inside the illuminating body disc.
     */
    ANTUMBRA = 3,
    /**
     * The target crossed the constraint boundary into visibility.
     */
    RISE = 4,
    /**
     * The target crossed the constraint boundary out of visibility.
     */
    SET = 5,
    /**
     * Entry into a bounded volume or field of view.
     */
    ENTRY = 6,
    /**
     * Exit from a bounded volume or field of view.
     */
    EXIT = 7,
    /**
     * Maximum orbital radius.
     */
    APOAPSIS = 8,
    /**
     * Minimum orbital radius.
     */
    PERIAPSIS = 9,
    /**
     * Node crossing with the out-of-plane component increasing.
     */
    ASCENDING_NODE = 10,
    /**
     * Node crossing with the out-of-plane component decreasing.
     */
    DESCENDING_NODE = 11,
    /**
     * A $PCE parameter condition was attained.
     */
    CONDITION_SATISFIED = 12
}
//# sourceMappingURL=evlEventType.d.ts.map