/**
 * Solar radiation pressure model family. CANNONBALL uses the
 * radiation-pressure coefficient and area-to-mass ratio of the force
 * configuration; GNSS_BOX_WING is the a priori box-wing model of the
 * spacecraft block in GNSS_BLOCK (Rodriguez-Solano, Hugentobler and
 * Steigenberger 2012, Adv. Space Res. 49, doi:10.1016/j.asr.2012.01.016)
 * under nominal yaw steering, with the mass INITIAL_MASS_KG.
 */
export declare enum prwRadiationPressureFamily {
    CANNONBALL = 0,
    GNSS_BOX_WING = 1,
    NONE = 2
}
//# sourceMappingURL=prwRadiationPressureFamily.d.ts.map