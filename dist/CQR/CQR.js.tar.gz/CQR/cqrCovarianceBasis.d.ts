/**
 * Where an object's position covariance at TCA came from.
 */
export declare enum cqrCovarianceBasis {
    UNSPECIFIED = 0,
    /**
     * None: the source supplied no covariance (an element set carries none).
     */
    NONE = 1,
    /**
     * The source's ephemeris or orbit message (OEM or OCM covariance).
     */
    SOURCE_EPHEMERIS = 2,
    /**
     * A conjunction data message.
     */
    CONJUNCTION_MESSAGE = 3,
    /**
     * The formal covariance of an orbit-determination fit.
     */
    ORBIT_DETERMINATION = 4,
    /**
     * An empirical prediction-error model for the source's element sets.
     */
    EMPIRICAL_MODEL = 5
}
//# sourceMappingURL=cqrCovarianceBasis.d.ts.map