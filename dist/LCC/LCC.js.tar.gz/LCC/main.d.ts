export { LCC, LCCT } from './LCC.js';
export { legacyCountryCode } from './legacyCountryCode.js';
//# sourceMappingURL=main.d.ts.map