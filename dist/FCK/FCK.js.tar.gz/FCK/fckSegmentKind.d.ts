/**
 * FlatSQL Checkpoint.
 *
 * A checkpoint frame in a FlatSQL feed stream (store format 5). The first frame
 * of every stream is a genesis FCK naming the feed. Later FCKs list the live
 * state segments ($FSG) and the feed's counters, so a feed opens from its newest
 * FCK plus the FMB frames after APPLIED_THROUGH. Segment state is a derived
 * snapshot; the records and their FMB frames are authoritative. Spec: flatsql
 * cpp/src/p4/FORMAT.md section 3.2.
 * The kind of a state segment ($FSG).
 */
export declare enum fckSegmentKind {
    /**
     * Dictionary entries (FSG.ENTRIES).
     */
    DICTIONARY = 0,
    /**
     * Latest record per object (FSG.LATEST); the newest entry wins across segments.
     */
    LATEST = 1,
    /**
     * Per-instance counters (FSG.INSTANCES).
     */
    INSTANCES = 2,
    /**
     * Per-producer-token counters (FSG.TOKENS).
     */
    TOKENS = 3,
    /**
     * Removed rows (FSG.PAIRS, KEY_HI = rid).
     */
    TOMBSTONES = 4,
    /**
     * Row orders (FSG.PAIRS).
     */
    ROWS_BY_SEQ = 5,
    ROWS_BY_OBJECT_EPOCH = 6,
    ROWS_BY_CID = 7,
    ROWS_BY_W = 8,
    ROWS_BY_AT = 9,
    /**
     * Reserved for analytics column segments (64..127).
     */
    COLUMN = 64,
    ZONE_MAP = 65,
    ROLLUP = 66
}
//# sourceMappingURL=fckSegmentKind.d.ts.map