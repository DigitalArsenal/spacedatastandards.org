export { CTR, CTRT } from './CTR.js';
//# sourceMappingURL=main.d.ts.map