export declare enum SONPropagationModel {
    RAY_TRACING = 0,
    PARABOLIC_EQUATION = 1,
    NORMAL_MODES = 2,
    ISOVELOCITY = 3,
    RANGE_DEPENDENT = 4,
    FAST_FIELD = 5
}
//# sourceMappingURL=SONPropagationModel.d.ts.map