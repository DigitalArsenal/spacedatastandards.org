export declare enum TargetType {
    SUBMARINE = 0,
    SURFACE_SHIP = 1,
    TORPEDO = 2,
    MINE = 3,
    BIOLOGICAL = 4,
    WRECK = 5,
    UNKNOWN = 6
}
//# sourceMappingURL=TargetType.d.ts.map