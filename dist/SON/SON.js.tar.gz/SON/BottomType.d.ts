export declare enum BottomType {
    HARD_ROCK = 0,
    SOFT_ROCK = 1,
    SAND = 2,
    SILT = 3,
    CLAY = 4,
    MUD = 5,
    GRAVEL = 6,
    CORAL = 7,
    MIXED = 8
}
//# sourceMappingURL=BottomType.d.ts.map