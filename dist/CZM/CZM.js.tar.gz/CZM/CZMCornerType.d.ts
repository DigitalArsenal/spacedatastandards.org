export declare enum CZMCornerType {
    ROUNDED = 0,
    MITERED = 1,
    BEVELED = 2
}
//# sourceMappingURL=CZMCornerType.d.ts.map