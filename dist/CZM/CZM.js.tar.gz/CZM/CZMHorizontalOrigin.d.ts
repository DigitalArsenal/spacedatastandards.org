export declare enum CZMHorizontalOrigin {
    LEFT = 0,
    CENTER = 1,
    RIGHT = 2
}
//# sourceMappingURL=CZMHorizontalOrigin.d.ts.map