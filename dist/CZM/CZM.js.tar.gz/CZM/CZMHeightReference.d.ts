export declare enum CZMHeightReference {
    NONE = 0,
    CLAMP_TO_GROUND = 1,
    RELATIVE_TO_GROUND = 2
}
//# sourceMappingURL=CZMHeightReference.d.ts.map