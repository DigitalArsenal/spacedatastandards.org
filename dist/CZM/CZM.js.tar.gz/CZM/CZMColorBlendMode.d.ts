export declare enum CZMColorBlendMode {
    HIGHLIGHT = 0,
    REPLACE = 1,
    MIX = 2
}
//# sourceMappingURL=CZMColorBlendMode.d.ts.map