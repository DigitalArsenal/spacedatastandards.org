export declare enum CZMClassificationType {
    TERRAIN = 0,
    CESIUM_3D_TILE = 1,
    BOTH = 2
}
//# sourceMappingURL=CZMClassificationType.d.ts.map