export declare enum CZMLabelStyle {
    FILL = 0,
    OUTLINE = 1,
    FILL_AND_OUTLINE = 2
}
//# sourceMappingURL=CZMLabelStyle.d.ts.map