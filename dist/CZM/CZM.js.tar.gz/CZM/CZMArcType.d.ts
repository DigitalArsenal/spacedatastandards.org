export declare enum CZMArcType {
    NONE = 0,
    GEODESIC = 1,
    RHUMB = 2
}
//# sourceMappingURL=CZMArcType.d.ts.map