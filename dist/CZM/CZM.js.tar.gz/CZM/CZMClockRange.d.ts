export declare enum CZMClockRange {
    UNBOUNDED = 0,
    CLAMPED = 1,
    LOOP_STOP = 2
}
//# sourceMappingURL=CZMClockRange.d.ts.map