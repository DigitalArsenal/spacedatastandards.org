export declare enum meanElementSource {
    /**
     * Simplified General Perturbation Model 4
     */
    SGP4 = 0,
    /**
     * Simplified General Perturbation Model 4 eXtended Perturbations (SGP4-XP),
     * as published in the 2022 astrodynamics conference literature.
     */
    SGP4XP = 1,
    /**
     * Draper Semi-analytical Satellite Theory
     */
    DSST = 2,
    /**
     * Universal Semianalytical Method
     */
    USM = 3,
    /**
     * SDN Advanced Propagator (AP): an advanced propagator that builds on the entire history of astrodynamics
     * (NRLMSISE-00 drag on the day's space weather; tesseral and zonal gravity terms). Its sets fly only on
     * AP. 4 is left unused: it was a cut value of an earlier theory.
     */
    AP = 5,
    /**
     * Not stated. A reader of an element set refuses UNSPECIFIED by name: the theory of a
     * set is always written.
     */
    UNSPECIFIED = 6
}
//# sourceMappingURL=meanElementSource.d.ts.map