/**
 * Where the space weather of a propagation comes from. Append new values
 * only.
 */
export declare enum pcfWeatherSource {
    /**
     * Infer: PCFSpaceWeather when the force model carries it, else the daily
     * rows supplied with the request.
     */
    UNSPECIFIED = 0,
    /**
     * PCFSpaceWeather, held for the whole arc.
     */
    CONSTANT = 1,
    /**
     * Daily rows supplied with the request ($SPW rows; the JB2008 indices
     * for the JB2008 atmosphere). In an $OCM element set, the rows of
     * PERTURBATIONS.SPACE_WEATHER.
     */
    RECORDS = 2,
    /**
     * The theory's own generic flux model: no rows, no PCFSpaceWeather (a
     * mean-element theory's built-in solar and geomagnetic activity).
     */
    THEORY_FLUX_MODEL = 3,
    /**
     * No drag weather: the theory's own drag term (SGP4's BSTAR).
     */
    NONE = 4
}
//# sourceMappingURL=pcfWeatherSource.d.ts.map