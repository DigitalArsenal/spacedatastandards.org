import * as flatbuffers from 'flatbuffers';
import { CVR, CVRT } from './CVR.js';
import { OMMUserDefinedParameter, OMMUserDefinedParameterT } from './OMMUserDefinedParameter.js';
import { PVN, PVNT } from './PVN.js';
import { RFM, RFMT } from './RFM.js';
import { ephemerisFormat } from './ephemerisFormat.js';
import { meanElementSource } from './meanElementSource.js';
import { timingStandard } from './timingStandard.js';
/**
 * Orbit Mean Elements Message
 */
export declare class OMM implements flatbuffers.IUnpackableObject<OMMT> {
    bb: flatbuffers.ByteBuffer | null;
    bb_pos: number;
    __init(i: number, bb: flatbuffers.ByteBuffer): OMM;
    static getRootAsOMM(bb: flatbuffers.ByteBuffer, obj?: OMM): OMM;
    static getSizePrefixedRootAsOMM(bb: flatbuffers.ByteBuffer, obj?: OMM): OMM;
    static bufferHasIdentifier(bb: flatbuffers.ByteBuffer): boolean;
    /**
     * CCSDS OMM Version
     */
    CCSDS_OMM_VERS(): number;
    /**
     * Creation Date (ISO 8601 UTC format)
     */
    CREATION_DATE(): string | null;
    CREATION_DATE(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Originator
     */
    ORIGINATOR(): string | null;
    ORIGINATOR(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Satellite Name(s)
     */
    OBJECT_NAME(): string | null;
    OBJECT_NAME(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * International Designator (YYYY-NNNAAA)
     */
    OBJECT_ID(): string | null;
    OBJECT_ID(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Center Name (e.g. EARTH, MARS). A set about another body names it: MOON,
     * SUN or a planet.
     */
    CENTER_NAME(): string | null;
    CENTER_NAME(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Reference Frame
     * Typically TEMEOFDATE
     * The Earth-Moon synodic (rotating) frame of a libration-point orbit is the
     * RFMCoordinateSystem with AXIS_TYPE OBJECT_REFERENCED: OBJECT_REFERENCED_AXES
     * names the Earth as PRIMARY_OBJECT_ID and the Moon as SECONDARY_OBJECT_ID
     * (ephemeris body codes 399 and 301, as text), X_AXIS RADIAL and Z_AXIS
     * ORBIT_NORMAL, Y completing the triad; ORIGIN is the Moon (CELESTIAL_BODY),
     * the Earth-Moon barycenter (BARYCENTRE) or the libration point
     * (LIBRATION_POINT with its primary and secondary). No other frame value is
     * needed for it.
     */
    REFERENCE_FRAME(obj?: RFM): RFM | null;
    /**
     * Reference Frame Epoch (ISO 8601 UTC format)
     */
    REFERENCE_FRAME_EPOCH(): string | null;
    REFERENCE_FRAME_EPOCH(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Time System [M, UTC]
     */
    TIME_SYSTEM(): timingStandard;
    /**
     * Mean Element Theory
     */
    MEAN_ELEMENT_THEORY(): meanElementSource;
    /**
     * COMMENT (O): every COMMENT line of the message, in message order, joined by
     * a line feed. A message states comments in its header, its metadata and each
     * data group; this field holds them all, so a message written from the record
     * states them together in its header.
     */
    COMMENT(): string | null;
    COMMENT(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * EPOCH of Mean Keplerian elements (ISO 8601 UTC format)
     */
    EPOCH(): string | null;
    EPOCH(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Semi-major axis in km or Mean Motion in rev/day
     */
    SEMI_MAJOR_AXIS(): number;
    /**
     * Mean motion in rev/day if MEAN_ELEMENT_THEORY=SGP/SGP4 else unused
     */
    MEAN_MOTION(): number;
    /**
     * Eccentricity (unitless)
     */
    ECCENTRICITY(): number;
    /**
     * Inclination in degrees
     */
    INCLINATION(): number;
    /**
     * RA_OF_ASC_NODE in degrees
     */
    RA_OF_ASC_NODE(): number;
    /**
     * ARG_OF_PERICENTER in degrees
     */
    ARG_OF_PERICENTER(): number;
    /**
     * MEAN_ANOMALY in degrees
     */
    MEAN_ANOMALY(): number;
    /**
     * GM in km**3/s**2
     */
    GM(): number;
    /**
     * MASS in kg
     */
    MASS(): number;
    /**
     * SOLAR_RAD_AREA in m**2
     */
    SOLAR_RAD_AREA(): number;
    /**
     * SOLAR_RAD_COEFF (unitless)
     */
    SOLAR_RAD_COEFF(): number;
    /**
     * DRAG_AREA in m**2
     */
    DRAG_AREA(): number;
    /**
     * DRAG_COEFF (unitless)
     */
    DRAG_COEFF(): number;
    /**
     * TLE Related Parameters (Only if MEAN_ELEMENT_THEORY=SGP/SGP4)
     * EPHEMERIS_TYPE Default=0
     */
    EPHEMERIS_TYPE(): ephemerisFormat;
    /**
     * CLASSIFICATION_TYPE Default=U
     */
    CLASSIFICATION_TYPE(): string | null;
    CLASSIFICATION_TYPE(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * NORAD_CAT_ID (integer) [O if SGP/SGP4]
     */
    NORAD_CAT_ID(): number;
    /**
     * ELEMENT_SET_NO [O if SGP/SGP4]
     */
    ELEMENT_SET_NO(): number;
    /**
     * REV_AT_EPOCH [O if SGP/SGP4]
     */
    REV_AT_EPOCH(): number;
    /**
     * BSTAR in 1/Earth radii [C: MEAN_ELEMENT_THEORY SGP4]. An SGP4-XP set carries BTERM instead, never both.
     */
    BSTAR(): number;
    /**
     * MEAN_MOTION_DOT in rev/day**2 [C if SGP or PPT3]
     */
    MEAN_MOTION_DOT(): number;
    /**
     * MEAN_MOTION_DDOT in rev/day**3 [C: SGP or PPT3]. An SGP4-XP set carries AGOM instead, never both.
     */
    MEAN_MOTION_DDOT(): number;
    /**
     * Position/Velocity Covariance Matrix (6x6 Lower Triangular) [C if any covariance provided]
     * COV_REF_FRAME reference frame for covariance [C if covariance given]
     * Typically RSW
     */
    COV_REFERENCE_FRAME(obj?: RFM): RFM | null;
    /**
     * Covariance matrix as flat array (6x6 lower triangular = 21 elements).
     * Order: [CX_X, CY_X, CY_Y, CZ_X, CZ_Y, CZ_Z,
     *         CX_DOT_X, CX_DOT_Y, CX_DOT_Z, CX_DOT_X_DOT,
     *         CY_DOT_X, CY_DOT_Y, CY_DOT_Z, CY_DOT_X_DOT, CY_DOT_Y_DOT,
     *         CZ_DOT_X, CZ_DOT_Y, CZ_DOT_Z, CZ_DOT_X_DOT, CZ_DOT_Y_DOT, CZ_DOT_Z_DOT]
     * Units: position in km**2, velocity in km**2/s**2, cross in km**2/s
     */
    COVARIANCE(index: number): number | null;
    covarianceLength(): number;
    covarianceArray(): Float64Array | null;
    /**
     * USER_DEFINED_BIP_0044_TYPE [O, units per ICD]
     */
    USER_DEFINED_BIP_0044_TYPE(): number;
    /**
     * USER_DEFINED_OBJECT_DESIGNATOR [O, units per ICD]
     */
    USER_DEFINED_OBJECT_DESIGNATOR(): string | null;
    USER_DEFINED_OBJECT_DESIGNATOR(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * USER_DEFINED_EARTH_MODEL [O, units per ICD]
     */
    USER_DEFINED_EARTH_MODEL(): string | null;
    USER_DEFINED_EARTH_MODEL(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * USER_DEFINED_EPOCH_TIMESTAMP [O, units per ICD]
     */
    USER_DEFINED_EPOCH_TIMESTAMP(): number;
    /**
     * USER_DEFINED_MICROSECONDS [O, units per ICD]
     */
    USER_DEFINED_MICROSECONDS(): number;
    /**
     * CLASSIFICATION of the message: the optional CCSDS 502.0-B-3 header keyword
     * that states its security classification or handling caveat. Not
     * CLASSIFICATION_TYPE, which is the TLE element set's U, C or S.
     */
    CLASSIFICATION(): string | null;
    CLASSIFICATION(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * MESSAGE_ID: the optional CCSDS 502.0-B-3 header keyword, an identifier the
     * originator makes unique for this message.
     */
    MESSAGE_ID(): string | null;
    MESSAGE_ID(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Every USER_DEFINED_x keyword (KVN) or USER_DEFINED element (NDM/XML) of the
     * message that has no dedicated field above, in message order.
     */
    USER_DEFINED_PARAMETERS(index: number, obj?: OMMUserDefinedParameter): OMMUserDefinedParameter | null;
    userDefinedParametersLength(): number;
    /**
     * Where the element set comes from and the terms it travels under.
     */
    PROVENANCE(obj?: PVN): PVN | null;
    /**
     * Realism of COVARIANCE.
     */
    COV_REALISM(obj?: CVR): CVR | null;
    /**
     * BTERM (CCSDS 502.0-B-3 Table 4-3, "BSTAR or BTERM"): the drag-like ballistic coefficient of an
     * SGP4-XP set, Cd*A/m in m**2/kg [C: MEAN_ELEMENT_THEORY SGP4-XP]. A writer sets BSTAR and
     * MEAN_MOTION_DDOT for SGP4 and BTERM and AGOM for SGP4-XP, never both pairs; the KVN and XML
     * renderers write the keyword MEAN_ELEMENT_THEORY selects. 0 for SGP4.
     */
    BTERM(): number;
    /**
     * AGOM (CCSDS 502.0-B-3 Table 4-3, "MEAN_MOTION_DDOT or AGOM"): the solar radiation pressure
     * coefficient of an SGP4-XP set, gamma*A/m in m**2/kg [C: MEAN_ELEMENT_THEORY SGP4-XP]. 0 for SGP4.
     */
    AGOM(): number;
    static startOMM(builder: flatbuffers.Builder): void;
    static addCcsdsOmmVers(builder: flatbuffers.Builder, CCSDS_OMM_VERS: number): void;
    static addCreationDate(builder: flatbuffers.Builder, CREATION_DATEOffset: flatbuffers.Offset): void;
    static addOriginator(builder: flatbuffers.Builder, ORIGINATOROffset: flatbuffers.Offset): void;
    static addObjectName(builder: flatbuffers.Builder, OBJECT_NAMEOffset: flatbuffers.Offset): void;
    static addObjectId(builder: flatbuffers.Builder, OBJECT_IDOffset: flatbuffers.Offset): void;
    static addCenterName(builder: flatbuffers.Builder, CENTER_NAMEOffset: flatbuffers.Offset): void;
    static addReferenceFrame(builder: flatbuffers.Builder, REFERENCE_FRAMEOffset: flatbuffers.Offset): void;
    static addReferenceFrameEpoch(builder: flatbuffers.Builder, REFERENCE_FRAME_EPOCHOffset: flatbuffers.Offset): void;
    static addTimeSystem(builder: flatbuffers.Builder, TIME_SYSTEM: timingStandard): void;
    static addMeanElementTheory(builder: flatbuffers.Builder, MEAN_ELEMENT_THEORY: meanElementSource): void;
    static addComment(builder: flatbuffers.Builder, COMMENTOffset: flatbuffers.Offset): void;
    static addEpoch(builder: flatbuffers.Builder, EPOCHOffset: flatbuffers.Offset): void;
    static addSemiMajorAxis(builder: flatbuffers.Builder, SEMI_MAJOR_AXIS: number): void;
    static addMeanMotion(builder: flatbuffers.Builder, MEAN_MOTION: number): void;
    static addEccentricity(builder: flatbuffers.Builder, ECCENTRICITY: number): void;
    static addInclination(builder: flatbuffers.Builder, INCLINATION: number): void;
    static addRaOfAscNode(builder: flatbuffers.Builder, RA_OF_ASC_NODE: number): void;
    static addArgOfPericenter(builder: flatbuffers.Builder, ARG_OF_PERICENTER: number): void;
    static addMeanAnomaly(builder: flatbuffers.Builder, MEAN_ANOMALY: number): void;
    static addGm(builder: flatbuffers.Builder, GM: number): void;
    static addMass(builder: flatbuffers.Builder, MASS: number): void;
    static addSolarRadArea(builder: flatbuffers.Builder, SOLAR_RAD_AREA: number): void;
    static addSolarRadCoeff(builder: flatbuffers.Builder, SOLAR_RAD_COEFF: number): void;
    static addDragArea(builder: flatbuffers.Builder, DRAG_AREA: number): void;
    static addDragCoeff(builder: flatbuffers.Builder, DRAG_COEFF: number): void;
    static addEphemerisType(builder: flatbuffers.Builder, EPHEMERIS_TYPE: ephemerisFormat): void;
    static addClassificationType(builder: flatbuffers.Builder, CLASSIFICATION_TYPEOffset: flatbuffers.Offset): void;
    static addNoradCatId(builder: flatbuffers.Builder, NORAD_CAT_ID: number): void;
    static addElementSetNo(builder: flatbuffers.Builder, ELEMENT_SET_NO: number): void;
    static addRevAtEpoch(builder: flatbuffers.Builder, REV_AT_EPOCH: number): void;
    static addBstar(builder: flatbuffers.Builder, BSTAR: number): void;
    static addMeanMotionDot(builder: flatbuffers.Builder, MEAN_MOTION_DOT: number): void;
    static addMeanMotionDdot(builder: flatbuffers.Builder, MEAN_MOTION_DDOT: number): void;
    static addCovReferenceFrame(builder: flatbuffers.Builder, COV_REFERENCE_FRAMEOffset: flatbuffers.Offset): void;
    static addCovariance(builder: flatbuffers.Builder, COVARIANCEOffset: flatbuffers.Offset): void;
    static createCovarianceVector(builder: flatbuffers.Builder, data: number[] | Float64Array): flatbuffers.Offset;
    /**
     * @deprecated This Uint8Array overload will be removed in the future.
     */
    static createCovarianceVector(builder: flatbuffers.Builder, data: number[] | Uint8Array): flatbuffers.Offset;
    static startCovarianceVector(builder: flatbuffers.Builder, numElems: number): void;
    static addUserDefinedBip0044Type(builder: flatbuffers.Builder, USER_DEFINED_BIP_0044_TYPE: number): void;
    static addUserDefinedObjectDesignator(builder: flatbuffers.Builder, USER_DEFINED_OBJECT_DESIGNATOROffset: flatbuffers.Offset): void;
    static addUserDefinedEarthModel(builder: flatbuffers.Builder, USER_DEFINED_EARTH_MODELOffset: flatbuffers.Offset): void;
    static addUserDefinedEpochTimestamp(builder: flatbuffers.Builder, USER_DEFINED_EPOCH_TIMESTAMP: number): void;
    static addUserDefinedMicroseconds(builder: flatbuffers.Builder, USER_DEFINED_MICROSECONDS: number): void;
    static addClassification(builder: flatbuffers.Builder, CLASSIFICATIONOffset: flatbuffers.Offset): void;
    static addMessageId(builder: flatbuffers.Builder, MESSAGE_IDOffset: flatbuffers.Offset): void;
    static addUserDefinedParameters(builder: flatbuffers.Builder, USER_DEFINED_PARAMETERSOffset: flatbuffers.Offset): void;
    static createUserDefinedParametersVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startUserDefinedParametersVector(builder: flatbuffers.Builder, numElems: number): void;
    static addProvenance(builder: flatbuffers.Builder, PROVENANCEOffset: flatbuffers.Offset): void;
    static addCovRealism(builder: flatbuffers.Builder, COV_REALISMOffset: flatbuffers.Offset): void;
    static addBterm(builder: flatbuffers.Builder, BTERM: number): void;
    static addAgom(builder: flatbuffers.Builder, AGOM: number): void;
    static endOMM(builder: flatbuffers.Builder): flatbuffers.Offset;
    static finishOMMBuffer(builder: flatbuffers.Builder, offset: flatbuffers.Offset): void;
    static finishSizePrefixedOMMBuffer(builder: flatbuffers.Builder, offset: flatbuffers.Offset): void;
    unpack(): OMMT;
    unpackTo(_o: OMMT): void;
}
export declare class OMMT implements flatbuffers.IGeneratedObject {
    CCSDS_OMM_VERS: number;
    CREATION_DATE: string | Uint8Array | null;
    ORIGINATOR: string | Uint8Array | null;
    OBJECT_NAME: string | Uint8Array | null;
    OBJECT_ID: string | Uint8Array | null;
    CENTER_NAME: string | Uint8Array | null;
    REFERENCE_FRAME: RFMT | null;
    REFERENCE_FRAME_EPOCH: string | Uint8Array | null;
    TIME_SYSTEM: timingStandard;
    MEAN_ELEMENT_THEORY: meanElementSource;
    COMMENT: string | Uint8Array | null;
    EPOCH: string | Uint8Array | null;
    SEMI_MAJOR_AXIS: number;
    MEAN_MOTION: number;
    ECCENTRICITY: number;
    INCLINATION: number;
    RA_OF_ASC_NODE: number;
    ARG_OF_PERICENTER: number;
    MEAN_ANOMALY: number;
    GM: number;
    MASS: number;
    SOLAR_RAD_AREA: number;
    SOLAR_RAD_COEFF: number;
    DRAG_AREA: number;
    DRAG_COEFF: number;
    EPHEMERIS_TYPE: ephemerisFormat;
    CLASSIFICATION_TYPE: string | Uint8Array | null;
    NORAD_CAT_ID: number;
    ELEMENT_SET_NO: number;
    REV_AT_EPOCH: number;
    BSTAR: number;
    MEAN_MOTION_DOT: number;
    MEAN_MOTION_DDOT: number;
    COV_REFERENCE_FRAME: RFMT | null;
    COVARIANCE: (number)[];
    USER_DEFINED_BIP_0044_TYPE: number;
    USER_DEFINED_OBJECT_DESIGNATOR: string | Uint8Array | null;
    USER_DEFINED_EARTH_MODEL: string | Uint8Array | null;
    USER_DEFINED_EPOCH_TIMESTAMP: number;
    USER_DEFINED_MICROSECONDS: number;
    CLASSIFICATION: string | Uint8Array | null;
    MESSAGE_ID: string | Uint8Array | null;
    USER_DEFINED_PARAMETERS: (OMMUserDefinedParameterT)[];
    PROVENANCE: PVNT | null;
    COV_REALISM: CVRT | null;
    BTERM: number;
    AGOM: number;
    constructor(CCSDS_OMM_VERS?: number, CREATION_DATE?: string | Uint8Array | null, ORIGINATOR?: string | Uint8Array | null, OBJECT_NAME?: string | Uint8Array | null, OBJECT_ID?: string | Uint8Array | null, CENTER_NAME?: string | Uint8Array | null, REFERENCE_FRAME?: RFMT | null, REFERENCE_FRAME_EPOCH?: string | Uint8Array | null, TIME_SYSTEM?: timingStandard, MEAN_ELEMENT_THEORY?: meanElementSource, COMMENT?: string | Uint8Array | null, EPOCH?: string | Uint8Array | null, SEMI_MAJOR_AXIS?: number, MEAN_MOTION?: number, ECCENTRICITY?: number, INCLINATION?: number, RA_OF_ASC_NODE?: number, ARG_OF_PERICENTER?: number, MEAN_ANOMALY?: number, GM?: number, MASS?: number, SOLAR_RAD_AREA?: number, SOLAR_RAD_COEFF?: number, DRAG_AREA?: number, DRAG_COEFF?: number, EPHEMERIS_TYPE?: ephemerisFormat, CLASSIFICATION_TYPE?: string | Uint8Array | null, NORAD_CAT_ID?: number, ELEMENT_SET_NO?: number, REV_AT_EPOCH?: number, BSTAR?: number, MEAN_MOTION_DOT?: number, MEAN_MOTION_DDOT?: number, COV_REFERENCE_FRAME?: RFMT | null, COVARIANCE?: (number)[], USER_DEFINED_BIP_0044_TYPE?: number, USER_DEFINED_OBJECT_DESIGNATOR?: string | Uint8Array | null, USER_DEFINED_EARTH_MODEL?: string | Uint8Array | null, USER_DEFINED_EPOCH_TIMESTAMP?: number, USER_DEFINED_MICROSECONDS?: number, CLASSIFICATION?: string | Uint8Array | null, MESSAGE_ID?: string | Uint8Array | null, USER_DEFINED_PARAMETERS?: (OMMUserDefinedParameterT)[], PROVENANCE?: PVNT | null, COV_REALISM?: CVRT | null, BTERM?: number, AGOM?: number);
    pack(builder: flatbuffers.Builder): flatbuffers.Offset;
}
//# sourceMappingURL=OMM.d.ts.map