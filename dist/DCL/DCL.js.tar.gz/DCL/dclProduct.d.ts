/**
 * Density Calibration (DCL)
 * Description
 * A calibration of a thermospheric density model and the results computed
 * with it. A calibration may be a dimensionless common-mode log-density
 * scale for NRLMSISE-00, or a correction to the model's exospheric
 * temperature (added where the model adds its geomagnetic term, so a
 * constant correction is the same as raising every hourly Dst-derived
 * temperature change by that amount), estimated either from observed
 * densities (accelerometer or precise-orbit densities) or from the orbital
 * decay of catalogued objects, in the manner of the Dynamic Calibration of
 * the Atmosphere in the High Accuracy Satellite Drag Model. The correction
 * is either spherical harmonics in latitude and local solar time per time
 * bin, or values at time nodes, optionally at several altitudes.
 *
 * The same record carries what a calibration is for: density at points
 * with the correction applied; the drag decay of element-set histories;
 * the orbital energy of states (the Jacobi integral of the geopotential in
 * Earth-fixed axes, conserved when only gravity acts, and its gradient);
 * and the drag power and work along a trajectory. Each comes with the fit
 * statistics (residual RMS before and after, chi-square, iterations,
 * formal sigmas, points used and edited) that say how far to trust it.
 * Orbit-determination and conjunction-assessment teams use it to correct
 * drag, and space-weather analysts to compare models.
 *
 * DCL names the model with $ATM, takes the model's drivers as published:
 * the JB2008 daily solar indices and the hourly Dst-derived exospheric
 * temperature change (K) as $PRW PRWJB2008Indices rows, and the daily
 * space weather an NRLMSISE-00 evaluation reads (F10.7, its 81-day mean,
 * Ap) as $SPW rows. Element-set histories are $OMM records and state
 * trajectories $OEM ephemeris blocks. $HFC carries flow conditions
 * (density, Mach, heating) along an entry trajectory; a DCL density
 * evaluation along the same trajectory supplies its calibrated density.
 *
 * Times are Unix milliseconds (UTC); densities kg/m^3; temperatures K;
 * log-density scales are dimensionless ln(corrected density / model density).
 * What a record computes. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum dclProduct {
    /**
     * Not stated.
     */
    Unspecified = 0,
    /**
     * Density at points, with the correction applied.
     */
    DensityEvaluation = 1,
    /**
     * Harmonic correction per time bin, fitted to observed densities.
     */
    DensityCalibration = 2,
    /**
     * Drag decay of element-set histories (the forward model).
     */
    OrbitalDecay = 3,
    /**
     * Node correction and ballistic coefficients fitted to orbital decay.
     */
    DecayCalibration = 4,
    /**
     * Orbital energy (Jacobi integral of the geopotential) of states.
     */
    OrbitalEnergy = 5,
    /**
     * Drag power and work along a trajectory.
     */
    DragWork = 6
}
//# sourceMappingURL=dclProduct.d.ts.map