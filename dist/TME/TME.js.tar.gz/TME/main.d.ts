export { ClockType } from './ClockType.js';
export { DateFormat } from './DateFormat.js';
export { TME, TMET } from './TME.js';
export { TimeScale } from './TimeScale.js';
//# sourceMappingURL=main.d.ts.map