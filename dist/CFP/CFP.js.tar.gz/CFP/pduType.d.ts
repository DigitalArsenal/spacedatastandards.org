export declare enum pduType {
    FILE_DIRECTIVE = 0,
    FILE_DATA = 1
}
//# sourceMappingURL=pduType.d.ts.map