export declare enum transmissionMode {
    ACKNOWLEDGED = 0,
    UNACKNOWLEDGED = 1
}
//# sourceMappingURL=transmissionMode.d.ts.map