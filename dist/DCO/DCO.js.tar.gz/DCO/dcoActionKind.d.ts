/**
 * Specific defensive action evaluated in this trade record. Append new values only.
 */
export declare enum dcoActionKind {
    /**
     * Not stated.
     */
    UNSPECIFIED = 0,
    /**
     * Orbital collision or threat avoidance maneuver.
     */
    MANEUVER_AVOID = 1,
    /**
     * In-plane phasing shift maneuver.
     */
    MANEUVER_PHASE_SHIFT = 2,
    /**
     * Altitude-change maneuver.
     */
    MANEUVER_ALTITUDE_CHANGE = 3,
    /**
     * RF frequency hopping countermeasure.
     */
    RF_FREQ_HOP = 4,
    /**
     * Phased-array null steering countermeasure.
     */
    RF_NULL_STEER = 5,
    /**
     * Transmit power boost countermeasure.
     */
    RF_POWER_BOOST = 6,
    /**
     * Antenna beam narrowing countermeasure.
     */
    RF_BEAM_NARROW = 7,
    /**
     * Traffic or TT&C gateway reroute.
     */
    GATEWAY_REROUTE = 8,
    /**
     * Optical or star-tracker shuttering or protective slew.
     */
    SENSOR_SHUTTER_OR_SLEW = 9,
    /**
     * Preemptive spacecraft safe-mode entry.
     */
    SAFE_MODE_PREEMPT = 10,
    /**
     * Tracking / custody sensor tasking surge.
     */
    TRACK_TASKING_SURGE = 11,
    /**
     * Ride out the event with no active maneuver or reconfiguration.
     */
    RIDE_OUT = 12
}
//# sourceMappingURL=dcoActionKind.d.ts.map