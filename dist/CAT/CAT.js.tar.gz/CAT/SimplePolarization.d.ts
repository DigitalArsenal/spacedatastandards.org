/**
 * Simple polarization types
 */
export declare enum SimplePolarization {
    vertical = 0,
    horizontal = 1,
    leftHandCircular = 2,
    rightHandCircular = 3
}
//# sourceMappingURL=SimplePolarization.d.ts.map