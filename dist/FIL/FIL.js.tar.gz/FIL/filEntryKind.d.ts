/**
 * File (FIL)
 * Description
 * A file or directory entry with, optionally, its content: a document read
 * from or written to a file system, an attachment, an uploaded artifact or a
 * downloaded product. The record names the file, describes it (size, media
 * type, times, digest) and carries its bytes verbatim when it is being moved.
 *
 * The same record serves the steps of moving a file. A request to read names
 * PATH only; the answer adds the content and description. A request to write
 * carries PATH and CONTENT; the answer states what was written (SIZE, DIGEST,
 * WRITTEN_AT_MS) without repeating the content. A directory listing is one
 * FIL with ENTRIES.
 * Kind of file system entry. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum filEntryKind {
    /**
     * Not stated.
     */
    Unspecified = 0,
    /**
     * A regular file.
     */
    File = 1,
    /**
     * A directory.
     */
    Directory = 2,
    /**
     * A symbolic link.
     */
    Link = 3
}
//# sourceMappingURL=filEntryKind.d.ts.map