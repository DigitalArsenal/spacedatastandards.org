/**
 * API Request (APR)
 * Description
 * One request received by a service endpoint, in normalized form, together
 * with the decision of how to serve it. A gateway (an HTTP server, a message
 * broker bridge, a command interface) parses whatever arrived on the wire
 * into an APR once; every later stage reads the APR instead of re-parsing the
 * transport. The same record carries the gateway's routing decision (ROUTE),
 * the request's selection parameters, its conditional-request validator, the
 * representation the client accepts, and, when the gateway or a later stage
 * refuses the request, the status and reason the client must be answered
 * with.
 *
 * An APR is transport-neutral: METHOD and STATUS follow HTTP semantics
 * because they are the common vocabulary, but nothing in the record requires
 * HTTP. A stage that serves the request passes the APR on unchanged beside
 * its answer, or with STATUS and ERROR set when it cannot serve it, so the
 * stage that writes the response always has both the request and the outcome.
 * Request method, HTTP semantics. Append new values only; never reorder or
 * reuse existing values.
 */
export declare enum aprMethod {
    /**
     * Not stated.
     */
    Unspecified = 0,
    GET = 1,
    HEAD = 2,
    POST = 3,
    PUT = 4,
    PATCH = 5,
    DELETE = 6,
    OPTIONS = 7
}
//# sourceMappingURL=aprMethod.d.ts.map