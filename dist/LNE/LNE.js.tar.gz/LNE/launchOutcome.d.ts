export declare enum launchOutcome {
    SUCCESS = 0,
    PARTIAL_SUCCESS = 1,
    FAILURE = 2,
    IN_PROGRESS = 3,
    UNKNOWN = 4
}
//# sourceMappingURL=launchOutcome.d.ts.map