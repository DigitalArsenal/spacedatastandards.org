/**
 * Quantity being aggregated.
 */
export declare enum cnpMetricKind {
    /**
     * Achieved application-layer download rate.
     */
    DOWNLOAD_THROUGHPUT = 0,
    /**
     * Achieved application-layer upload rate.
     */
    UPLOAD_THROUGHPUT = 1,
    /**
     * Round-trip time on an otherwise unloaded path.
     */
    LATENCY_IDLE = 2,
    /**
     * Round-trip time measured while the download test saturates the path.
     */
    LATENCY_LOADED_DOWNLOAD = 3,
    /**
     * Round-trip time measured while the upload test saturates the path.
     */
    LATENCY_LOADED_UPLOAD = 4,
    /**
     * Variation in inter-packet arrival time.
     */
    JITTER = 5,
    /**
     * Fraction of packets lost.
     */
    PACKET_LOSS = 6,
    /**
     * Fraction of the window in which the service was usable.
     */
    AVAILABILITY = 7,
    /**
     * Fraction of the terminal's sky view blocked by terrain or structures.
     */
    OBSTRUCTION = 8,
    /**
     * Round-trip time where the source does not distinguish loaded from idle.
     */
    RTT = 9,
    /**
     * The source publishes a quantity none of the above names.
     * SOURCE_METRIC_NAME is then required to be non-empty.
     */
    OTHER = 10
}
//# sourceMappingURL=cnpMetricKind.d.ts.map