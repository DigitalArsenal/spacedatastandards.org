/**
 * Granularity of the geography a measurement window is keyed to.
 */
export declare enum cnpRegionKind {
    /**
     * No geographic restriction — the aggregate covers everywhere the operator
     * serves.
     */
    GLOBAL = 0,
    /**
     * A country. CODE is ISO 3166-1 alpha-2.
     */
    COUNTRY = 1,
    /**
     * A first-level subdivision. CODE is ISO 3166-2.
     */
    SUBDIVISION = 2,
    /**
     * A metropolitan area or city. CODE is the source's own key.
     */
    METRO = 3,
    /**
     * A ground-segment cell or beam footprint. CODE is the operator's own key.
     */
    CELL = 4,
    /**
     * A point of presence / ground gateway. CODE is the source's own key.
     */
    POINT_OF_PRESENCE = 5,
    /**
     * The source keys by something none of the above describes. CODE and NAME
     * carry the source's key verbatim.
     */
    OTHER = 6
}
//# sourceMappingURL=cnpRegionKind.d.ts.map