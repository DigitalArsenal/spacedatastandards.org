/**
 * What a course of action does. Append new values only.
 */
export declare enum coaKind {
    /**
     * Not stated.
     */
    UNSPECIFIED = 0,
    /**
     * A maneuver. When it answers an event it is made LEAD_SECONDS before EVENT_EPOCH and is back in
     * place within RETURN_WITHIN_SECONDS after it.
     */
    MANEUVER = 1,
    /**
     * No action: the event is accepted.
     */
    RIDE_OUT = 2,
    /**
     * STEPS, in order, restore service after the event.
     */
    RECOVERY = 3,
    /**
     * RF countermeasure (frequency hop, null steer, power boost, beam narrow).
     */
    RF_COUNTERMEASURE = 4,
    /**
     * Traffic / TT&C / payload gateway reroute.
     */
    GATEWAY_REROUTE = 5,
    /**
     * Optical / star-tracker / sensor shuttering or slew protection.
     */
    SENSOR_PROTECTION = 6,
    /**
     * Preemptive spacecraft safe-mode entry (e.g. severe SEP/storm).
     */
    SAFE_MODE = 7,
    /**
     * Surge or tasking of tracking / custody sensors.
     */
    TRACK_TASKING = 8
}
//# sourceMappingURL=coaKind.d.ts.map