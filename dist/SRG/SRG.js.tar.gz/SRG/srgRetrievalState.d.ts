/**
 * Data Source Registry (SRG)
 * Description
 * Who publishes data upstream of a network and what can be retrieved from
 * them. A registry lists data providers (a satellite operator's ephemeris
 * site, a national archive, a public API), each with the origins it may be
 * fetched from, the format it publishes in, how often it refreshes and
 * whether it needs credentials. Discovery against a provider yields resource
 * descriptors: one retrievable file or endpoint each, with its URL, format
 * and, when known, what it covers. Storing a retrieved resource in a
 * content-addressed store yields a receipt naming its content identifier.
 * A retriever's progress through a provider's resources is reported as a
 * retrieval status, and the limits it runs under as retrieval settings.
 *
 * One record type serves every step, so each step can be passed alone: a
 * registry listing carries PROVIDERS; a discovery queue carries RESOURCES; a
 * single job (one resource to fetch, small enough to travel as the context of
 * one HTTP request) carries one RESOURCES entry; a storage receipt carries
 * RECEIPTS; a retriever reports STATUS and is configured with SETTINGS.
 *
 * Neighbouring standards: a provider configured as a running ingest source on
 * a node is an $ICN (ingest connector), which SRG nests rather than repeats.
 * SRG describes where data comes from; $DAV says whether a node holds the
 * latest published dataset of a lane, and $PNM announces a publication.
 * Neither fits a storage receipt: a $PNM is a signed network announcement and
 * a $DAV describes a whole lane, while a receipt only states that given bytes
 * were stored under a content identifier. A receipt's CID is what a later
 * $NCD (SOURCE_CID), $DPM asset or $PNM refers to. Coverage reuses the
 * $STF DataCoverage table.
 * What a retriever is doing or why it stopped. Append new values only; never
 * reorder or reuse existing values.
 */
export declare enum srgRetrievalState {
    /**
     * Not reported.
     */
    Unknown = 0,
    /**
     * Settings were accepted; retrieval has not run yet.
     */
    Configured = 1,
    /**
     * Retrieval is turned off.
     */
    Disabled = 2,
    /**
     * The provider needs credentials and none are available to the retriever.
     */
    CredentialUnavailable = 3,
    /**
     * All resources of the last discovery were retrieved; the next discovery
     * waits for the provider's refresh interval.
     */
    WaitingRefresh = 4,
    /**
     * Resources remain in the current discovery queue.
     */
    InProgress = 5,
    /**
     * Every resource of the current discovery queue (or page) was processed.
     */
    Complete = 6,
    /**
     * The retriever's storage budget is used up; nothing more is stored until
     * it is raised.
     */
    ArchiveBudgetReached = 7,
    /**
     * The provider answered with a page, not a data file, so nothing was
     * stored (NOTE says why).
     */
    ProviderPageOnly = 8,
    /**
     * Retrieval failed (NOTE says why).
     */
    Failed = 9
}
//# sourceMappingURL=srgRetrievalState.d.ts.map