/**
 * Conjunction Screening (SCR)
 * Description
 * The intermediate work products of screening a catalog for close
 * approaches, and the possibility-of-collision assessment of one encounter.
 * A screen over a time window is cut into coarse steps; a block names a run
 * of steps; a grid holds every object's position, velocity and deviation
 * bound at each step of a block (so pairs that cannot come within the
 * threshold are discarded cheaply, on a CPU or a GPU); roles say which
 * objects are primaries, secondaries or skipped; candidates are the
 * (pair, step) cells that survive the coarse filter and go on to precise
 * refinement; exclusions are objects whose propagation failed. Each frame
 * is self-describing so the stages can run in separate processes or nodes
 * and a partitioned screen can be merged.
 *
 * The refined conjunctions of a screen are $CQR events and $CDM messages
 * (time of closest approach, miss distance, relative state, covariances and
 * the collision probability with its method); $CSM is the one-line summary.
 * SCR does not repeat them. The possibility-of-collision result here is not
 * a probability: it is the possibility and necessity of collision under
 * possibilistic (fuzzy) uncertainty of the two orbits, with the miss
 * distance and closest-approach time ranges of each alpha-cut, so it has no
 * home in $CDM's COLLISION_PROBABILITY.
 *
 * One SCR carries one arm. Units: km and km/s for grid states; SI (m, m/s,
 * s) for the possibility assessment.
 * Role of an object in a screen. Append new values only; never reorder or
 * reuse existing values.
 */
export declare enum scrScreeningRole {
    /**
     * Screened only against primaries.
     */
    Secondary = 0,
    /**
     * Screened against every non-skipped object.
     */
    Primary = 1,
    /**
     * Left out of the screen.
     */
    Skip = 2
}
//# sourceMappingURL=scrScreeningRole.d.ts.map