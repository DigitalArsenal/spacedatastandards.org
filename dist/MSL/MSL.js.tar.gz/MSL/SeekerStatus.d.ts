export declare enum SeekerStatus {
    OFF = 0,
    CAGED = 1,
    UNCAGED = 2,
    ACQUIRING = 3,
    TRACKING = 4,
    MEMORY = 5,
    JAMMED = 6
}
//# sourceMappingURL=SeekerStatus.d.ts.map