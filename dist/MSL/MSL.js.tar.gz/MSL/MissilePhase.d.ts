export declare enum MissilePhase {
    CAPTIVE = 0,
    LAUNCH = 1,
    BOOST = 2,
    SUSTAIN = 3,
    COAST = 4,
    TERMINAL = 5,
    INTERCEPT = 6,
    MISS = 7,
    SELF_DESTRUCT = 8
}
//# sourceMappingURL=MissilePhase.d.ts.map