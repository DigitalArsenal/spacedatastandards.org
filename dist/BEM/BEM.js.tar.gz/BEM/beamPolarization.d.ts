export declare enum beamPolarization {
    RHCP = 0,
    LHCP = 1,
    LINEAR_H = 2,
    LINEAR_V = 3,
    DUAL_CIRCULAR = 4,
    DUAL_LINEAR = 5,
    CROSS_POL = 6
}
//# sourceMappingURL=beamPolarization.d.ts.map