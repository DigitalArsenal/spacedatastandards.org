export { BEM, BEMT } from './BEM.js';
//# sourceMappingURL=main.d.ts.map