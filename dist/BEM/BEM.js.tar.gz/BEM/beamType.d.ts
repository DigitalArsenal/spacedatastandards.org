export declare enum beamType {
    SPOT = 0,
    REGIONAL = 1,
    GLOBAL = 2,
    SHAPED = 3,
    STEERABLE = 4,
    HOPPING = 5
}
//# sourceMappingURL=beamType.d.ts.map