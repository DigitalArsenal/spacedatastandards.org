export declare enum PenResult {
    NO_PENETRATION = 0,
    PARTIAL_PEN = 1,
    FULL_PEN = 2,
    RICOCHET = 3,
    SHATTERED = 4,
    OVER_MATCH = 5
}
//# sourceMappingURL=PenResult.d.ts.map