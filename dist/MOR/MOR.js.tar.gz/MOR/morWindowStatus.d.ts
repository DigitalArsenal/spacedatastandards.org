/**
 * A window of WINDOWS: served (its coefficients follow) or one no record serves, with the ordinals of
 * $PPE ppeWindowStatus for the refusals. Append new values only.
 */
export declare enum morWindowStatus {
    /**
     * Served: the window's coefficients are in WINDOW_COEFF_HEADS and WINDOW_COEFF_TAILS.
     */
    SERVED = 0,
    /**
     * The theory refused the window; no coefficients.
     */
    THEORY_REFUSED = 1,
    /**
     * The builder could not hold its tolerance over the window; no coefficients.
     */
    TOLERANCE_NOT_HELD = 2
}
//# sourceMappingURL=morWindowStatus.d.ts.map