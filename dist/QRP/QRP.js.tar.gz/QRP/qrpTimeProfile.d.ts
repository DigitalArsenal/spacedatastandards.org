/**
 * How a request selects records in time when the lane holds several
 * versions of the same object. Append new values only; never reorder or
 * reuse existing values.
 */
export declare enum qrpTimeProfile {
    /**
     * Not stated: the serving node applies its configured default.
     */
    Unspecified = 0,
    /**
     * Every record in the epoch window.
     */
    All = 1,
    /**
     * For each object, the record whose epoch is nearest PROFILE_EPOCH_MS.
     */
    Nearest = 2,
    /**
     * For each object, the latest record at or before PROFILE_EPOCH_MS (the
     * state as it was known then).
     */
    AsOf = 3,
    /**
     * For each object, the earliest record at or after PROFILE_EPOCH_MS.
     */
    Forward = 4,
    /**
     * For each object, its latest record.
     */
    Latest = 5
}
//# sourceMappingURL=qrpTimeProfile.d.ts.map