/**
 * Orbit state element sets. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum frmStateRepresentation {
    UNSPECIFIED = 0,
    /**
     * Position and velocity components, 6 elements.
     */
    CARTESIAN = 1,
    /**
     * SMA, ECC, INC, RAAN, AOP, TA.
     */
    KEPLERIAN = 2,
    /**
     * RadPer, RadApo, INC, RAAN, AOP, TA.
     */
    MODIFIED_KEPLERIAN = 3,
    /**
     * RMAG, RA, DEC, VMAG, azimuth, flight-path angle.
     */
    SPHERICAL_AZFPA = 4,
    /**
     * RMAG, RA, DEC, VMAG, right ascension of velocity, declination of velocity.
     */
    SPHERICAL_RADEC = 5,
    /**
     * SMA, h, k, p, q, mean longitude.
     */
    EQUINOCTIAL = 6,
    /**
     * p, f, g, h, k, true longitude.
     */
    MODIFIED_EQUINOCTIAL = 7,
    /**
     * Equinoctial variant using mean motion in place of the semi-major axis.
     */
    ALTERNATE_EQUINOCTIAL = 8,
    /**
     * Delaunay canonical variables l, g, h, L, G, H.
     */
    DELAUNAY = 9,
    /**
     * Geodetic latitude/longitude/height with the horizon velocity triple.
     */
    PLANETODETIC = 10,
    /**
     * Incoming asymptote (B-plane) element set.
     */
    INCOMING_ASYMPTOTE = 11,
    /**
     * Outgoing asymptote (B-plane) element set.
     */
    OUTGOING_ASYMPTOTE = 12,
    /**
     * Brouwer-Lyddane mean elements, short-period terms only.
     */
    BROUWER_MEAN_SHORT = 13,
    /**
     * Brouwer-Lyddane mean elements, short and long period terms.
     */
    BROUWER_MEAN_LONG = 14
}
//# sourceMappingURL=frmStateRepresentation.d.ts.map