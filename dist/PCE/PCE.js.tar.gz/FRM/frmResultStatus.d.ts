/**
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum frmResultStatus {
    OK = 0,
    INVALID_INPUT = 1,
    UNSUPPORTED_OPERATION = 2,
    /**
     * The provider does not implement the requested axis set.
     */
    UNSUPPORTED_AXIS_TYPE = 3,
    /**
     * The provider does not implement the requested element set.
     */
    UNSUPPORTED_STATE_REPRESENTATION = 4,
    /**
     * The axis chain needs Earth-orientation data that was not supplied or
     * does not span EPOCH. The provider MUST fail here rather than silently
     * extrapolate.
     */
    MISSING_EOP_DATA = 5,
    /**
     * The state is at a singularity of the requested element set (for example
     * e -> 0 for Keplerian). The provider MUST report this rather than
     * substitute a different element set.
     */
    SINGULAR_ELEMENT_SET = 6
}
//# sourceMappingURL=frmResultStatus.d.ts.map