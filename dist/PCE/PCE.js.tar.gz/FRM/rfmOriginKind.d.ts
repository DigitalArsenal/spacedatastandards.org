/**
 * What kind of point a coordinate system is centred on. Append new values
 * only; never reorder or reuse existing values.
 */
export declare enum rfmOriginKind {
    UNSPECIFIED = 0,
    /**
     * The centre of mass of a single celestial body.
     */
    CELESTIAL_BODY = 1,
    /**
     * The barycentre of a named system of bodies.
     */
    BARYCENTRE = 2,
    /**
     * A libration (Lagrange) point of a two-body system.
     */
    LIBRATION_POINT = 3,
    /**
     * Another tracked space object, identified by OBJECT_ID.
     */
    SPACE_OBJECT = 4,
    /**
     * A fixed site on a body surface, identified by SITE_ID and the geodetic
     * fields on RFMOrigin.
     */
    GROUND_SITE = 5
}
//# sourceMappingURL=rfmOriginKind.d.ts.map