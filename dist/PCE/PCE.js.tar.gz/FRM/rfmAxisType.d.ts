/**
 * Axis-set capability classes for a fully specified coordinate system.
 * These name the ORIENTATION rule only; the ORIGIN is carried separately in
 * RFMOrigin, so any axis set below combines with any origin. Append new
 * values only; never reorder or reuse existing values.
 */
export declare enum rfmAxisType {
    UNSPECIFIED = 0,
    /**
     * Mean equator and mean equinox of the J2000.0 epoch.
     */
    MEAN_EQUATOR_EQUINOX_J2000 = 1,
    /**
     * Mean ecliptic and mean equinox of the J2000.0 epoch.
     */
    MEAN_ECLIPTIC_EQUINOX_J2000 = 2,
    /**
     * International Celestial Reference Frame axes.
     */
    ICRF = 3,
    /**
     * True equator, mean equinox of date.
     */
    TRUE_EQUATOR_MEAN_EQUINOX_OF_DATE = 4,
    /**
     * Mean equator of date (precession applied to the epoch of the state).
     */
    MEAN_OF_DATE_EQUATOR = 5,
    /**
     * Mean ecliptic of date.
     */
    MEAN_OF_DATE_ECLIPTIC = 6,
    /**
     * True equator of date (precession and nutation applied).
     */
    TRUE_OF_DATE_EQUATOR = 7,
    /**
     * True ecliptic of date.
     */
    TRUE_OF_DATE_ECLIPTIC = 8,
    /**
     * Mean equator of a fixed reference epoch.
     */
    MEAN_OF_EPOCH_EQUATOR = 9,
    /**
     * Mean ecliptic of a fixed reference epoch.
     */
    MEAN_OF_EPOCH_ECLIPTIC = 10,
    /**
     * True equator of a fixed reference epoch.
     */
    TRUE_OF_EPOCH_EQUATOR = 11,
    /**
     * True ecliptic of a fixed reference epoch.
     */
    TRUE_OF_EPOCH_ECLIPTIC = 12,
    /**
     * Axes rotating with the body named by AXIS_REFERENCE_BODY_NAIF_ID,
     * per its published rotation elements.
     */
    BODY_FIXED = 13,
    /**
     * Non-rotating axes aligned with the reference body's equator and prime
     * meridian at the reference epoch.
     */
    BODY_INERTIAL = 14,
    /**
     * Axes built from the relative geometry of two named objects; see
     * RFMObjectReferencedAxes.
     */
    OBJECT_REFERENCED = 15,
    /**
     * Axes built by aligning one vector and constraining a second; see
     * RFMLocalAlignedConstrainedAxes.
     */
    LOCAL_ALIGNED_CONSTRAINED = 16,
    /**
     * Axes in the reference body's equatorial plane at the requested epoch.
     */
    BODY_EQUATOR = 17,
    /**
     * Solar-ecliptic magnetospheric axes: X toward the Sun, Z along the
     * ecliptic north, commonly abbreviated GSE.
     */
    SOLAR_ECLIPTIC_MAGNETOSPHERIC = 18,
    /**
     * Solar-magnetospheric axes: X toward the Sun, Z in the plane containing
     * the body magnetic dipole, commonly abbreviated GSM.
     */
    SOLAR_MAGNETOSPHERIC = 19,
    /**
     * Local horizon axes at a surface site; the site is carried on RFMOrigin.
     */
    TOPOCENTRIC = 20,
    /**
     * Axes fixed by the body spin axis and the body-to-Sun direction.
     */
    BODY_SPIN_SUN = 21,
    /**
     * Axes defined by a loaded ephemeris/orientation kernel; identified by
     * KERNEL_FRAME_NAME / KERNEL_FRAME_ID on RFMCoordinateSystem.
     */
    EPHEMERIS_KERNEL_DEFINED = 22,
    /**
     * LEGACY, retained and NAMED rather than left implicit: mean equator of
     * date computed with the IAU-76/FK5 precession theory instead of the
     * IAU-2006/2000A chain. Results differ from MEAN_OF_DATE_EQUATOR at the
     * milliarcsecond level and the two are not interchangeable.
     */
    MEAN_OF_DATE_EQUATOR_FK5 = 23,
    /**
     * LEGACY, retained and NAMED: true equator of date computed with the
     * IAU-76/FK5 precession-nutation theory. See MEAN_OF_DATE_EQUATOR_FK5.
     */
    TRUE_OF_DATE_EQUATOR_FK5 = 24
}
//# sourceMappingURL=rfmAxisType.d.ts.map