/**
 * SI unit of a parameter value. The catalog is SI: metres, radians, seconds,
 * kilograms. A provider MUST NOT publish degrees or kilometres under these
 * members. PROVIDER_DEFINED holds a reserved high value so new SI units
 * append contiguously without disturbing it. Append new values only.
 */
export declare enum pceUnit {
    UNSPECIFIED = 0,
    /**
     * A pure number.
     */
    DIMENSIONLESS = 1,
    METRE = 2,
    METRE_PER_SECOND = 3,
    METRE_PER_SECOND_SQUARED = 4,
    METRE_SQUARED = 5,
    /**
     * Specific angular momentum.
     */
    METRE_SQUARED_PER_SECOND = 6,
    /**
     * Specific energy, including characteristic energy.
     */
    METRE_SQUARED_PER_SECOND_SQUARED = 7,
    METRE_CUBED = 8,
    RADIAN = 9,
    RADIAN_PER_SECOND = 10,
    SECOND = 11,
    /**
     * Day of 86400 SI seconds; the unit of a modified Julian day count.
     */
    DAY = 12,
    KILOGRAM = 13,
    KILOGRAM_PER_SECOND = 14,
    KILOGRAM_PER_METRE_CUBED = 15,
    /**
     * Moment of inertia.
     */
    KILOGRAM_METRE_SQUARED = 16,
    NEWTON = 17,
    NEWTON_METRE = 18,
    WATT = 19,
    PASCAL = 20,
    KELVIN = 21,
    /**
     * Area-to-mass ratio and ballistic coefficient reciprocal.
     */
    METRE_SQUARED_PER_KILOGRAM = 22,
    /**
     * The unit is outside this vocabulary and is named in
     * PCEParameterDescriptor.PROVIDER_DEFINED_UNIT_SYMBOL, which is then
     * REQUIRED. A consumer that cannot resolve the symbol MUST refuse the
     * value rather than assume DIMENSIONLESS.
     */
    PROVIDER_DEFINED = 100
}
//# sourceMappingURL=pceUnit.d.ts.map