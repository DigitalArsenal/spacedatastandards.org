/**
 * Outcome of one parameter evaluation or one propagate-to-condition run.
 * 0 is UNSPECIFIED so an unset byte never decodes as success. Append new
 * values only.
 */
export declare enum pceResultStatus {
    UNSPECIFIED = 0,
    OK = 1,
    INVALID_INPUT = 2,
    /**
     * The name does not resolve in the publisher's catalog.
     */
    UNKNOWN_PARAMETER = 3,
    /**
     * The name resolves and is DECLARED_UNAVAILABLE.
     */
    NOT_IMPLEMENTED = 4,
    /**
     * A coordinate system, central body, site or second object the parameter
     * requires was not supplied.
     */
    MISSING_DEPENDENCY = 5,
    /**
     * The owning object or hardware item named on the request is not present.
     */
    MISSING_OWNER_OBJECT = 6,
    /**
     * The evaluation needs Earth-orientation data that was not supplied or
     * does not span the epoch. The provider MUST fail here rather than
     * silently extrapolate.
     */
    MISSING_EOP_DATA = 7,
    /**
     * The parameter is undefined at this state: a node angle at zero
     * inclination, an argument of periapsis at zero eccentricity.
     */
    SINGULAR_AT_STATE = 8,
    /**
     * The parameter is defined only on a regime this state is not in: a launch
     * asymptote on a bound orbit.
     */
    OUT_OF_DOMAIN = 9,
    /**
     * A stopping condition was never attained inside the requested interval.
     */
    GOAL_NOT_ATTAINED = 10,
    /**
     * The bracketing succeeded but the root refinement did not converge to the
     * requested epoch tolerance.
     */
    ROOT_REFINEMENT_FAILED = 11,
    /**
     * The run hit its step or evaluation budget before answering.
     */
    BUDGET_EXCEEDED = 12
}
//# sourceMappingURL=pceResultStatus.d.ts.map