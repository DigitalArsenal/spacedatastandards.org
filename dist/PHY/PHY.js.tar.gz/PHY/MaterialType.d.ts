export declare enum MaterialType {
    STEEL = 0,
    ALUMINUM = 1,
    TITANIUM = 2,
    CERAMIC = 3,
    COMPOSITE = 4,
    CONCRETE = 5,
    WOOD = 6,
    RUBBER = 7,
    WATER = 8,
    AIR = 9,
    CUSTOM = 10
}
//# sourceMappingURL=MaterialType.d.ts.map