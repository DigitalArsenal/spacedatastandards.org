export declare enum Ellipsoid {
    WGS84 = 0,
    GRS80 = 1,
    WGS72 = 2,
    SPHERE = 3,
    MOON = 4,
    MARS = 5
}
//# sourceMappingURL=Ellipsoid.d.ts.map