/**
 * Operating state of a facility as its sources state it. Ordinals are wire
 * values: append only; never reorder or reuse.
 */
export declare enum txsOperationalStatus {
    UNSPECIFIED = 0,
    /**
     * Radiating on a regular or continuous basis.
     */
    OPERATIONAL = 1,
    /**
     * Radiating irregularly or only for part of the year.
     */
    INTERMITTENT = 2,
    /**
     * Licensed and standing, but not currently radiating.
     */
    SILENT = 3,
    /**
     * Authorization withdrawn or surrendered; structure may still stand.
     */
    DECOMMISSIONED = 4,
    /**
     * Structure removed.
     */
    DEMOLISHED = 5,
    /**
     * Authorized or announced, not yet radiating.
     */
    PLANNED = 6,
    /**
     * Sources agree the operation moved to a different facility.
     */
    RELOCATED = 7
}
//# sourceMappingURL=txsOperationalStatus.d.ts.map