/**
 * Modulation capability class of one emission. The ITU emission designator in
 * EMISSION_DESIGNATOR is authoritative whenever both are present; this enum
 * exists so a consumer can filter without parsing designators. Ordinals are
 * wire values: append only; never reorder or reuse.
 */
export declare enum txsModulationClass {
    UNSPECIFIED = 0,
    UNMODULATED_CARRIER = 1,
    ON_OFF_KEYED_CARRIER = 2,
    AMPLITUDE_DOUBLE_SIDEBAND = 3,
    AMPLITUDE_SINGLE_SIDEBAND_FULL_CARRIER = 4,
    AMPLITUDE_SINGLE_SIDEBAND_REDUCED_CARRIER = 5,
    AMPLITUDE_SINGLE_SIDEBAND_SUPPRESSED_CARRIER = 6,
    AMPLITUDE_VESTIGIAL_SIDEBAND = 7,
    AMPLITUDE_INDEPENDENT_SIDEBAND = 8,
    FREQUENCY_MODULATION = 9,
    PHASE_MODULATION = 10,
    FREQUENCY_SHIFT_KEYING = 11,
    PHASE_SHIFT_KEYING = 12,
    QUADRATURE_AMPLITUDE = 13,
    ORTHOGONAL_FREQUENCY_DIVISION_MULTIPLEX = 14,
    PULSED = 15,
    SPREAD_SPECTRUM = 16,
    OTHER = 17
}
//# sourceMappingURL=txsModulationClass.d.ts.map