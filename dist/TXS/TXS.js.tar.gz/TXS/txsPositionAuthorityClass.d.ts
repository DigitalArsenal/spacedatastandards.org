/**
 * The class of authority behind the published position of a facility.
 *
 * This is an EPISTEMIC statement, not a quality score: it says who asserted
 * the coordinate and in what capacity. Ordinals are wire values: append only;
 * never reorder or reuse.
 */
export declare enum txsPositionAuthorityClass {
    /**
     * The publisher does not state how the position was established. POSITION
     * AUTHORITY defaults here so an unset field can never be read as a
     * regulator's coordinate.
     */
    UNSPECIFIED = 0,
    /**
     * A spectrum regulator or licensing administration publishes the coordinate
     * in its own licence or assignment record.
     */
    REGULATOR_PUBLISHED = 1,
    /**
     * An international frequency coordination register or notification filing
     * carries the coordinate.
     */
    COORDINATION_FILING = 2,
    /**
     * The licensee or facility operator publishes the coordinate itself.
     */
    LICENSEE_PUBLISHED = 3,
    /**
     * The coordinate was surveyed or measured on site by a party independent of
     * the licensee.
     */
    SURVEYED_INDEPENDENT = 4,
    /**
     * The coordinate was read off imagery or a mapping product by the publisher
     * or a cited source.
     */
    DERIVED_FROM_IMAGERY = 5,
    /**
     * The coordinate is the result of radio direction finding, time- or
     * frequency-difference-of-arrival geolocation, or another observation-based
     * fix. The fused solution itself belongs in `$GEL`.
     */
    INFERRED_FROM_OBSERVATION = 6,
    /**
     * The coordinate is asserted by an observer community or an enthusiast
     * compilation with no regulator, licensee or survey behind it. It is
     * publishable and it is never interchangeable with a licence coordinate.
     */
    COMMUNITY_ASSERTED = 7,
    /**
     * A community assertion the sources themselves report as superseded — the
     * facility is believed to have moved, and the coordinate describes where it
     * formerly stood.
     */
    COMMUNITY_ASSERTED_HISTORICAL = 8,
    /**
     * The facility is documented to exist and no party publishes a position at
     * all. LATITUDE and LONGITUDE are ABSENT in this case; they are never
     * filled with a region centroid.
     */
    UNDISCLOSED = 9
}
//# sourceMappingURL=txsPositionAuthorityClass.d.ts.map