/**
 * Meteorological variable carried by the field. Append new values only;
 * never reorder or reuse existing values. Units are fixed per value and
 * repeated in UNITS.
 */
export declare enum wxfVariable {
    /**
     * VARIABLE_NAME carries the producer's own variable name.
     */
    Unspecified = 0,
    /**
     * Air temperature at 2 m above ground, kelvin.
     */
    Temperature2m = 1,
    /**
     * Dew-point temperature at 2 m above ground, kelvin.
     */
    DewpointTemperature2m = 2,
    /**
     * Eastward wind component at 10 m above ground, m/s.
     */
    WindU10m = 3,
    /**
     * Northward wind component at 10 m above ground, m/s.
     */
    WindV10m = 4,
    /**
     * Wind speed at 10 m above ground, m/s.
     */
    WindSpeed10m = 5,
    /**
     * Eastward wind component at 100 m above ground, m/s.
     */
    WindU100m = 6,
    /**
     * Northward wind component at 100 m above ground, m/s.
     */
    WindV100m = 7,
    /**
     * Wind speed at 100 m above ground, m/s.
     */
    WindSpeed100m = 8,
    /**
     * Mean sea-level pressure, pascal.
     */
    MeanSeaLevelPressure = 9,
    /**
     * Sea-surface temperature, kelvin.
     */
    SeaSurfaceTemperature = 10,
    /**
     * Total cloud cover fraction, [0, 1].
     */
    TotalCloudCover = 11,
    /**
     * High-cloud cover fraction, [0, 1].
     */
    HighCloudCover = 12,
    /**
     * Medium-cloud cover fraction, [0, 1].
     */
    MediumCloudCover = 13,
    /**
     * Low-cloud cover fraction, [0, 1].
     */
    LowCloudCover = 14,
    /**
     * Surface downward shortwave radiation accumulated over
     * ACCUMULATION_HOURS, J/m^2.
     */
    SurfaceSolarRadiationDownwards = 15,
    /**
     * Total-sky direct shortwave radiation at the surface accumulated over
     * ACCUMULATION_HOURS, J/m^2.
     */
    TotalSkyDirectSolarRadiationAtSurface = 16,
    /**
     * Total precipitation accumulated over ACCUMULATION_HOURS, metres of
     * water equivalent.
     */
    TotalPrecipitation = 17,
    /**
     * Total precipitation trained against a satellite-blended precipitation
     * analysis, accumulated over ACCUMULATION_HOURS, metres of water
     * equivalent.
     */
    TotalPrecipitationSatelliteBlended = 18,
    /**
     * Experimental total precipitation product, accumulated over
     * ACCUMULATION_HOURS, metres of water equivalent.
     */
    TotalPrecipitationExperimental = 19,
    /**
     * Geopotential on a pressure level, m^2/s^2.
     */
    Geopotential = 20,
    /**
     * Air temperature on a pressure level, kelvin.
     */
    Temperature = 21,
    /**
     * Specific humidity on a pressure level, kg/kg.
     */
    SpecificHumidity = 22,
    /**
     * Eastward wind component on a pressure level, m/s.
     */
    WindU = 23,
    /**
     * Northward wind component on a pressure level, m/s.
     */
    WindV = 24,
    /**
     * Vertical velocity on a pressure level, Pa/s.
     */
    VerticalVelocity = 25,
    /**
     * Precipitation rate, kg/(m^2 s).
     */
    PrecipitationRate = 26,
    /**
     * Relative humidity, [0, 1].
     */
    RelativeHumidity = 27,
    /**
     * Total column water vapour, kg/m^2.
     */
    TotalColumnWaterVapour = 28,
    /**
     * Surface pressure, pascal.
     */
    SurfacePressure = 29,
    /**
     * Geopotential height, geopotential metres (gpm): the height a producer
     * such as GFS publishes on pressure levels and at the tropopause. Distinct
     * from Geopotential (m^2/s^2); a consumer never relabels one as the other.
     */
    GeopotentialHeight = 30,
    /**
     * Brightness temperature a radiometer channel measured, kelvin: the
     * temperature of a black body emitting the observed radiance at
     * CHANNEL_WAVELENGTH_UM. At LEVEL_KIND TopOfAtmosphere.
     */
    BrightnessTemperature = 31,
    /**
     * Top-of-atmosphere bidirectional reflectance factor of a solar channel
     * at CHANNEL_WAVELENGTH_UM, dimensionless (1 = a white Lambertian
     * surface under the same illumination), not corrected for the solar
     * zenith angle unless VARIABLE_NAME says so. Missing at night.
     */
    Reflectance = 32,
    /**
     * Categorical cloud mask of a satellite retrieval: 0 clear, 1 probably
     * clear, 2 probably cloudy, 3 cloudy. Units "1". A cell resampled from
     * several source pixels carries their mean, so fractional values are
     * the average category, not a new class.
     */
    CloudMask = 33,
    /**
     * Categorical thermodynamic phase at the cloud top: 0 clear, 1 liquid
     * water, 2 supercooled liquid water, 3 mixed, 4 ice, 5 unknown. Units
     * "1". Resampled cells carry the category of the source pixel nearest the
     * cell centre.
     */
    CloudPhase = 34,
    /**
     * Cloud optical depth at CHANNEL_WAVELENGTH_UM, dimensionless.
     */
    CloudOpticalDepth = 35,
    /**
     * Cloud-top effective particle radius, micrometres (units "um").
     */
    CloudEffectiveRadius = 36,
    /**
     * Cloud-top emissivity at CHANNEL_WAVELENGTH_UM, [0, 1].
     */
    CloudEmissivity = 37
}
//# sourceMappingURL=wxfVariable.d.ts.map