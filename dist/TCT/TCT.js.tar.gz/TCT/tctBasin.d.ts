/**
 * Tropical Cyclone Track (TCT)
 * Description
 * One track of one tropical cyclone as produced by a single realisation of
 * a forecast model (a member, control, deterministic run or ensemble
 * statistic) from one initialisation, or as observed (best track / analysis).
 * Each point carries valid time, centre position, maximum sustained wind,
 * minimum central pressure, wind radii by quadrant at the standard
 * thresholds and the intensity category. An ensemble of N members yields N
 * TCT records sharing STORM_ID and INIT_TIME_MS; a consumer draws the spread
 * from them. Every epoch is Unix milliseconds UTC. A forecast track is a
 * model output, never an official advisory.
 * Ocean basin the system is tracked in, following the common best-track
 * basin partition. Append new values only; never reorder or reuse existing
 * values.
 */
export declare enum tctBasin {
    Unspecified = 0,
    NorthAtlantic = 1,
    EastPacific = 2,
    CentralPacific = 3,
    WestPacific = 4,
    NorthIndian = 5,
    SouthIndian = 6,
    SouthPacific = 7,
    SouthAtlantic = 8,
    /**
     * A basin not covered above.
     */
    Other = 9
}
//# sourceMappingURL=tctBasin.d.ts.map