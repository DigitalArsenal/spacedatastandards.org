export declare enum TerrainInterpolation {
    NEAREST = 0,
    BILINEAR = 1,
    BICUBIC = 2,
    KRIGING = 3
}
//# sourceMappingURL=TerrainInterpolation.d.ts.map