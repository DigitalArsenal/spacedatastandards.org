export declare enum TerrainDataSource {
    SRTM = 0,
    ASTER = 1,
    DTED_0 = 2,
    DTED_1 = 3,
    DTED_2 = 4,
    NED = 5,
    LIDAR = 6,
    CUSTOM = 7
}
//# sourceMappingURL=TerrainDataSource.d.ts.map