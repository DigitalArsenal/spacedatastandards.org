export { EntryFunction, EntryFunctionT } from './EntryFunction.js';
export { PLG, PLGT } from './PLG.js';
export { PluginCapability, PluginCapabilityT } from './PluginCapability.js';
export { PluginDependency, PluginDependencyT } from './PluginDependency.js';
export { pluginType } from './pluginType.js';
//# sourceMappingURL=main.d.ts.map