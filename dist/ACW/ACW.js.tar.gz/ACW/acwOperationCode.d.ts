export declare enum acwOperationCode {
    UNKNOWN = 0,
    /**
     * Compute access windows from pre-sampled target Cartesian states.
     */
    COMPUTE_ACCESS_WINDOWS = 1,
    /**
     * Simulate sensor observations of TARGETS by SENSORS: schedule tracks
     * inside the ACCESS windows (computed per sensor and target by
     * COMPUTE_ACCESS_WINDOWS with that sensor's constraints), generate each
     * measurement from the
     * truth states with its MEMErrorModel noise and bias, apply the detection
     * test, and add false alarms. The observations are emitted as separate
     * $RDO (RADAR), $EOO (OPTICAL, LASER_RANGING) and $RFO (PASSIVE_RF)
     * records; the result lists the tracks.
     */
    SIMULATE_OBSERVATIONS = 2
}
//# sourceMappingURL=acwOperationCode.d.ts.map