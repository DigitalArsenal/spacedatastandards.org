import * as flatbuffers from 'flatbuffers';
import { ACWAccessWindow, ACWAccessWindowT } from './ACWAccessWindow.js';
import { ACWTrack, ACWTrackT } from './ACWTrack.js';
import { acwEvaluationMode } from './acwEvaluationMode.js';
import { acwResultStatus } from './acwResultStatus.js';
/**
 * Result for one access-window compute request.
 */
export declare class ACWResult implements flatbuffers.IUnpackableObject<ACWResultT> {
    bb: flatbuffers.ByteBuffer | null;
    bb_pos: number;
    __init(i: number, bb: flatbuffers.ByteBuffer): ACWResult;
    static getRootAsACWResult(bb: flatbuffers.ByteBuffer, obj?: ACWResult): ACWResult;
    static getSizePrefixedRootAsACWResult(bb: flatbuffers.ByteBuffer, obj?: ACWResult): ACWResult;
    STATUS(): acwResultStatus;
    ERROR_MESSAGE(): string | null;
    ERROR_MESSAGE(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    WINDOWS(index: number, obj?: ACWAccessWindow): ACWAccessWindow | null;
    windowsLength(): number;
    /**
     * Caller trace/correlation identifier copied from the request when present.
     */
    TRACE_ID(): string | null;
    TRACE_ID(optionalEncoding: flatbuffers.Encoding): string | Uint8Array | null;
    /**
     * Evaluation mode actually used.
     */
    EVALUATION_MODE(): acwEvaluationMode;
    /**
     * Flattened depth-first constraint list the window indices refer to.
     */
    CONSTRAINT_LABELS(index: number): string;
    CONSTRAINT_LABELS(index: number, optionalEncoding: flatbuffers.Encoding): string | Uint8Array;
    constraintLabelsLength(): number;
    /**
     * Tracks scheduled by SIMULATE_OBSERVATIONS.
     */
    TRACKS(index: number, obj?: ACWTrack): ACWTrack | null;
    tracksLength(): number;
    /**
     * Observations emitted, including false alarms.
     */
    OBSERVATION_COUNT(): number;
    static startACWResult(builder: flatbuffers.Builder): void;
    static addStatus(builder: flatbuffers.Builder, STATUS: acwResultStatus): void;
    static addErrorMessage(builder: flatbuffers.Builder, ERROR_MESSAGEOffset: flatbuffers.Offset): void;
    static addWindows(builder: flatbuffers.Builder, WINDOWSOffset: flatbuffers.Offset): void;
    static createWindowsVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startWindowsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addTraceId(builder: flatbuffers.Builder, TRACE_IDOffset: flatbuffers.Offset): void;
    static addEvaluationMode(builder: flatbuffers.Builder, EVALUATION_MODE: acwEvaluationMode): void;
    static addConstraintLabels(builder: flatbuffers.Builder, CONSTRAINT_LABELSOffset: flatbuffers.Offset): void;
    static createConstraintLabelsVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startConstraintLabelsVector(builder: flatbuffers.Builder, numElems: number): void;
    static addTracks(builder: flatbuffers.Builder, TRACKSOffset: flatbuffers.Offset): void;
    static createTracksVector(builder: flatbuffers.Builder, data: flatbuffers.Offset[]): flatbuffers.Offset;
    static startTracksVector(builder: flatbuffers.Builder, numElems: number): void;
    static addObservationCount(builder: flatbuffers.Builder, OBSERVATION_COUNT: number): void;
    static endACWResult(builder: flatbuffers.Builder): flatbuffers.Offset;
    static createACWResult(builder: flatbuffers.Builder, STATUS: acwResultStatus, ERROR_MESSAGEOffset: flatbuffers.Offset, WINDOWSOffset: flatbuffers.Offset, TRACE_IDOffset: flatbuffers.Offset, EVALUATION_MODE: acwEvaluationMode, CONSTRAINT_LABELSOffset: flatbuffers.Offset, TRACKSOffset: flatbuffers.Offset, OBSERVATION_COUNT: number): flatbuffers.Offset;
    unpack(): ACWResultT;
    unpackTo(_o: ACWResultT): void;
}
export declare class ACWResultT implements flatbuffers.IGeneratedObject {
    STATUS: acwResultStatus;
    ERROR_MESSAGE: string | Uint8Array | null;
    WINDOWS: (ACWAccessWindowT)[];
    TRACE_ID: string | Uint8Array | null;
    EVALUATION_MODE: acwEvaluationMode;
    CONSTRAINT_LABELS: (string)[];
    TRACKS: (ACWTrackT)[];
    OBSERVATION_COUNT: number;
    constructor(STATUS?: acwResultStatus, ERROR_MESSAGE?: string | Uint8Array | null, WINDOWS?: (ACWAccessWindowT)[], TRACE_ID?: string | Uint8Array | null, EVALUATION_MODE?: acwEvaluationMode, CONSTRAINT_LABELS?: (string)[], TRACKS?: (ACWTrackT)[], OBSERVATION_COUNT?: number);
    pack(builder: flatbuffers.Builder): flatbuffers.Offset;
}
//# sourceMappingURL=ACWResult.d.ts.map