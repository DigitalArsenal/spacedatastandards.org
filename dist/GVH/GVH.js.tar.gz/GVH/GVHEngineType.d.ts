export declare enum GVHEngineType {
    DIESEL = 0,
    GASOLINE = 1,
    GAS_TURBINE = 2,
    MULTIFUEL = 3,
    HYBRID = 4,
    ELECTRIC = 5
}
//# sourceMappingURL=GVHEngineType.d.ts.map