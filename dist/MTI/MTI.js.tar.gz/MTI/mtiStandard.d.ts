export declare enum mtiStandard {
    STANAG_4607 = 0,
    STANAG_4545 = 1,
    CUSTOM = 2,
    UNKNOWN = 3
}
//# sourceMappingURL=mtiStandard.d.ts.map