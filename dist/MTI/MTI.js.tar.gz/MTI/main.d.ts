export { MTI, MTIT } from './MTI.js';
//# sourceMappingURL=main.d.ts.map