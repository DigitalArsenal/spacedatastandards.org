export { SWR, SWRT } from './SWR.js';
//# sourceMappingURL=main.d.ts.map