/**
 * Origin of trajectory samples.
 */
export declare enum lamTrajectorySource {
    UNSPECIFIED = 0,
    /**
     * Projected from a target orbit and a reference ascent profile.
     */
    PROJECTED = 1,
    /**
     * Reconstructed from vehicle telemetry.
     */
    TELEMETRY = 2,
    /**
     * Reconstructed from tracking observations or catalog element sets.
     */
    TRACKING = 3,
    /**
     * Produced by a physics simulation of the vehicle.
     */
    SIMULATED = 4
}
//# sourceMappingURL=lamTrajectorySource.d.ts.map