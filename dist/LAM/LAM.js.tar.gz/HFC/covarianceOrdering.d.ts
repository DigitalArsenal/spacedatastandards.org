/**
 * Order in which the values of an N x N covariance matrix are written at each epoch (CCSDS 502.0-B-3 COV_ORDERING).
 */
export declare enum covarianceOrdering {
    /**
     * Lower triangle row by row, [1,1], [2,1], [2,2], [3,1] ...: N(N+1)/2 values.
     */
    LTM = 0,
    /**
     * Upper triangle row by row, [1,1], [1,2], [1,3], [2,2] ...: N(N+1)/2 values.
     */
    UTM = 1,
    /**
     * The whole matrix row by row: N*N values.
     */
    FULL = 2,
    /**
     * The whole matrix row by row: N*N values. The lower triangle with its diagonal holds the covariances; the places
     * above the diagonal hold the correlation coefficients (covariance over the product of standard deviations).
     */
    LTMWCC = 3,
    /**
     * The whole matrix row by row: N*N values. The upper triangle with its diagonal holds the covariances; the places
     * below the diagonal hold the correlation coefficients.
     */
    UTMWCC = 4
}
//# sourceMappingURL=covarianceOrdering.d.ts.map