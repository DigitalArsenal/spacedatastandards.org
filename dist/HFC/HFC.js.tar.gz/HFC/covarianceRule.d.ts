/**
 * The rule that produced a covariance. Wire values are append-only, not a
 * preference order: a producer states the estimator it actually used.
 */
export declare enum covarianceRule {
    /**
     * Not stated
     */
    Unspecified = 0,
    /**
     * The operator's covariance, as supplied
     */
    Operator = 1,
    /**
     * The formal covariance of an orbit fit, multiplied by the realism factor
     * measured for the source and the fit's class (SCALE_FACTOR)
     */
    ScaledFit = 2,
    /**
     * The source's own empirical model of its element sets' errors, by orbit
     * regime and element-set age
     */
    SourceModel = 3,
    /**
     * The empirical model pooled over all sources, for a source without its own
     * model in the regime
     */
    PooledModel = 4,
    /**
     * Empirical errors from this object's own element-set history, shrunk
     * toward a population prior identified by MODEL_ID and REGIME. Later
     * element sets are comparison states, not independent truth; history alone
     * never establishes calibration. HISTORY_* and SHRINKAGE_WEIGHT carry
     * fitting evidence; SAMPLES/OBJECTS/SCALE_FACTOR retain their meanings.
     */
    EmpiricalHistoryShrunk = 5
}
//# sourceMappingURL=covarianceRule.d.ts.map