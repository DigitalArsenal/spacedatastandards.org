export { SCHEMA_MANIFEST, SCHEMA_MANIFESTT } from './SCHEMA_MANIFEST.js';
export { SCHEMA_STANDARD, SCHEMA_STANDARDT } from './SCHEMA_STANDARD.js';
//# sourceMappingURL=main.d.ts.map