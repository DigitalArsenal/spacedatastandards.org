export declare enum SensorMode {
    OFF = 0,
    STANDBY = 1,
    SEARCH = 2,
    ACQUISITION = 3,
    TRACK = 4,
    TRACK_WHILE_SCAN = 5,
    DESIGNATE = 6,
    JAMMED = 7
}
//# sourceMappingURL=SensorMode.d.ts.map