/**
 * The frame MOUNTING angles are expressed in.
 */
export declare enum snrMountingFrame {
    UNSPECIFIED = 0,
    /**
     * Fixed to the platform body; the angles are body-axis angles.
     */
    PLATFORM_BODY = 1,
    /**
     * Local vertical, local horizontal at the platform: radial, along-track,
     * cross-track.
     */
    LVLH = 2,
    /**
     * Local east-north-up at a ground site. Azimuth clockwise from north,
     * elevation above the local horizontal.
     */
    LOCAL_ENU = 3
}
//# sourceMappingURL=snrMountingFrame.d.ts.map