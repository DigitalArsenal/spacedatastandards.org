export declare enum TrackQuality {
    NONE = 0,
    TENTATIVE = 1,
    FIRM = 2,
    LOCKED = 3,
    COASTING = 4,
    LOST = 5
}
//# sourceMappingURL=TrackQuality.d.ts.map