export { AntennaPattern } from './AntennaPattern.js';
export { BandType } from './BandType.js';
export { COM, COMT } from './COM.js';
export { ComModulationType } from './ComModulationType.js';
export { DataLinkType } from './DataLinkType.js';
export { PropagationModel } from './PropagationModel.js';
//# sourceMappingURL=main.d.ts.map