export { AntennaPattern } from './AntennaPattern.js';
export { BandType } from './BandType.js';
export { COM, COMT } from './COM.js';
export { DataLinkType } from './DataLinkType.js';
export { ModulationType } from './ModulationType.js';
export { PropagationModel } from './PropagationModel.js';
//# sourceMappingURL=main.d.ts.map