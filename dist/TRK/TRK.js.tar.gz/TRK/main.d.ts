export { TRK, TRKT } from './TRK.js';
//# sourceMappingURL=main.d.ts.map