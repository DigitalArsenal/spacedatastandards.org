export declare enum TrkTrackStatus {
    ACTIVE = 0,
    DROPPED = 1,
    TENTATIVE = 2,
    CONFIRMED = 3,
    COASTED = 4,
    DEAD = 5
}
//# sourceMappingURL=TrkTrackStatus.d.ts.map