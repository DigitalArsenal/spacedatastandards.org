export declare enum trackStatus {
    ACTIVE = 0,
    DROPPED = 1,
    TENTATIVE = 2,
    CONFIRMED = 3,
    COASTED = 4,
    DEAD = 5
}
//# sourceMappingURL=trackStatus.d.ts.map