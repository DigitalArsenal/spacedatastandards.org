export declare enum trackEnvironment {
    SPACE = 0,
    AIR = 1,
    SURFACE = 2,
    SUBSURFACE = 3,
    LAND = 4,
    UNKNOWN = 5
}
//# sourceMappingURL=trackEnvironment.d.ts.map