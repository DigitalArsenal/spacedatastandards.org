/**
 * Node Data Statistics (NDS)
 * Description
 * Snapshot of one node's data plane for operator dashboards: the record
 * footprint of every standard held, the ingest progress of every
 * (standard, provider, source, batch) lane together with the producer and the
 * upstream origin of that lane, ingest transitions, topic activity, module
 * runtime counters and trust-engine counters. A node assembles the snapshot
 * on a background lane and serves it from memory so a dashboard read never
 * waits on the store. A STALE snapshot is reported as stale with the AS_OF
 * time of its last true numbers, never as a confident zero.
 *
 * Provenance of a lane is structural, never a display string: PRODUCER_PEER_ID
 * is the peer whose signed identity record covers the lane's publications,
 * ORIGIN_ID names the upstream publisher the producer retrieved the records
 * from, and PUBLISHER_RUNG states how far that producer claim has been
 * verified by the reporting node.
 * How far the reporting node has verified the producer of a lane. Append new
 * values only; never reorder or reuse existing values.
 */
export declare enum ndsPublisherRung {
    /**
     * Only a source tag string is known; nothing has been verified.
     */
    SourceTag = 0,
    /**
     * The producer's signed identity record verifies in this node's directory.
     */
    Signed = 1,
    /**
     * The producer additionally carries a verified domain proof.
     */
    Bonded = 2
}
//# sourceMappingURL=ndsPublisherRung.d.ts.map