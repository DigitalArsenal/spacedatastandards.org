export { OSM, OSMT } from './OSM.js';
//# sourceMappingURL=main.d.ts.map