export declare enum emitterType {
    RADAR = 0,
    COMMUNICATIONS = 1,
    NAVIGATION = 2,
    JAMMER = 3,
    BEACON = 4,
    TRANSPONDER = 5,
    DATA_LINK = 6,
    TELEMETRY = 7,
    EW = 8,
    UNKNOWN = 9
}
//# sourceMappingURL=emitterType.d.ts.map