/**
 * Ingest Connector.
 *
 * An ICN describes one configured source of records entering an ingest flow.
 * Connector lifecycle STATUS is independent of any `$STF` listing status;
 * changing one never implies a change to the other.
 * Transport or source shape used by an ingest connector. Append new values
 * only; never reorder or reuse existing values.
 */
export declare enum icnConnectorKind {
    /**
     * Files are supplied through a bounded upload session.
     */
    UploadSession = 0,
    /**
     * Records are pulled from an HTTPS endpoint.
     */
    HttpsPull = 1,
    /**
     * A directory is scanned for settled files.
     */
    FilesystemWatch = 2
}
//# sourceMappingURL=icnConnectorKind.d.ts.map