export declare enum busSize {
    FEMTO = 0,
    PICO = 1,
    NANO = 2,
    MICRO = 3,
    MINI = 4,
    SMALL = 5,
    MEDIUM = 6,
    LARGE = 7,
    HEAVY = 8
}
//# sourceMappingURL=busSize.d.ts.map