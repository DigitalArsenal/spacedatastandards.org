export declare enum stabilizationType {
    THREE_AXIS = 0,
    SPIN = 1,
    GRAVITY_GRADIENT = 2,
    MAGNETIC = 3,
    DUAL_SPIN = 4,
    NONE = 5
}
//# sourceMappingURL=stabilizationType.d.ts.map