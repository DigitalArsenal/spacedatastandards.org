export { OBD, OBDT } from './OBD.js';
export { odMethod } from './odMethod.js';
export { odSensorContribution, odSensorContributionT } from './odSensorContribution.js';
//# sourceMappingURL=main.d.ts.map