export { OBD, OBDT } from './OBD.js';
//# sourceMappingURL=main.d.ts.map