export declare enum KMLListItemType {
    CHECK = 0,
    CHECK_OFF_ONLY = 1,
    CHECK_HIDE_CHILDREN = 2,
    RADIO_FOLDER = 3
}
//# sourceMappingURL=KMLListItemType.d.ts.map