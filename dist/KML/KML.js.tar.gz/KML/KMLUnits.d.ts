export declare enum KMLUnits {
    PIXELS = 0,
    FRACTION = 1,
    INSET_PIXELS = 2
}
//# sourceMappingURL=KMLUnits.d.ts.map