export declare enum KMLShape {
    RECTANGLE = 0,
    CYLINDER = 1,
    SPHERE = 2
}
//# sourceMappingURL=KMLShape.d.ts.map