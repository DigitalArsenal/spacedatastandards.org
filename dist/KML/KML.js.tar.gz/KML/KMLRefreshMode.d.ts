export declare enum KMLRefreshMode {
    ON_CHANGE = 0,
    ON_INTERVAL = 1,
    ON_EXPIRE = 2
}
//# sourceMappingURL=KMLRefreshMode.d.ts.map