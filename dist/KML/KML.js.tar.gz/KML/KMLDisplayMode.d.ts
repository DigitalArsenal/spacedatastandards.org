export declare enum KMLDisplayMode {
    DEFAULT = 0,
    HIDE = 1
}
//# sourceMappingURL=KMLDisplayMode.d.ts.map