export declare enum KMLFlyToMode {
    BOUNCE = 0,
    SMOOTH = 1
}
//# sourceMappingURL=KMLFlyToMode.d.ts.map