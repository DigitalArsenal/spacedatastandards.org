export declare enum KMLGridOrigin {
    LOWER_LEFT = 0,
    UPPER_LEFT = 1
}
//# sourceMappingURL=KMLGridOrigin.d.ts.map