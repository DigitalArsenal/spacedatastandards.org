/**
 * Node Health Status (NHS)
 * Description
 * One snapshot of the health of a running node: a data-network peer, a
 * ground-station computer, a flight computer or any service host. It reports
 * how long the service has been running and in what state, how much storage
 * it holds and has left, how busy its network interfaces are, and (when the
 * host measures them) its processor and memory load, with a recent history of
 * network throughput for trend displays.
 *
 * NHS is the node's view of itself. The peers a node knows about are $NST;
 * the records and ingest lanes a node holds are $NDS. A value the node did
 * not measure is reported as not measured (HAS_* false, or 0 where the field
 * says so), never as a confident zero.
 * Service lifecycle state. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum nhsServiceState {
    /**
     * Not reported.
     */
    Unknown = 0,
    /**
     * Starting up; not yet serving.
     */
    Starting = 1,
    /**
     * Serving normally.
     */
    Running = 2,
    /**
     * Serving with reduced capability (a dependency is down, storage is
     * nearly full, a backlog is building).
     */
    Degraded = 3,
    /**
     * Finishing work and refusing new work before stopping.
     */
    Draining = 4,
    /**
     * Not serving.
     */
    Stopped = 5,
    /**
     * Failed; operator action is required.
     */
    Failed = 6
}
//# sourceMappingURL=nhsServiceState.d.ts.map