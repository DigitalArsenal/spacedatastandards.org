export { OOD, OODT } from './OOD.js';
//# sourceMappingURL=main.d.ts.map