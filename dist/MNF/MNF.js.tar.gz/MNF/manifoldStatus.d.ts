export declare enum manifoldStatus {
    CANDIDATE = 0,
    CONFIRMED = 1,
    REJECTED = 2,
    CORRELATED = 3,
    EXPIRED = 4
}
//# sourceMappingURL=manifoldStatus.d.ts.map