export { PNM, PNMT } from './PNM.js';
//# sourceMappingURL=main.d.ts.map