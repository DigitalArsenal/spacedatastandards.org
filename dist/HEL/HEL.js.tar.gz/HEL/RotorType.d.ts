export declare enum RotorType {
    MAIN = 0,
    TAIL = 1,
    TANDEM_FRONT = 2,
    TANDEM_REAR = 3,
    COAXIAL_UPPER = 4,
    COAXIAL_LOWER = 5
}
//# sourceMappingURL=RotorType.d.ts.map