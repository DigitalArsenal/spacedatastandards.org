export declare enum RotorFlags {
    NORMAL = 0,
    VRS_WARNING = 1,
    VRS_ACTIVE = 2,
    RBS_WARNING = 3,
    RBS_ACTIVE = 4,
    OVERSPEED = 5,
    UNDERSPEED = 6
}
//# sourceMappingURL=RotorFlags.d.ts.map