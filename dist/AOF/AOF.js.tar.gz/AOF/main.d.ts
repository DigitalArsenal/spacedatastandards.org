export { AOF, AOFT } from './AOF.js';
//# sourceMappingURL=main.d.ts.map