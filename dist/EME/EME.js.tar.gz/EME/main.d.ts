export { EME, EMET } from './EME.js';
export { EMECOLLECTION, EMECOLLECTIONT } from './EMECOLLECTION.js';
//# sourceMappingURL=main.d.ts.map