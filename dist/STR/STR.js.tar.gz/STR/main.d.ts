export { STR, STRT } from './STR.js';
//# sourceMappingURL=main.d.ts.map