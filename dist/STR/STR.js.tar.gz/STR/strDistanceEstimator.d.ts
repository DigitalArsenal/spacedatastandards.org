/**
 * How a star's distance was estimated.
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum strDistanceEstimator {
    /**
     * No distance; DISTANCE_PC, DISTANCE_LO_PC and DISTANCE_HI_PC are NaN.
     */
    UNSPECIFIED = 0,
    /**
     * Geometric distance: the median of the posterior from the parallax under a
     * direction-dependent prior (Bailer-Jones et al. 2021, AJ 161, 147).
     */
    BAILER_JONES_2021_GEO = 1,
    /**
     * Photogeometric distance: the geometric posterior further constrained by the
     * star's color and magnitude (Bailer-Jones et al. 2021, AJ 161, 147).
     */
    BAILER_JONES_2021_PHOTOGEO = 2,
    /**
     * Mode of the posterior from the parallax under the exponentially decreasing
     * space density prior with its length scale (Bailer-Jones 2015, PASP 127, 994).
     */
    EDSD_POSTERIOR = 3,
    /**
     * Inverse parallax, DISTANCE_PC = 1000 / PARALLAX; meaningful only when the
     * fractional parallax uncertainty is small.
     */
    PARALLAX_INVERSE = 4
}
//# sourceMappingURL=strDistanceEstimator.d.ts.map