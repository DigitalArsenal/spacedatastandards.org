/**
 * Measurement classes supported by a tracking error model. Values are
 * capability classes; append new members only and never reuse a value.
 */
export declare enum memMeasurementType {
    UNSPECIFIED = 0,
    RANGE = 1,
    RANGE_RATE = 2,
    DOPPLER = 3,
    AZIMUTH_ELEVATION = 4,
    X_EAST_Y_NORTH = 5,
    X_SOUTH_Y_EAST = 6,
    RIGHT_ASCENSION_DECLINATION = 7,
    POSITION_VECTOR = 8,
    SEQUENTIAL_RANGE = 9,
    PSEUDONOISE_RANGE = 10,
    TIME_CORRELATED_PHASE = 11,
    RELAY_RANGE = 12,
    RELAY_DOPPLER = 13,
    RELAY_DIFFERENCED_DOPPLER = 14,
    BISTATIC_RANGE = 15,
    SKIN_RANGE = 16,
    CROSSLINK_RANGE = 17,
    CROSSLINK_RANGE_RATE = 18,
    LASER_RANGE = 19,
    TIME_DIFFERENCE_OF_ARRIVAL = 20,
    FREQUENCY_DIFFERENCE_OF_ARRIVAL = 21
}
//# sourceMappingURL=memMeasurementType.d.ts.map