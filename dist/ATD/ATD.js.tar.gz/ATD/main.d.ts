export { ATD, ATDT } from './ATD.js';
export { attMotionType } from './attMotionType.js';
export { attRepresentation } from './attRepresentation.js';
//# sourceMappingURL=main.d.ts.map