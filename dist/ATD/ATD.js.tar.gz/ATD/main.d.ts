export { ATD, ATDT } from './ATD.js';
//# sourceMappingURL=main.d.ts.map