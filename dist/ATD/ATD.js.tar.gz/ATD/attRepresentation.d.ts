export declare enum attRepresentation {
    QUATERNION = 0,
    EULER = 1,
    SPIN = 2,
    DIRECTION_COSINE = 3
}
//# sourceMappingURL=attRepresentation.d.ts.map