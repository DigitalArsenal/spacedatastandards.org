export declare enum attMotionType {
    STABILIZED = 0,
    SPINNING = 1,
    TUMBLING = 2,
    PRECESSING = 3,
    UNKNOWN = 4
}
//# sourceMappingURL=attMotionType.d.ts.map