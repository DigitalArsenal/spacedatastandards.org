export declare enum attitudeStateType {
    QUATERNION = 0,
    EULER_ANGLES = 1,
    SPIN = 2,
    DIRECTION_COSINE = 3
}
//# sourceMappingURL=attitudeStateType.d.ts.map