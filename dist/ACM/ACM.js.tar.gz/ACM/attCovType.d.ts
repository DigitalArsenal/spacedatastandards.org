export declare enum attCovType {
    ANGLE = 0,
    ANGLE_GYROBIAS = 1,
    ANGLE_ANGVEL = 2,
    QUATERNION_COV = 3
}
//# sourceMappingURL=attCovType.d.ts.map