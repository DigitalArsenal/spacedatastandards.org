export { ACM, ACMT } from './ACM.js';
//# sourceMappingURL=main.d.ts.map