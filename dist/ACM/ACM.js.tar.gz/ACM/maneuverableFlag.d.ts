export declare enum maneuverableFlag {
    YES = 0,
    NO = 1,
    UNKNOWN = 2
}
//# sourceMappingURL=maneuverableFlag.d.ts.map