/**
 * Surface the tile's heights are measured from. A DEM whose datum is unstated
 * cannot be compared with, or rendered against, one whose datum is known.
 */
export declare enum dttVerticalDatum {
    /**
     * The datum is not stated. Heights are not comparable across tiles.
     */
    UNSPECIFIED = 0,
    /**
     * Heights above the WGS 84 reference ellipsoid.
     */
    ELLIPSOIDAL_WGS84 = 1,
    /**
     * Heights above a gravimetric geoid model; the model edition is carried
     * verbatim in VERTICAL_DATUM_NAME.
     */
    GEOID = 2,
    /**
     * Heights above a tidal mean-sea-level surface; the realization is carried
     * verbatim in VERTICAL_DATUM_NAME.
     */
    MEAN_SEA_LEVEL = 3,
    /**
     * Heights above a national or regional vertical reference frame, named
     * verbatim in VERTICAL_DATUM_NAME.
     */
    REGIONAL_DATUM = 4,
    /**
     * A datum this enum does not model, named verbatim in VERTICAL_DATUM_NAME.
     */
    CUSTOM = 5
}
//# sourceMappingURL=dttVerticalDatum.d.ts.map