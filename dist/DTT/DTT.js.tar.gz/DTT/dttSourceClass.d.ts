/**
 * Capability class of the measurement technique the source elevations were
 * produced by. The standard names no mission, dataset, agency, or vendor:
 * which dataset a tile came from is DATA, carried verbatim in
 * DTTProvenance.DATASET_ID and DATASET_NAME. Ordinals are wire values:
 * append only; never reorder or reuse.
 */
export declare enum dttSourceClass {
    /**
     * The production technique is not stated.
     */
    UNSPECIFIED = 0,
    /**
     * Spaceborne radar interferometry.
     */
    SPACEBORNE_RADAR_INTERFEROMETRIC = 1,
    /**
     * Spaceborne optical stereo photogrammetry.
     */
    SPACEBORNE_OPTICAL_STEREO = 2,
    /**
     * Spaceborne laser or radar altimetry.
     */
    SPACEBORNE_ALTIMETRIC = 3,
    /**
     * Airborne laser scanning.
     */
    AIRBORNE_LIDAR = 4,
    /**
     * Airborne radar, including interferometric and synthetic-aperture radar.
     */
    AIRBORNE_RADAR = 5,
    /**
     * Airborne or terrestrial optical photogrammetry.
     */
    PHOTOGRAMMETRIC = 6,
    /**
     * Ground survey, including levelling and kinematic positioning.
     */
    GROUND_SURVEY = 7,
    /**
     * Acoustic or altimetric depth sounding of water-covered surface.
     */
    BATHYMETRIC_SOUNDING = 8,
    /**
     * Digitized from a published contour or hypsographic map.
     */
    CARTOGRAPHIC_CONTOUR = 9,
    /**
     * Merged from two or more classes above; the contributing datasets are
     * carried in DTTProvenance.
     */
    FUSED_MULTI_SOURCE = 10,
    /**
     * Synthesized rather than measured: interpolated fill, procedural relief,
     * or a model output. Never to be presented as a measurement.
     */
    SYNTHETIC = 11
}
//# sourceMappingURL=dttSourceClass.d.ts.map