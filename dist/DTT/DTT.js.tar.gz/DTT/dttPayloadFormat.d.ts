/**
 * Encoding of the tile payload bytes. The format determines how a consumer
 * decodes heights; it is never guessed from the payload size or extension.
 */
export declare enum dttPayloadFormat {
    /**
     * The payload encoding is not stated. The tile is undecodable.
     */
    UNSPECIFIED = 0,
    /**
     * Quantized triangle mesh with 16-bit normalized vertex coordinates and
     * an indexed triangle list, plus optional extension chunks.
     */
    QUANTIZED_MESH = 1,
    /**
     * Regular grid of 16-bit unsigned height posts with a stated child-tile
     * availability byte.
     */
    HEIGHTMAP_UINT16 = 2,
    /**
     * Regular grid of 32-bit float height posts, row-major from the
     * north-west post.
     */
    HEIGHTMAP_FLOAT32 = 3,
    /**
     * Tagged image raster carrying elevation samples with its own georeference.
     */
    RASTER_GEOTIFF = 4,
    /**
     * Lossless RGB image raster whose channels encode elevation.
     */
    RASTER_RGB_ENCODED = 5,
    /**
     * A format this enum does not model; the publisher states it out of band.
     */
    CUSTOM = 6
}
//# sourceMappingURL=dttPayloadFormat.d.ts.map