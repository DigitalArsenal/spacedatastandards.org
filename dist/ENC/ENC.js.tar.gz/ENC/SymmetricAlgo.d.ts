/**
 * Symmetric encryption algorithm
 */
export declare enum SymmetricAlgo {
    AES_256_CTR = 0
}
//# sourceMappingURL=SymmetricAlgo.d.ts.map