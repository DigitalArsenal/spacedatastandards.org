/**
 * Key derivation function
 */
export declare enum KDF {
    HKDF_SHA256 = 0
}
//# sourceMappingURL=KDF.d.ts.map