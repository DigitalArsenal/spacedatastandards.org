export declare enum timingStandard {
    /**
     * Greenwich Mean Sidereal Time
     */
    GMST = 0,
    /**
     * Global Positioning System
     */
    GPS = 1,
    /**
     * Mission Elapsed Time
     */
    MET = 2,
    /**
     * Mission Relative Time
     */
    MRT = 3,
    /**
     * Spacecraft Clock (receiver) (requires rules for interpretation in ICD)
     */
    SCLK = 4,
    /**
     * International Atomic Time
     */
    TAI = 5,
    /**
     * Barycentric Coordinate Time
     */
    TCB = 6,
    /**
     * Barycentric Dynamical Time
     */
    TDB = 7,
    /**
     * Geocentric Coordinate Time
     */
    TCG = 8,
    /**
     * Terrestrial Time
     */
    TT = 9,
    /**
     * Universal Time
     */
    UT1 = 10,
    /**
     * Coordinated Universal Time
     */
    UTC = 11,
    /**
     * GLONASS Time
     */
    GLONASS = 12,
    /**
     * Galileo System Time
     */
    GST = 13,
    /**
     * Quasi-Zenith Satellite System Time
     */
    QZSS = 14,
    /**
     * BeiDou Time
     */
    BDT = 15,
    /**
     * Navigation with Indian Constellation Time
     */
    NAVIC = 16,
    /**
     * Satellite-Based Augmentation System Time
     */
    SBAS = 17,
    /**
     * Atomic time scale of the reference atomic-time network, offset from
     * International Atomic Time by the fixed constant A1 - TAI = 0.0343817 s
     * exactly. Appended last; never reorder or reuse existing values.
     */
    A1 = 18
}
//# sourceMappingURL=timingStandard.d.ts.map