/**
 * Non-registered or local use frames
 */
export declare enum CustomFrame {
    /**
     * Earth-Centered-Earth-Fixed: Rotates with Earth. X-axis at prime meridian, Y eastward, Z towards North Pole.
     */
    ECEF = 0,
    /**
     * True Equator Mean Equinox of Date, same as TEMEOFDATE: Dynamic frame for SGP4 satellite tracking.
     */
    TEME = 1,
    /**
     * True Equator Mean Equinox of Epoch: Static version of TEMEOFDATE at a given epoch.
     */
    TEMEOFEPOCH = 2,
    /**
     * East-North-Up: Local tangent plane for surface points.
     */
    ENU = 3,
    /**
     * North-East-Down: Aviation/navigation frame aligned with gravity.
     */
    NED = 4,
    /**
     * North-East-Up: Local tangent plane variant with Up positive.
     */
    NEU = 5,
    /**
     * Radial-Intrack-Cross-track: Spacecraft orientation aligned with orbit.
     */
    RIC = 6,
    /**
     * Radial-Transverse-Normal: Orbit frame for spacecraft dynamics.
     */
    RTN = 7,
    /**
     * Transverse-Velocity-Normal: Alternative orbit frame.
     */
    TVN = 8,
    /**
     * Vehicle-Velocity-Local-Horizontal: Orbit frame aligned with velocity vector.
     */
    VVLH = 9,
    /**
     * Radial-Tangential-Cross-track: Equivalent to LVLH/QSW.
     */
    QSW = 10,
    /**
     * Local Tangent Plane: Surface-fixed frame centered on a point.
     */
    LTP = 11,
    /**
     * Local Vertical-Local Horizontal: Z axis towards Earth center, X along velocity.
     */
    LVLH = 12,
    /**
     * Polar-North-East: Surface coordinate frame.
     */
    PNE = 13,
    /**
     * Body-Fixed Reference Frame: Fixed to a spacecraft or celestial object.
     */
    BRF = 14,
    /**
     * Radial-Along-track-Cross-track: Same as RSW.
     */
    RSW = 15,
    /**
     * Tangential-Normal-Cross-track: Same as TNW.
     */
    TNW = 16,
    /**
     * Radial-UTF: Radial, Along-track, Cross-track variant.
     */
    UVW = 17
}
//# sourceMappingURL=CustomFrame.d.ts.map