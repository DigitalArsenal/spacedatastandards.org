export { CHN, CHNT } from './CHN.js';
//# sourceMappingURL=main.d.ts.map