export declare enum rafPduType {
    BIND_INVOCATION = 0,
    BIND_RETURN = 1,
    UNBIND_INVOCATION = 2,
    UNBIND_RETURN = 3,
    START_INVOCATION = 4,
    START_RETURN = 5,
    STOP_INVOCATION = 6,
    STOP_RETURN = 7,
    TRANSFER_BUFFER = 8,
    STATUS_REPORT = 9,
    PEER_ABORT = 10
}
//# sourceMappingURL=rafPduType.d.ts.map