export { F107DataType } from './F107DataType.js';
export { FluxQualifier } from './FluxQualifier.js';
export { SPW, SPWT } from './SPW.js';
export { SPWCOLLECTION, SPWCOLLECTIONT } from './SPWCOLLECTION.js';
//# sourceMappingURL=main.d.ts.map