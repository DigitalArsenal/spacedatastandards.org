export declare enum F107DataType {
    OBS = 0,
    INT = 1,
    PRD = 2,
    PRM = 3
}
//# sourceMappingURL=F107DataType.d.ts.map