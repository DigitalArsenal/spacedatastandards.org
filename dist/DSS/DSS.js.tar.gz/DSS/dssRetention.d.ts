/**
 * Retention rule for a lane's publications on the subscribing node. Append
 * new values only; never reorder or reuse existing values.
 */
export declare enum dssRetention {
    /**
     * Each new publication replaces the previous batch; the lane holds one
     * current set.
     */
    ReplaceCurrent = 0,
    /**
     * Every publication is kept and pinned; history stays retrievable.
     */
    ArchiveAll = 1,
    /**
     * Every publication stays in the store; nothing is superseded and nothing
     * is pinned, so history stays queryable from the store.
     */
    KeepAll = 2
}
//# sourceMappingURL=dssRetention.d.ts.map