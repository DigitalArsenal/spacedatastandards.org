/**
 * Action a client requests on a lane. Append new values only; never reorder
 * or reuse existing values.
 */
export declare enum dssAction {
    None = 0,
    /**
     * Run one bounded catch-up pass now.
     */
    Sync = 1,
    Subscribe = 2,
    Unsubscribe = 3,
    Pin = 4,
    Unpin = 5,
    /**
     * Rebuild the local materialisation from pinned publications.
     */
    Hydrate = 6,
    /**
     * Set RETENTION and leave the subscription alone: the lane's rule, or,
     * when the frame names no PROVIDER_ID and no SOURCE_NAME, the default for
     * every lane of SCHEMA_NAME. A frame without RETENTION clears the choice,
     * so the default applies again.
     */
    SetRetention = 7
}
//# sourceMappingURL=dssAction.d.ts.map