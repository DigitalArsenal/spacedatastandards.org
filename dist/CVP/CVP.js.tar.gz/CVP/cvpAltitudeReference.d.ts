/**
 * The surface the vertex altitudes are referenced to.
 */
export declare enum cvpAltitudeReference {
    UNSPECIFIED = 0,
    WGS84_ELLIPSOID = 1,
    MEAN_SEA_LEVEL = 2,
    /**
     * Draped on terrain from the dataset named in
     * CVPProvenance.TERRAIN_DATASET.
     */
    TERRAIN = 3,
    /**
     * A constant altitude plane; the value is in FIXED_ALTITUDE_M.
     */
    FIXED_ALTITUDE = 4
}
//# sourceMappingURL=cvpAltitudeReference.d.ts.map