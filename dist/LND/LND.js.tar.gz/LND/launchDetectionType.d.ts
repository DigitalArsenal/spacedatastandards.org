export declare enum launchDetectionType {
    IR_DETECT = 0,
    RADAR_DETECT = 1,
    OPTICAL_DETECT = 2,
    ELINT_DETECT = 3,
    COMBINED = 4,
    UNKNOWN = 5
}
//# sourceMappingURL=launchDetectionType.d.ts.map