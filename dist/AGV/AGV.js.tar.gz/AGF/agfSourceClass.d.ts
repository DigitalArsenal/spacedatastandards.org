/**
 * What KIND of system produced this field. A capability class, never an
 * operator, a programme or a product name: those are data, and they live in
 * SOURCE_ID, PRODUCT_ID and PRODUCER.
 *
 * ORDINALS ARE WIRE VALUES. New classes are APPENDED ONLY.
 */
export declare enum agfSourceClass {
    UNSPECIFIED = 0,
    /**
     * Imaging radiometer on a geostationary platform.
     */
    GEO_IMAGER = 1,
    /**
     * Imaging radiometer on a low-Earth-orbiting platform.
     */
    LEO_IMAGER = 2,
    /**
     * Numerical weather prediction model field.
     */
    NWP_MODEL = 3,
    /**
     * Retrospective analysis of a fixed model and assimilation system.
     */
    REANALYSIS = 4,
    /**
     * Ground-based weather radar.
     */
    GROUND_RADAR = 5
}
//# sourceMappingURL=agfSourceClass.d.ts.map