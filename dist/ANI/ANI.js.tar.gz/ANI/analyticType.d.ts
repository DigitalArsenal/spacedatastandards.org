export declare enum analyticType {
    SPECTRAL = 0,
    PHOTOMETRIC = 1,
    ASTROMETRIC = 2,
    RADIOMETRIC = 3,
    SIGNATURE = 4,
    FEATURE_EXTRACTION = 5,
    CHANGE_DETECTION = 6,
    CLASSIFICATION = 7,
    FUSION = 8
}
//# sourceMappingURL=analyticType.d.ts.map