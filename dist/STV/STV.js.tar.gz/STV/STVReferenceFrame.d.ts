export declare enum STVReferenceFrame {
    GCRF = 0,
    ITRF = 1,
    EME2000 = 2,
    TEME = 3,
    ICRF = 4,
    MOON_CI = 5,
    MARS_CI = 6
}
//# sourceMappingURL=STVReferenceFrame.d.ts.map