export { OOT, OOTT } from './OOT.js';
export { thrusterType } from './thrusterType.js';
//# sourceMappingURL=main.d.ts.map