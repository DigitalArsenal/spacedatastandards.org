export { TIM, TIMT } from './TIM.js';
export { TIMCOLLECTION, TIMCOLLECTIONT } from './TIMCOLLECTION.js';
export { timeSystem } from './timeSystem.js';
//# sourceMappingURL=main.d.ts.map