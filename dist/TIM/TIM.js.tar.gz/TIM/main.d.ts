export { TIM, TIMT } from './TIM.js';
export { timeSystem } from './timeSystem.js';
//# sourceMappingURL=main.d.ts.map