export declare enum irDetectionType {
    POINT_SOURCE = 0,
    RESOLVED = 1,
    STREAK = 2,
    UNRESOLVED = 3,
    EXTENDED = 4
}
//# sourceMappingURL=irDetectionType.d.ts.map