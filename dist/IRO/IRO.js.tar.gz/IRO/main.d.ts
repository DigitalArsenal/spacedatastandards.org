export { IRO, IROT } from './IRO.js';
export { irBand } from './irBand.js';
export { irDetectionType } from './irDetectionType.js';
//# sourceMappingURL=main.d.ts.map