export { IRO, IROT } from './IRO.js';
//# sourceMappingURL=main.d.ts.map