export declare enum irBand {
    SWIR = 0,
    MWIR = 1,
    LWIR = 2,
    VLWIR = 3,
    BROADBAND = 4
}
//# sourceMappingURL=irBand.d.ts.map