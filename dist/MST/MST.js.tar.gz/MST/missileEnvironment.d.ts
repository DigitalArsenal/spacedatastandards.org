export declare enum missileEnvironment {
    SPACE = 0,
    ENDO_ATMOSPHERIC = 1,
    EXO_ATMOSPHERIC = 2,
    TRANSITIONAL = 3,
    UNKNOWN = 4
}
//# sourceMappingURL=missileEnvironment.d.ts.map