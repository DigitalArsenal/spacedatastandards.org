export declare enum missileStatus {
    BOOSTING = 0,
    MIDCOURSE = 1,
    TERMINAL = 2,
    IMPACT = 3,
    BURNOUT = 4,
    INTERCEPTED = 5,
    LOST = 6,
    UNKNOWN = 7
}
//# sourceMappingURL=missileStatus.d.ts.map