export declare enum aouReportType {
    CIRCULAR = 0,
    ELLIPTICAL = 1,
    RECTANGULAR = 2,
    NONE = 3
}
//# sourceMappingURL=aouReportType.d.ts.map