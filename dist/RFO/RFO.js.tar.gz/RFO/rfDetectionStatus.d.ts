export declare enum rfDetectionStatus {
    DETECTED = 0,
    CONFIRMED = 1,
    TENTATIVE = 2,
    LOST = 3,
    INTERFERENCE_ONLY = 4
}
//# sourceMappingURL=rfDetectionStatus.d.ts.map