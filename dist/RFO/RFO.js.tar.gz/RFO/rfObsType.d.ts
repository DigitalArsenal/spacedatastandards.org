export declare enum rfObsType {
    EMISSION = 0,
    TRANSPONDER = 1,
    INTERFERENCE = 2,
    BEACON = 3,
    TELEMETRY = 4,
    UNKNOWN = 5
}
//# sourceMappingURL=rfObsType.d.ts.map