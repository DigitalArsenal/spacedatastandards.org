export { GPX, GPXT } from './GPX.js';
export { GPXFixType } from './GPXFixType.js';
export { GPXLink, GPXLinkT } from './GPXLink.js';
export { GPXRoute, GPXRouteT } from './GPXRoute.js';
export { GPXTrack, GPXTrackT } from './GPXTrack.js';
export { GPXTrackSegment, GPXTrackSegmentT } from './GPXTrackSegment.js';
export { GPXWaypoint, GPXWaypointT } from './GPXWaypoint.js';
//# sourceMappingURL=main.d.ts.map