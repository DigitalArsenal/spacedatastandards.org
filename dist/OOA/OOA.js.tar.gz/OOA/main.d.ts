export { OOA, OOAT } from './OOA.js';
//# sourceMappingURL=main.d.ts.map