/**
 * What the COLOR slot of every point in a tile holds.
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum sktColorEncoding {
    /**
     * No colour; COLOR is 0.
     */
    NONE = 0,
    /**
     * Colour index COLOR_BLUE_BAND_ID minus COLOR_RED_BAND_ID in
     * millimagnitudes, offset by 32768 (COLOR = index_mmag + 32768). 0 means
     * unknown.
     */
    COLOR_INDEX = 1,
    /**
     * Effective temperature in units of 2 kelvin (COLOR = Teff / 2), rounded.
     * 0 means unknown.
     */
    EFFECTIVE_TEMPERATURE = 2
}
//# sourceMappingURL=sktColorEncoding.d.ts.map