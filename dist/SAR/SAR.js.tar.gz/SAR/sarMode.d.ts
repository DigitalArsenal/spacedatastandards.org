export declare enum sarMode {
    STRIPMAP = 0,
    SPOTLIGHT = 1,
    SCANSAR = 2,
    TOPSAR = 3,
    ISAR = 4,
    GMTI = 5,
    MARITIME = 6,
    UNKNOWN = 7
}
//# sourceMappingURL=sarMode.d.ts.map