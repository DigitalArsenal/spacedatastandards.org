export declare enum sarPolarization {
    HH = 0,
    VV = 1,
    HV = 2,
    VH = 3,
    DUAL_HH_VV = 4,
    DUAL_HH_HV = 5,
    DUAL_VV_VH = 6,
    QUAD = 7,
    COMPACT = 8
}
//# sourceMappingURL=sarPolarization.d.ts.map