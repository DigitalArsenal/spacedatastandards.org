export { CRM, CRMT } from './CRM.js';
export { CRMCOLLECTION, CRMCOLLECTIONT } from './CRMCOLLECTION.js';
//# sourceMappingURL=main.d.ts.map