/**
 * FlatSQL Batch Metadata.
 *
 * A FlatSQL feed (store format 5) is one linear stream of `[u32 LE size][FlatBuffer]`
 * frames. Record frames hold each record's bytes exactly as they arrived, so a
 * record is one contiguous byte range whose raw-leaf CIDv1 (sha2-256) is its
 * IPFS block. An FMB is the sibling frame that commits one commit round's rows
 * for one feed: it follows that round's record frames and never contains record
 * bytes. FMB frames, with the record frames, are everything needed to rebuild a
 * feed's index; values that can be re-extracted from the record bytes (epoch,
 * object key) are not repeated here. Offsets are local to the stream that holds
 * the frame and are never trusted across copies. Spec: flatsql
 * cpp/src/p4/FORMAT.md section 3.1.
 * Dictionary entry kinds. Ids are scoped to the feed, except TOKEN ids, which
 * are scoped to the record type.
 */
export declare enum fmbDictKind {
    /**
     * TEXT [token, peer]: a producer token of the type.
     */
    TOKEN = 0,
    /**
     * TEXT [producer, peer]: a publishing node.
     */
    NODE = 1,
    /**
     * TEXT [batch, producer peer, producer key]: a batch instance.
     */
    BATCH = 2,
    /**
     * TEXT [content key].
     */
    CONTENT_KEY = 3,
    /**
     * TEXT [url].
     */
    URL = 4,
    /**
     * TEXT [object key]: written only for sealed rows (other rows' keys come
     * from their bytes, numbered in order of first appearance in the stream).
     */
    OBJECT_KEY = 5
}
//# sourceMappingURL=fmbDictKind.d.ts.map