export declare enum ModuleState {
    OPERATIONAL = 0,
    DAMAGED = 1,
    CRITICAL = 2,
    DESTROYED = 3,
    REPAIRING = 4
}
//# sourceMappingURL=ModuleState.d.ts.map