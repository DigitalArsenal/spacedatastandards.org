/**
 * Dynamical model parameters a covariance and STM may carry after the state
 * (a VCM's B, BDOT, AGOM and T). Values are the request's FORCES, in SI:
 * DRAG_AREA_OVER_MASS Cd*A/m (m2/kg, DRAG_COEFFICIENT * AREA_M2 /
 * INITIAL_MASS_KG); DRAG_AREA_OVER_MASS_RATE its rate (m2/kg/s,
 * DRAG_AREA_OVER_MASS_RATE_M2_KG_S); SRP_AREA_OVER_MASS Cr*A/m (m2/kg,
 * REFLECTIVITY_COEFFICIENT * AREA_M2 / INITIAL_MASS_KG);
 * IN_TRACK_ACCELERATION m/s2 (IN_TRACK_ACCELERATION_M_S2).
 */
export declare enum prwDynamicParameter {
    UNSPECIFIED = 0,
    DRAG_AREA_OVER_MASS = 1,
    DRAG_AREA_OVER_MASS_RATE = 2,
    SRP_AREA_OVER_MASS = 3,
    IN_TRACK_ACCELERATION = 4
}
//# sourceMappingURL=prwDynamicParameter.d.ts.map