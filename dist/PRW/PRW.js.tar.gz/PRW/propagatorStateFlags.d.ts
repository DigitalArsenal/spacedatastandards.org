/**
 * Propagator Runtime Wire — arena-addressed init / batch request / batch
 * response envelopes for orbital propagators that produce state vectors
 * into a shared memory arena.
 *
 * Data interchange for the underlying content (state vectors, covariance,
 * maneuvers, force models, Keplerian / TLE inputs, polynomial ephemeris)
 * lives in SDS `OCM` + `OMM` + `PPE` + `RFM` + `ATM`. PRW is the runtime
 * wire that moves those across a JS ↔ WASM boundary, not a substitute for
 * any of them.
 * Runtime state-flag bitfield (sized to match a single uint).
 * Data-interchange equivalents: MANEUVERING is subsumed by OCM.Maneuver;
 * HAS_COVARIANCE is implicit from OCM.COVARIANCE_DATA. The remaining
 * flags live here because they describe runtime propagation health, not
 * a persisted record.
 */
export declare enum propagatorStateFlags {
    /**
     * State vector data is valid.
     */
    VALID = 1,
    /**
     * Satellite is in Earth's shadow at this epoch.
     */
    IN_ECLIPSE = 2,
    /**
     * Orbit has decayed (re-entry imminent or complete).
     */
    DECAYED = 4,
    /**
     * Propagation extrapolated beyond the input epoch.
     */
    EXTRAPOLATED = 8,
    /**
     * Reserved.
     */
    RESERVED_4 = 16,
    /**
     * Reserved.
     */
    RESERVED_5 = 32,
    /**
     * Reserved.
     */
    RESERVED_6 = 64,
    /**
     * Reserved.
     */
    RESERVED_7 = 128
}
//# sourceMappingURL=propagatorStateFlags.d.ts.map