/**
 * What answers a request time outside an element-set propagator's window
 * (PCFEpochStore WINDOW_BEFORE_DAYS and WINDOW_AFTER_DAYS). Append new values
 * only.
 */
export declare enum pcfFallbackPropagator {
    /**
     * Nothing: the state is NaN with a status that says outside the window.
     */
    NONE = 0,
    /**
     * SGP4 on the object's own SGP4 set.
     */
    SGP4 = 1,
    /**
     * SGP4-XP on the object's own SGP4-XP set.
     */
    SGP4XP = 2,
    /**
     * The host routes the request elsewhere: no state, a status that asks for it.
     */
    HOST = 3
}
//# sourceMappingURL=pcfFallbackPropagator.d.ts.map