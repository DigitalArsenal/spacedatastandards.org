/**
 * What a propagator does when a located event occurs. Append new values
 * only.
 */
export declare enum pcfEventAction {
    UNSPECIFIED = 0,
    /**
     * End the propagation at the event; the result carries its epoch and state.
     */
    STOP = 1,
    /**
     * Make the event a step boundary only (the dynamics may change there) and
     * report nothing about it.
     */
    CONTINUE = 2,
    /**
     * Report the event in the result and keep propagating.
     */
    RECORD = 3
}
//# sourceMappingURL=pcfEventAction.d.ts.map