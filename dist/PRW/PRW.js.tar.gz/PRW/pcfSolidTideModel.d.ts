/**
 * Solid Earth tide model for the central body's field. UNSPECIFIED uses the
 * propagator's own default (IERS 2010 when supported). NONE disables solid
 * Earth tides explicitly. IERS_2010 is IERS Conventions (2010) section 6.2:
 * degree 2 and 3 tides raised by the Sun and Moon with Table 6.3's anelastic
 * Love numbers, degree 4 terms through k+ (step 1, eqs. 6.6-6.7),
 * frequency-dependent corrections of Tables 6.5a-c (step 2, eq. 6.8), and the
 * permanent tide handled for the field's own tide system. Pole tide is not
 * included.
 */
export declare enum pcfSolidTideModel {
    UNSPECIFIED = 0,
    NONE = 1,
    IERS_2010 = 2
}
//# sourceMappingURL=pcfSolidTideModel.d.ts.map