export { OON, OONT } from './OON.js';
//# sourceMappingURL=main.d.ts.map