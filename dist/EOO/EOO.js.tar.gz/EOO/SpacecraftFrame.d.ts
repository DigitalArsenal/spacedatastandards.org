/**
 * https://sanaregistry.org/r/spacecraft_body_reference_frames/
 * Spacecraft Body Reference Frames (SANA registry 1.3.112.4.57.8)
 */
export declare enum SpacecraftFrame {
    /**
     * OID: 1.3.112.4.57.8.1
     * Accelerometer instrument frame.
     */
    ACC_i = 0,
    /**
     * OID: 1.3.112.4.57.8.2
     * Actuator system frame.
     */
    ACTUATOR_i = 1,
    /**
     * OID: 1.3.112.4.57.8.3
     * Attitude Sensor Target frame.
     */
    AST_i = 2,
    /**
     * OID: 1.3.112.4.57.8.4
     * Coarse Sun Sensor frame.
     */
    CSS_i = 3,
    /**
     * OID: 1.3.112.4.57.8.5
     * Digital Sun Sensor frame.
     */
    DSS_i = 4,
    /**
     * OID: 1.3.112.4.57.8.6
     * Earth Sensor Assembly frame.
     */
    ESA_i = 5,
    /**
     * OID: 1.3.112.4.57.8.7
     * Gyroscope instrument frame.
     */
    GYRO_FRAME_i = 6,
    /**
     * OID: 1.3.112.4.57.8.8
     * Inertial Measurement Unit frame.
     */
    IMU_FRAME_i = 7,
    /**
     * OID: 1.3.112.4.57.8.9
     * Generic instrument mounting frame.
     */
    INSTRUMENT_i = 8,
    /**
     * OID: 1.3.112.4.57.8.10
     * Magnetic Torquer Assembly frame.
     */
    MTA_i = 9,
    /**
     * OID: 1.3.112.4.57.8.11
     * Reaction Wheel assembly frame.
     */
    RW_i = 10,
    /**
     * OID: 1.3.112.4.57.8.12
     * Solar Array frame.
     */
    SA_i = 11,
    /**
     * OID: 1.3.112.4.57.8.13
     * Spacecraft body fixed frame.
     */
    SC_BODY_i = 12,
    /**
     * OID: 1.3.112.4.57.8.14
     * Generic sensor assembly frame.
     */
    SENSOR_i = 13,
    /**
     * OID: 1.3.112.4.57.8.15
     * Star Tracker instrument frame.
     */
    STARTRACKER_i = 14,
    /**
     * OID: 1.3.112.4.57.8.16
     * Thermal Assembly Module frame.
     */
    TAM_i = 15
}
//# sourceMappingURL=SpacecraftFrame.d.ts.map