export declare enum ObservationPosition {
    FENCE = 0,
    FIRST = 1,
    IN = 2,
    LAST = 3,
    SINGLE = 4
}
//# sourceMappingURL=ObservationPosition.d.ts.map