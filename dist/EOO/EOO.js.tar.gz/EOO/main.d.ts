export { EOO, EOOT } from './EOO.js';
//# sourceMappingURL=main.d.ts.map