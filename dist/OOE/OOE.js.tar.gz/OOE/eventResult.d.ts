export declare enum eventResult {
    TOTAL_LOSS = 0,
    PARTIAL_LOSS = 1,
    DEGRADED = 2,
    RECOVERED = 3,
    NOMINAL = 4,
    PENDING = 5
}
//# sourceMappingURL=eventResult.d.ts.map