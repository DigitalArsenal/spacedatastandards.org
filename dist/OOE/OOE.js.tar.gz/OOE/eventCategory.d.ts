export declare enum eventCategory {
    ANOMALY = 0,
    FAILURE = 1,
    RETIREMENT = 2,
    DEORBIT = 3,
    BREAKUP = 4,
    COLLISION = 5,
    STATUS_CHANGE = 6,
    REPOSITIONING = 7,
    UNKNOWN = 8
}
//# sourceMappingURL=eventCategory.d.ts.map