export { OOE, OOET } from './OOE.js';
//# sourceMappingURL=main.d.ts.map