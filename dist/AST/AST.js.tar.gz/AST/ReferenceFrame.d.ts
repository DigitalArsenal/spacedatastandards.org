export declare enum ReferenceFrame {
    ECI_J2000 = 0,
    ECEF = 1,
    TEME = 2,
    GCRF = 3,
    ITRF = 4,
    RIC = 5,
    VNC = 6,
    NTW = 7,
    SEZ = 8,
    LVLH = 9
}
//# sourceMappingURL=ReferenceFrame.d.ts.map