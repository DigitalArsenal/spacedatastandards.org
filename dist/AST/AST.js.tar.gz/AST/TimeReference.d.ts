export declare enum TimeReference {
    UTC = 0,
    TAI = 1,
    TT = 2,
    TDB = 3,
    GPS_TIME = 4,
    JULIAN_DATE = 5,
    MODIFIED_JULIAN_DATE = 6
}
//# sourceMappingURL=TimeReference.d.ts.map