export declare enum PropagatorMethod {
    KEPLER = 0,
    SGP4 = 1,
    SDP4 = 2,
    FFM = 3,
    COWELL = 4,
    ENCKE = 5,
    GAUSS_JACKSON = 6,
    RK78 = 7,
    BROUWER = 8,
    KOZAI = 9,
    DSST = 10
}
//# sourceMappingURL=PropagatorMethod.d.ts.map