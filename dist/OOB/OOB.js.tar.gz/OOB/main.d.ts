export { OOB, OOBT } from './OOB.js';
//# sourceMappingURL=main.d.ts.map