/**
 * The kind of volume this record describes, as the source publishes it.
 * Ordinals are wire values: append only; never reorder or reuse.
 */
export declare enum avlVolumeType {
    UNSPECIFIED = 0,
    /**
     * A controlled airspace volume not otherwise classified below.
     */
    CONTROLLED = 1,
    /**
     * Restricted area: entry restricted per published conditions.
     */
    RESTRICTED = 2,
    /**
     * Prohibited area: flight prohibited.
     */
    PROHIBITED = 3,
    /**
     * Danger area: activities hazardous to flight may exist.
     */
    DANGER = 4,
    /**
     * Terminal control area.
     */
    TMA = 5,
    /**
     * Control zone.
     */
    CTR = 6,
    /**
     * Aerodrome traffic zone.
     */
    ATZ = 7,
    /**
     * Flight information region.
     */
    FIR = 8,
    /**
     * Upper flight information region.
     */
    UIR = 9,
    /**
     * Military operations area.
     */
    MOA = 10,
    /**
     * Air defense identification zone.
     */
    ADIZ = 11
}
//# sourceMappingURL=avlVolumeType.d.ts.map