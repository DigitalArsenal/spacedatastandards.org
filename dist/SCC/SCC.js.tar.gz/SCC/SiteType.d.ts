/**
 * Enum for the type of site
 */
export declare enum SiteType {
    LAUNCH_SITE = 0,
    OBSERVATION_STATION = 1,
    HOBBYIST_OBSERVER = 2,
    RESEARCH_FACILITY = 3,
    SATELLITE_GROUND_STATION = 4,
    SPACEPORT = 5,
    MILITARY_BASE = 6,
    WEATHER_STATION = 7,
    ASTRONOMICAL_OBSERVATORY = 8,
    EDUCATIONAL_INSTITUTE = 9,
    COMMUNICATION_HUB = 10,
    POWER_PLANT = 11,
    INDUSTRIAL_COMPLEX = 12,
    TRANSPORTATION_HUB = 13,
    URBAN_AREA = 14,
    NATIONAL_PARK = 15,
    HISTORICAL_SITE = 16,
    OTHER = 17,
    /**
     * A place a spacecraft touched down or is to touch down on a body surface
     */
    LANDING_SITE = 18,
    /**
     * A place a spacecraft or stage struck a body surface
     */
    IMPACT_SITE = 19,
    /**
     * A surface region under study as a landing or exploration target
     */
    CANDIDATE_REGION = 20,
    /**
     * A named natural feature of a body surface (crater, mare, rille, mons)
     */
    SURFACE_FEATURE = 21
}
//# sourceMappingURL=SiteType.d.ts.map