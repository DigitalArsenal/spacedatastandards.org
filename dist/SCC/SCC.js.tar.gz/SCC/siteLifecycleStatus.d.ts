/**
 * Where a site stands in its life. IAEA PRIS/RRDB terms; compatible with the
 * EU INSPIRE ConditionOfFacilityValue list. Ordinals are wire values: append only.
 */
export declare enum siteLifecycleStatus {
    /**
     * No source states a status
     */
    UNSPECIFIED = 0,
    /**
     * Proposed, announced or in study; construction not begun
     */
    PLANNED = 1,
    /**
     * Under construction
     */
    UNDER_CONSTRUCTION = 2,
    /**
     * Construction begun, then halted with no restart date (PRIS suspended construction)
     */
    CONSTRUCTION_SUSPENDED = 3,
    /**
     * In operation
     */
    OPERATING = 4,
    /**
     * Not operating, with a stated intent to restart (PRIS suspended operation; RRDB 1T, 7X)
     */
    LONG_TERM_SHUTDOWN = 5,
    /**
     * Permanently shut down; not yet in decommissioning
     */
    PERMANENT_SHUTDOWN = 6,
    /**
     * Decommissioning or dismantling under way
     */
    DECOMMISSIONING = 7,
    /**
     * Dismantled, remediated or released from regulatory control
     */
    DECOMMISSIONED = 8,
    /**
     * Never completed or never operated
     */
    CANCELLED = 9,
    /**
     * Every licence-OK source was read and none states a status
     */
    UNVERIFIED = 10
}
//# sourceMappingURL=siteLifecycleStatus.d.ts.map