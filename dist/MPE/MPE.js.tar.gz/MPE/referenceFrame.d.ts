export declare enum referenceFrame {
    /**
     * Earth Mean Equator and Equinox of J2000
     */
    EME2000 = 0,
    /**
     * Geocentric Celestial Reference Frame
     */
    GCRF = 1,
    /**
     * Greenwich Rotating Coordinates
     */
    GRC = 2,
    /**
     * International Celestial Reference Frame
     */
    ICRF = 3,
    /**
     * International Terrestrial Reference Frame 2000
     */
    ITRF2000 = 4,
    /**
     * International Terrestrial Reference Frame 1993
     */
    ITRF93 = 5,
    /**
     * International Terrestrial Reference Frame 1997
     */
    ITRF97 = 6,
    /**
     * Mars Centered Inertial
     */
    MCI = 7,
    /**
     * True of Date, Rotating
     */
    TDR = 8,
    /**
     * True Equator Mean Equinox
     */
    TEME = 9,
    /**
     * True of Date
     */
    TOD = 10
}
//# sourceMappingURL=referenceFrame.d.ts.map