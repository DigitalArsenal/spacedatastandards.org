export declare enum EngineType {
    TURBOJET = 0,
    TURBOFAN_LOW = 1,
    TURBOFAN_HIGH = 2,
    TURBOPROP = 3,
    PISTON = 4,
    RAMJET = 5,
    SCRAMJET = 6,
    ELECTRIC = 7
}
//# sourceMappingURL=EngineType.d.ts.map