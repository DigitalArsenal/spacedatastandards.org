export declare enum GearState {
    UP = 0,
    TRANSIT_DOWN = 1,
    DOWN = 2,
    TRANSIT_UP = 3,
    DAMAGED = 4
}
//# sourceMappingURL=GearState.d.ts.map