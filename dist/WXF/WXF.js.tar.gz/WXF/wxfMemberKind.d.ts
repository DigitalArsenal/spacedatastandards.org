/**
 * Which realisation of an ensemble the field represents. Append new values
 * only; never reorder or reuse existing values.
 */
export declare enum wxfMemberKind {
    /**
     * One perturbed ensemble member; MEMBER_INDEX selects it.
     */
    Member = 0,
    /**
     * The unperturbed control member.
     */
    Control = 1,
    /**
     * A single deterministic run (no ensemble).
     */
    Deterministic = 2,
    /**
     * Ensemble arithmetic mean.
     */
    Mean = 3,
    /**
     * Ensemble median.
     */
    Median = 4,
    /**
     * Ensemble standard deviation.
     */
    StandardDeviation = 5,
    /**
     * Ensemble minimum.
     */
    Minimum = 6,
    /**
     * Ensemble maximum.
     */
    Maximum = 7,
    /**
     * Ensemble percentile; PERCENTILE holds the rank in [0, 100].
     */
    Percentile = 8,
    /**
     * Probability that the variable exceeds THRESHOLD_VALUE, in [0, 1].
     */
    ProbabilityAboveThreshold = 9,
    /**
     * Probability that the variable falls below THRESHOLD_VALUE, in [0, 1].
     */
    ProbabilityBelowThreshold = 10
}
//# sourceMappingURL=wxfMemberKind.d.ts.map