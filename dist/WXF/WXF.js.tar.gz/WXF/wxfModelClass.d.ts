/**
 * Weather Forecast Field (WXF)
 * Description
 * One two-dimensional slice of a weather forecast: a single variable, at a
 * single vertical level, for a single ensemble member (or a statistic over
 * the ensemble), valid at a single time, on a regular latitude-longitude
 * grid. A producer such as a global ensemble forecast model initialised on a
 * fixed cadence emits one WXF per (variable, level, member, lead) at each
 * initialisation; a consumer selects by INIT_TIME_MS / LEAD_HOURS / VARIABLE /
 * LEVEL_KIND / MEMBER_KIND and reads the cells. Fields of up to 1,048,576
 * cells carry their samples inline in VALUES; larger fields are split into
 * tiles (TILE_INDEX / TILE_COUNT, each with its own GRID) or reference a
 * content-addressed chunk through CHUNK_CID. Every epoch is Unix
 * milliseconds UTC. A forecast is a model output, never an official warning.
 * Class of model that produced the field. Names a capability class, never a
 * producer. Append new values only; never reorder or reuse existing values.
 */
export declare enum wxfModelClass {
    Unspecified = 0,
    /**
     * Machine-learned global ensemble forecast model.
     */
    MachineLearnedGlobalEnsemble = 1,
    /**
     * Physics-based numerical global ensemble forecast model.
     */
    NumericalGlobalEnsemble = 2,
    /**
     * Physics-based numerical global deterministic forecast model.
     */
    NumericalGlobalDeterministic = 3,
    /**
     * Limited-area numerical forecast model.
     */
    NumericalRegional = 4,
    /**
     * Retrospective analysis produced by assimilating observations.
     */
    Reanalysis = 5,
    /**
     * Objective analysis at the initialisation time (lead 0).
     */
    Analysis = 6,
    /**
     * A class not covered above; MODEL_ID identifies the producer's model.
     */
    Other = 7,
    /**
     * Empirical climatological model evaluated at VALID_TIME_MS from
     * geophysical indices, with no forecast run (pair with TIME_BASIS
     * ValidTimeOnly).
     */
    EmpiricalClimatology = 8
}
//# sourceMappingURL=wxfModelClass.d.ts.map