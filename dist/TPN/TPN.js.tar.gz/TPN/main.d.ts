export { TPN, TPNT } from './TPN.js';
//# sourceMappingURL=main.d.ts.map