export declare enum geoStationKeeping {
    ACTIVE = 0,
    DRIFTING = 1,
    INCLINED = 2,
    GRAVEYARD = 3,
    REPOSITIONING = 4,
    UNKNOWN = 5
}
//# sourceMappingURL=geoStationKeeping.d.ts.map