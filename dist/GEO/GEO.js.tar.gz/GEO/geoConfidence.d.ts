export declare enum geoConfidence {
    HIGH = 0,
    MEDIUM = 1,
    LOW = 2,
    TENTATIVE = 3
}
//# sourceMappingURL=geoConfidence.d.ts.map