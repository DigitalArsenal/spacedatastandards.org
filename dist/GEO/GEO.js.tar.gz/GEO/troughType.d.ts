export declare enum troughType {
    EAST = 0,
    WEST = 1,
    NEITHER = 2
}
//# sourceMappingURL=troughType.d.ts.map