/**
 * Network a tracking station belongs to. Append new values only; never
 * reorder or reuse existing values.
 */
export declare enum gstNetwork {
    UNSPECIFIED = 0,
    /**
     * NASA Deep Space Network.
     */
    DSN = 1,
    /**
     * ESA tracking station network.
     */
    ESTRACK = 2,
    /**
     * European VLBI Network.
     */
    EVN = 3,
    /**
     * International Laser Ranging Service.
     */
    ILRS = 4,
    /**
     * International GNSS Service.
     */
    IGS = 5,
    /**
     * A network not covered above.
     */
    OTHER = 6
}
//# sourceMappingURL=gstNetwork.d.ts.map