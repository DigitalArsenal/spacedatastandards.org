export declare enum WeaponType {
    MG_SMALL = 0,
    MG_HEAVY = 1,
    AUTOCANNON = 2,
    CANNON = 3,
    TANK_GUN = 4,
    ARTILLERY = 5,
    MORTAR = 6,
    ROCKET_UNGUIDED = 7,
    BOMB_DUMB = 8,
    BOMB_GUIDED = 9,
    TORPEDO = 10,
    DEPTH_CHARGE = 11,
    MINE = 12,
    GRENADE = 13
}
//# sourceMappingURL=WeaponType.d.ts.map