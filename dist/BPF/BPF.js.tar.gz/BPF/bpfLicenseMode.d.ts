/**
 * Distribution-control mode of the produced artifact. This is a build
 * configuration choice, not a commercial term and not an entitlement.
 * Append new values only; never reorder or reuse existing values.
 */
export declare enum bpfLicenseMode {
    /**
     * The publisher did not state a mode. A consumer MUST NOT infer one.
     */
    UNSPECIFIED = 0,
    /**
     * No distribution control: every embedded payload is readable without a
     * key supplied at runtime.
     */
    NONE = 1,
    /**
     * The artifact carries the recipient key that unwraps its protected
     * payloads.
     */
    BUNDLED_KEY = 2,
    /**
     * The recipient key is derived at runtime from an operator-supplied
     * distribution key; the artifact carries no recipient key.
     */
    LICENSE_KEY = 3
}
//# sourceMappingURL=bpfLicenseMode.d.ts.map