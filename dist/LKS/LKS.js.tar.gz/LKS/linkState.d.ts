export declare enum linkState {
    ESTABLISHED = 0,
    DEGRADED = 1,
    INTERRUPTED = 2,
    PLANNED = 3,
    TERMINATED = 4,
    UNKNOWN = 5
}
//# sourceMappingURL=linkState.d.ts.map