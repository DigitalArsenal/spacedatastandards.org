export { LKS, LKST } from './LKS.js';
//# sourceMappingURL=main.d.ts.map