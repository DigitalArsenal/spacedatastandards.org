export declare enum linkType {
    UPLINK = 0,
    DOWNLINK = 1,
    CROSSLINK = 2,
    INTER_SATELLITE = 3,
    GROUND_TO_GROUND = 4,
    RELAY = 5
}
//# sourceMappingURL=linkType.d.ts.map