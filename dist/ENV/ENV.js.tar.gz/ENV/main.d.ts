export { AtmosphereModel } from './AtmosphereModel.js';
export { ENV, ENVT } from './ENV.js';
export { TerrainType } from './TerrainType.js';
export { WeatherCondition } from './WeatherCondition.js';
//# sourceMappingURL=main.d.ts.map