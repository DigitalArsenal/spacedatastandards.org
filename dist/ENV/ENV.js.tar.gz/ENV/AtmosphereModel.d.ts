export declare enum AtmosphereModel {
    ISA = 0,
    US_STD_1976 = 1,
    NRLMSISE_00 = 2,
    SIMPLE = 3,
    CUSTOM = 4
}
//# sourceMappingURL=AtmosphereModel.d.ts.map