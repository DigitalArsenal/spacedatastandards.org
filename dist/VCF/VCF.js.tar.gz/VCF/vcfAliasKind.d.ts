/**
 * What an identity address row carries. APPEND ONLY; a member is never removed
 * and never reused, so a consumer that does not know a token can still route
 * the row by KIND_TOKEN.
 */
export declare enum vcfAliasKind {
    UNSPECIFIED = 0,
    /**
     * The literal public key that produced the profile's signature.
     */
    SIGNING_KEY = 1,
    /**
     * The literal public key a correspondent encrypts to.
     */
    ENCRYPTION_KEY = 2,
    /**
     * The profile's own signature value, so a scanner can verify without a
     * second fetch.
     */
    PROFILE_SIGNATURE = 3,
    /**
     * The profile's signature timestamp, as the publisher stated it.
     */
    PROFILE_SIGNATURE_TIMESTAMP = 4,
    /**
     * Content identifier of the exact profile bytes the card projects.
     */
    PROFILE_CONTENT_ID = 5,
    /**
     * A distributed-ledger account the profile proves control of. CHAIN names
     * which ledger.
     */
    LEDGER_ACCOUNT = 6,
    /**
     * A row whose kind this standard does not model. KIND_TOKEN is authoritative.
     */
    OTHER = 7
}
//# sourceMappingURL=vcfAliasKind.d.ts.map