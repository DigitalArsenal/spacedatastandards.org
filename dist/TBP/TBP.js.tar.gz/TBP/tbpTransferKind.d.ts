/**
 * How a transfer is built. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum tbpTransferKind {
    Unspecified = 0,
    /**
     * Direct two-body patched-conic transfer.
     */
    HohmannLike = 1,
    /**
     * Low-energy (ballistic capture) transfer.
     */
    LowEnergy = 2,
    /**
     * Free-return trajectory about the smaller primary.
     */
    FreeReturn = 3,
    /**
     * Powered flyby of the smaller primary.
     */
    PoweredFlyby = 4,
    /**
     * Weak-stability-boundary transfer.
     */
    WeakStabilityBoundary = 5,
    /**
     * Direct insertion into an orbit about the smaller primary.
     */
    DirectInsertion = 6,
    /**
     * Insertion into a periodic orbit (TARGET_ORBIT).
     */
    PeriodicOrbitInsertion = 7,
    /**
     * Theoretical minimum Jacobi-energy delta-v between states or to surface.
     */
    MinEnergy = 8,
    /**
     * Single-revolution STM-targeted direct CR3BP Lambert transfer.
     */
    DirectLambert = 9,
    /**
     * Minimum-delta-v CR3BP Lambert across prograde/retrograde and primaries.
     */
    MinLambert = 10,
    /**
     * Minimum-time low-thrust optimal control (Pontryagin Minimum Principle).
     */
    LowThrustMinTime = 11
}
//# sourceMappingURL=tbpTransferKind.d.ts.map