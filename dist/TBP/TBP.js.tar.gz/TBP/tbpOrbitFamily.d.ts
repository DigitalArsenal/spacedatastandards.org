/**
 * Family of a periodic orbit. Append new values only; never reorder or reuse
 * existing values.
 */
export declare enum tbpOrbitFamily {
    Unspecified = 0,
    /**
     * Halo orbit whose largest out-of-plane excursion is north (+Z).
     */
    HaloNorthern = 1,
    /**
     * Halo orbit whose largest out-of-plane excursion is south (-Z).
     */
    HaloSouthern = 2,
    /**
     * Planar Lyapunov orbit.
     */
    PlanarLyapunov = 3,
    /**
     * Vertical Lyapunov orbit.
     */
    VerticalLyapunov = 4,
    /**
     * Near-rectilinear halo orbit (the high-amplitude end of the halo family).
     */
    NearRectilinearHalo = 5,
    /**
     * Distant retrograde orbit about the smaller primary.
     */
    DistantRetrograde = 6,
    /**
     * Butterfly orbit.
     */
    Butterfly = 7,
    /**
     * Axial orbit.
     */
    Axial = 8,
    /**
     * Short- or long-period orbit about L4 or L5.
     */
    LongShortPeriod = 9
}
//# sourceMappingURL=tbpOrbitFamily.d.ts.map